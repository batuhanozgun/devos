#!/usr/bin/env python3
"""Run an isolated original-source ECC guard/runner study; never apply tool writes."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

EXPECTED = {
    'scripts/hooks/config-protection.js': '2da5358c2f2e7711194580df96241cf9d55d1979',
    'scripts/lib/hook-flags.js': '69d3f25d6ba5d49acdebed943352674f87caa5c3',
    'scripts/hooks/run-with-flags.js': '9f6de372212d5c3ba20502b5e05711431f1a0053',
    'scripts/hooks/pretooluse-visible-output.js': 'dc48119099f6206e6011174a62ad9912d7af9a25',
}
def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
def verify_sources(root: Path) -> dict:
    result = {}
    for name, expected in EXPECTED.items():
        data = (root / name).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if blob != expected:
            raise RuntimeError(f'Source identity mismatch: {name}: {blob} != {expected}')
        result[name] = {'git_blob': blob, 'sha256': sha256(data), 'bytes': len(data)}
    return result

def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python probe.py <exact-source-root>')
    source = Path(sys.argv[1]).resolve(strict=True)
    node = shutil.which('node')
    if not node:
        raise RuntimeError('node is required')
    before = verify_sources(source)
    plan = Path(__file__).with_name('PLAN.md')
    report = {
        'experiment': 'E05', 'pin': '8321021c54d670126ce3b2969d5deb880b4b0c2a',
        'started_at': datetime.now(timezone.utc).isoformat(),
        'platform': platform.platform(),
        'python': platform.python_version(),
        'node': subprocess.check_output([node, '--version'], text=True).strip(),
        'source_before': before,
        'plan_sha256': sha256(plan.read_bytes()),
        'runner_sha256': sha256(Path(__file__).read_bytes()),
        'cases': [],
    }
    with tempfile.TemporaryDirectory(prefix='ecc-e05-') as temp:
        root = Path(temp)
        (root / 'home').mkdir()
        protected = root / 'eslint.config.js'
        protected.write_text('export default [{rules: {"no-console": "error"}}];\n')
        ordinary = root / 'main.js'
        ordinary.write_text('export const value = 1;\n')
        mixed = root / 'pyproject.toml'
        mixed.write_text('[project]\nname="fixture"\n[tool.ruff.lint]\nselect=["E"]\n')
        new = root / '.prettierrc'
        dangling = root / '.eslintrc.js'
        dangling.symlink_to(root / 'missing.js')
        managed = root / 'disabled-hook-config.json'
        managed.write_text('{"hooks":{"enabled":false,"profile":"standard"}}\n')
        initial = {str(p): sha256(p.read_bytes()) for p in (protected, ordinary, mixed, managed)}
        def payload(p, content='fixture proposal only'):
            return {'tool_name': 'Write', 'tool_input': {'file_path': str(p), 'content': content}}
        base = payload(protected)
        oversized = payload(ordinary, 'x' * (1024 * 1024 + 2048))
        cases = [
            ('C00', payload(ordinary), {}, 0, 'raw', None),
            ('C01', base, {}, 2, 'empty', 'BLOCKED: Modifying'),
            ('C02', payload(protected, protected.read_text()), {}, 2, 'empty', 'BLOCKED: Modifying'),
            ('C03', payload(new), {}, 0, 'raw', None),
            ('C04', payload(dangling), {}, 2, 'empty', 'BLOCKED: Modifying'),
            ('C05', payload(mixed), {}, 0, 'raw', None),
            ('C06', '{not-json', {}, 0, 'raw', None),
            ('C07', oversized, {}, 2, 'empty', 'Refusing to bypass config-protection on a truncated payload'),
            ('C08', oversized, {'ECC_HOOK_PROFILE':'minimal'}, 0, 'empty', 'stdin exceeded'),
            ('C09', base, {'ECC_HOOK_PROFILE':'minimal'}, 0, 'raw', None),
            ('C10', base, {'ECC_DISABLED_HOOKS':'pre:config-protection'}, 0, 'raw', None),
            ('C11', base, {'ECC_DRY_RUN':'1'}, 0, 'raw', '[DryRun]'),
            ('C12', {'tool_name':'Write','tool_input':{'file_path':{'invalid':'object'}}}, {}, 0, 'raw', '[Hook] run() error'),
            ('C13', base, {'ECC_HOOK_CONFIG':str(managed)}, 0, 'raw', None),
            ('C14', base, {'ECC_HOOK_CONFIG':str(managed),'ECC_HOOKS_ENABLED':'true'}, 2, 'empty', 'BLOCKED: Modifying'),
            ('C15', base, {'ECC_HOOK_PROFILE':'invalid-profile'}, 2, 'empty', 'BLOCKED: Modifying'),
        ]
        env = {
            'PATH': os.path.dirname(node) + os.pathsep + '/usr/bin:/bin',
            'HOME': str(root / 'home'), 'USERPROFILE': str(root / 'home'),
            'CLAUDE_PLUGIN_ROOT': str(source),
            'ECC_HOOK_CONFIG': str(root / 'no-config.json'),
            'ECC_HOOK_PROFILE': 'standard',
        }
        command = [node, str(source / 'scripts/hooks/run-with-flags.js'),
                   'pre:config-protection', 'scripts/hooks/config-protection.js', 'standard,strict']
        report['command'] = command
        report['base_env'] = env
        for case_id, data, override, code, out_kind, error_text in cases:
            raw = data if isinstance(data, str) else json.dumps(data, separators=(',', ':'))
            result = subprocess.run(command, input=raw, text=True, capture_output=True,
                                    env={**env, **override}, cwd=root, timeout=15)
            checks = {
                'exit': result.returncode == code,
                'stdout': result.stdout == (raw if out_kind == 'raw' else ''),
                'stderr': (error_text in result.stderr) if error_text else result.stderr == '',
            }
            input_record = {'raw': raw} if len(raw) < 4096 else {
                'recipe': {'tool_name':'Write','file_path':str(ordinary),
                           'content_repeat_character':'x','content_repeat_count':1024*1024+2048,
                           'json_separators':[',',':']},
                'bytes':len(raw.encode()),'sha256':sha256(raw.encode())
            }
            report['cases'].append({
                'id':case_id,'input':input_record,'env_override':override,
                'expected':{'exit':code,'stdout_kind':out_kind,'stderr_contains':error_text},
                'actual':{'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},
                'checks':checks,'expectation_matched':all(checks.values()),
            })
        report['fixture_checks'] = {
            'regular_files_unchanged':all(sha256(Path(p).read_bytes())==h for p,h in initial.items()),
            'allowed_new_path_remains_absent':not new.exists(),
            'dangling_symlink_unchanged':dangling.is_symlink() and os.readlink(dangling)==str(root/'missing.js'),
        }
    report['source_after'] = verify_sources(source)
    report['all_expectations_matched'] = all(c['expectation_matched'] for c in report['cases'])
    report['all_fixture_checks_matched'] = all(report['fixture_checks'].values())
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report['all_expectations_matched'] and report['all_fixture_checks_matched'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
