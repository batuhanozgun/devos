# E05 — Executed configuration guard / runner evidence

**Executed once:** 2026-09-18T04:49:24.591128+00:00, Linux / Node v22.16.0 / Python 3.13.5. Exact platform is in `results.json`. **Subprocess exit:** 0. **Campaign stderr:** empty (`stderr.txt`). Sixteen predeclared expectations matched; all fixture invariants matched. This describes hook-decision behavior, not a complete installed-system security result.

## Scope and inputs

`python probe.py <exact-source-root>` runs original `run-with-flags.js` with the pinned hook ID and profile list. Four source files are verified by Git blob before and after:

| Path | Pinned blob |
|---|---|
| scripts/hooks/config-protection.js | 2da5358c2f2e7711194580df96241cf9d55d1979 |
| scripts/lib/hook-flags.js | 69d3f25d6ba5d49acdebed943352674f87caa5c3 |
| scripts/hooks/run-with-flags.js | 9f6de372212d5c3ba20502b5e05711431f1a0053 |
| scripts/hooks/pretooluse-visible-output.js | dc48119099f6206e6011174a62ad9912d7af9a25 |

No target doubles or library installation. Files came from connector text and were byte-verified after raw-network DNS failure. One transcription error in the wrapper's diagnostic was caught and repaired before execution. This was not a full checkout or an executed outer plugin bootstrap.

All target paths, configs and the dangling symlink were synthetic temporary fixtures. A clean explicit environment pointed HOME/USERPROFILE to a temporary directory and plugin/config paths to this fixture. No real host, model, credential, external service or user configuration was used. No tool write was carried out: hook exit zero does not itself create/change a file. All existing fixture contents and the dangling link remained unchanged; the new allowed pathname remained absent.

## Results

C00 ordinary file: 0. C01 existing protected: 2. C02 identical content: 2. C03 absent protected: 0. C04 dangling protected symlink: 2. C05 multipurpose pyproject: 0. C06 malformed JSON: 0. C07 oversized ordinary event/standard: 2. C08 oversized/minimal: 0. C09 protected/minimal: 0. C10 hook-ID exclusion: 0. C11 dry-run: 0 plus preview. C12 non-string path: 0 plus runner error. C13 disabled ECC configuration: 0. C14 explicit enabled override: 2. C15 invalid profile: 2 via fallback.

See PLAN for expected output conditions and results.json for each exact stdout/stderr/check. The invalid-input case is not a demonstrated valid-host bypass. ENOENT/symlink and admission distinctions are tested; EACCES/EPERM, all filename variants, filesystem races, alternate writers, full native registration and host timeout behavior are not.

## Integrity and recovery

Prospective PLAN SHA-256: `d3c58cf3dbb7faaf31da04efaab3beece4841cbbc080f9805f7f5008968f8d3b`.
Runner SHA-256: `66e342e528a33008f06180543d589ef92a334f50dfa960669ad11d8d2a779eee`.
Exact 15,950-byte results stdout SHA-256: `76b143e595519c8c556e8027dd7307d4a13437d2bd5265bd06fbdcca4c13f99a`.

Oversized ASCII inputs are represented losslessly by a repeat recipe, exact temporary pathname, JSON separators, byte length and SHA-256. Every actual output is retained without truncation. The runner encodes the same recipe. No post-result criteria were changed and E01–E04 were not rerun.

For deliberate replication only, recover the four exact source paths from the named ECC pin into a source root and run probe.py against that root. Do not rerun merely to recover the completed research. `results.json` and this readable summary already preserve the outcome.
