# E05 — Configuration guard and runner boundary probe

Prepared before execution on 2026-09-18. ECC pin: `8321021c54d670126ce3b2969d5deb880b4b0c2a`. U06-A/Q07a.

## Question and tested boundary

Does the registered inner runner preserve a configuration guard's refusal, and which conditions produce no blocking verdict instead? Exercise the exact `run-with-flags.js` → `hook-flags.js` / `config-protection.js` path, including its original `pretooluse-visible-output.js` dependency. These four files must match their pinned Git blobs before and after the run. No target mocks, edits or external packages.

This is not an actual Claude tool write, full plugin-bootstrap invocation, native-host permission test, OS containment test or malicious-user campaign. All input events are synthetic. All files are generated under a temporary directory; the source fixture is partial, not an installed ECC system. No user configuration, credentials, paid model or network is involved.

## Predeclared contrasts and expectations

| ID | Input/configuration contrast | Expected inner runner result |
|---|---|---|
| C00 | Ordinary source-file write event | exit 0, exact input passthrough |
| C01 | Write event for an existing protected config | exit 2, empty stdout, blocking reason |
| C02 | Same protected file and byte-identical proposed content | still exit 2: no semantic/no-op test |
| C03 | Protected filename absent | exit 0; the guard does not create it |
| C04 | Protected filename is a dangling symlink | exit 2; missing target is not absent directory entry |
| C05 | Existing pyproject.toml with linter-related content | exit 0; intentional multipurpose-file exclusion |
| C06 | Malformed JSON | exit 0, input passthrough; no successful check inferred |
| C07 | Oversized ordinary-file input in active standard profile | exit 2, empty stdout; truncation checked before target classification |
| C08 | Same oversized input with minimal profile | exit 0, empty stdout; guard not admitted |
| C09 | Existing protected file with minimal profile | exit 0, passthrough |
| C10 | Existing protected file with explicit hook-ID exclusion | exit 0, passthrough |
| C11 | Existing protected file with dry-run enabled | exit 0, passthrough, preview rather than real guard verdict |
| C12 | Valid JSON but non-string file_path causing a guard exception | exit 0, passthrough, runner error diagnostic; robustness case, not a valid host exploit |
| C13 | Managed ECC hook config disabled, no enabled env override | exit 0, passthrough |
| C14 | Same managed config with explicit enabled env override | exit 2; ECC config precedence is not host managed-policy authority |
| C15 | Existing protected file, invalid profile value | exit 2 via default standard profile |

Oracle: exact exit code, stdout (empty or original input) and a case-specific stderr substring. Also verify all pre-created fixture files are unchanged and the allowed new path stays absent. Permission to continue is not measured by exit 0: other host gates may still reject. No arbitrary error is called a product vulnerability.

Keep every case, complete outputs, source identities, command, environment selection, platform and prospective plan/runner hashes. Oversized ASCII input may be represented losslessly by its generation recipe, byte count and digest; never silently truncate its output. No post-result expectation changes. E01–E04 and upstream tests are not rerun. A matching expectation characterizes a predicate; it is not task quality or whole-system security acceptance.
