# U04 — Exact executable evidence

Recorded run: 2026-09-11. Primary: NousResearch/hermes-agent@c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a.
The repository companion SPEC.md was stored as Git blob ee17ae74098f941b70e07bcf496d6d9be0206892 before execution.

Contents: complete raw observations (evidence/RESULT.json), stdout/stderr, probe.py, INPUTS.json,
full heartbeat.py, manual Kanban selection and the upstream MIT licence. The original results are
immutable evidence. This archive is not a full Hermes checkout or product installation.

## Reproduction in an isolated local Python environment

Extract regular files into a new directory and inspect probe.py and source/ before execution.
Run `python probe.py --output fresh-result.json > fresh-stdout.txt 2> fresh-stderr.txt`.
Do not overwrite evidence/RESULT.json or claim a second run is independent merely because it ran again.
Only the standard library is required; no provider/account/service is contacted. The probe denies
network/process-launch audit events. It imports the full heartbeat module only after comparing its
Git blob identity, and binds the surrounding goals DB accessor to a temporary SQLite adapter.
The selected Kanban function has a local identity guard, NOT full-parent byte/AST verification.
Heartbeat's clock and the Kanban judge/task/run/block callbacks are synthetic. No actual Kanban DB,
Hermes SessionDB, driver, profile, worker process, gateway, OS termination or model is executed.

15 groups and three negative controls matched the predeclared discriminators. They establish only
these mechanical boundaries; they do not measure semantic work quality or whole-product safety.
The set_meta failure in stderr is intentionally injected H04 evidence, not an unreported setup error.
