#!/usr/bin/env python3
"""U04 bounded diagnostic. No model/network/process calls. See committed SPEC.md.

Kanban is a manual function selection with deterministic state callbacks.
Heartbeat is a Git-identity-verified full module; its goals DB accessor is a
fixture backed by a real temporary SQLite key/value table, NOT Hermes SessionDB.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import logging
from pathlib import Path
import sqlite3
import sys
import tempfile
from types import ModuleType, SimpleNamespace
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
PIN = 'c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a'
HEARTBEAT_BLOB = 'd3f440d9ed2035505b0bdfbe7d6d57dec926317f'
SELECTION_SHA256 = '8905267346ccb530a8eb6c85697f989b5f21a893db1d62eb651f533bdaf77827'


def identity(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}


def audit(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event in {'os.system', 'os.exec', 'os.fork', 'os.posix_spawn'}:
        raise PermissionError('U04 forbids network/process activity: '+event)


def verify_heartbeat(data):
    if identity(data)['git_blob'] != HEARTBEAT_BLOB:
        raise ValueError('full heartbeat source Git identity mismatch')


def load_selection(text=None):
    original = (ROOT/'source/kanban_goal_selection.py').read_bytes()
    if identity(original)['sha256'] != SELECTION_SHA256:
        raise ValueError('manual selection local identity mismatch')
    ns = {'__name__':'u04_kanban_selection'}
    exec(compile(text if text is not None else original, 'source/kanban_goal_selection.py', 'exec'), ns)
    return ns


def exercise(ns=None, *, initial='running', verdicts=('continue',), max_turns=4,
             block_mode='accept', during_judge=None, during_turn=None,
             parse_failed=False, transport_failed=False, status_error=False, turn_error=False):
    ns = ns or load_selection()
    state = {'status':initial}
    trace, prompts, blocks, logs = [], [], [], []
    counts={'judge':0,'status':0,'turn':0}
    def status():
        counts['status'] += 1
        trace.append({'status':state['status']})
        if status_error:
            raise OSError('synthetic status-reader failure')
        return state['status']
    def judge(goal, response):
        counts['judge'] += 1
        if counts['judge'] > 50:
            raise RuntimeError('fixture runaway guard')
        if during_judge:
            during_judge(state, counts['judge'])
        v = verdicts[min(counts['judge']-1,len(verdicts)-1)]
        trace.append({'judge':v,'state_after':state['status'],'input_response':response})
        return v,'synthetic:'+v,parse_failed,{'seconds':600} if v=='wait' else None,transport_failed
    def turn(prompt):
        counts['turn']+=1
        prompts.append(prompt)
        trace.append({'turn_called_with_status':state['status']})
        if turn_error:
            raise RuntimeError('synthetic turn callback failure')
        if during_turn:
            during_turn(state, counts['turn'])
        return 'synthetic response '+str(counts['turn'])
    def block(reason):
        blocks.append(reason)
        if block_mode == 'raise':
            raise OSError('synthetic block-write failure')
        if block_mode == 'reject':
            return False
        state['status']='blocked'
        return True
    ns['judge_goal']=judge
    result=ns['run_kanban_goal_loop'](task_id='fixture-task',goal_text='synthetic bounded goal',
        run_turn=turn,task_status_fn=status,block_fn=block,max_turns=max_turns,
        first_response='synthetic first response',log=logs.append)
    return {'result':result,'state':state,'counts':counts,'prompts':prompts,'blocks':blocks,'trace':trace,'logs':logs}


def oracle_superseded(o):
    return o['result']['outcome']=='stopped' and o['counts']['judge']==0 and o['counts']['turn']==0


def oracle_finalize(o):
    return (o['result']['outcome']=='blocked_budget' and o['counts']['turn']==1
            and len(o['blocks'])==1 and o['result']['reason']=='judged done, never finalized')


class MetaDB:
    def __init__(self,path):
        self.conn=sqlite3.connect(path,isolation_level=None)
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('CREATE TABLE state_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        self.fail_write=False
        self.operations=[]
    def get_meta(self,key):
        row=self.conn.execute('SELECT value FROM state_meta WHERE key=?',(key,)).fetchone()
        self.operations.append({'op':'get','key':key,'found':row is not None})
        return row[0] if row else None
    def set_meta(self,key,value):
        self.operations.append({'op':'set','key':key,'injected_failure':self.fail_write})
        if self.fail_write:
            raise OSError('synthetic set_meta failure')
        self.conn.execute('INSERT INTO state_meta VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))
    def snapshot(self):
        return {key:json.loads(value) for key,value in self.conn.execute('SELECT key,value FROM state_meta ORDER BY key')}
    def close(self):
        self.conn.close()


def heartbeat_env(path):
    data=(ROOT/'source/heartbeat.py').read_bytes()
    verify_heartbeat(data)
    db=MetaDB(path)
    fake_goals=ModuleType('hermes_cli.goals')
    fake_goals._get_session_db=lambda:db
    fake_goals._warn_dropped_write=lambda *a:None
    package=ModuleType('hermes_cli'); package.__path__=[]
    package.goals=fake_goals
    sys.modules['hermes_cli']=package
    sys.modules['hermes_cli.goals']=fake_goals
    name='u04_heartbeat'
    spec=importlib.util.spec_from_file_location(name,ROOT/'source/heartbeat.py')
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    clock={'now':1000.0}
    mod.time=SimpleNamespace(time=lambda:clock['now'])
    return mod,db,clock


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'evidence/RESULT.json')
    args=parser.parse_args()
    sys.addaudithook(audit)
    logging.basicConfig(level=logging.DEBUG,format='%(name)s %(levelname)s %(message)s')
    results=[]
    def record(cid,expected,obs,matched):
        results.append({'id':cid,'expected':expected,'observed':obs,'matched':bool(matched)})
        print(cid, 'MATCH' if matched else 'MISMATCH', flush=True)
    outcomes={'done':'completed_by_worker','blocked':'blocked_by_worker',
              'review':'review_requested_by_worker','changes_requested':'changes_requested_by_reviewer'}
    obs={s:exercise(initial=s) for s in outcomes}
    record('G01','All four terminal states bypass judge/turn',obs,
           all(o['result']['outcome']==outcomes[s] and o['counts']['judge']==0 and o['counts']['turn']==0 for s,o in obs.items()))
    o=exercise(verdicts=('continue','done'),during_turn=lambda s,n:s.update(status='done') if n==2 else None)
    record('G02','Continue then finalize nudge then terminal status',o,
        o['result']['outcome']=='completed_by_worker' and o['result']['turns_used']==3 and len(o['prompts'])==2
        and o['prompts'][0].startswith('[Continuing') and o['prompts'][1].startswith('[The work looks complete'))
    o=exercise(max_turns=1)
    record('G03','First response counts; no extra turn at budget one',o,o['counts']['turn']==0 and len(o['blocks'])==1 and o['result']['turns_used']==1)
    obs={m:exercise(max_turns=1,block_mode=m) for m in ('reject','raise')}
    record('G04','Block result is not a durable block receipt',obs,
        all(o['state']['status']=='running' and o['result']['outcome']=='blocked_budget' for o in obs.values()))
    o=exercise(initial='superseded')
    record('G05','Ownership loss at status boundary stops before work',o,oracle_superseded(o))
    o=exercise(during_judge=lambda s,n:s.update(status='superseded'))
    record('G06','Loss during judge allows one callback before next status read',o,
        o['counts']['turn']==1 and o['result']['outcome']=='stopped'
        and any(t.get('turn_called_with_status')=='superseded' for t in o['trace']))
    o=exercise(verdicts=('wait',),during_turn=lambda s,n:s.update(status='done'))
    record('G07','WAIT is converted to a continuation, not parked',o,
        o['counts']['turn']==1 and o['prompts'][0].startswith('[Continuing') and o['result']['outcome']=='completed_by_worker')
    obs={k:exercise(max_turns=6,**{k:True}) for k in ('parse_failed','transport_failed')}
    record('G08','Failure flags do not give this helper separate early-pause counters',obs,
        all(o['counts']['judge']==6 and o['counts']['turn']==5 and o['result']['outcome']=='blocked_budget' for o in obs.values()))
    o=exercise(verdicts=('done',))
    record('G09','One finalize nudge; repeated DONE without worker terminal blocks',o,oracle_finalize(o))
    obs={'status':exercise(status_error=True),'turn':exercise(turn_error=True)}
    record('G10','Reader or run errors stop without completion',obs,all(o['result']['outcome']=='stopped' for o in obs.values()))
    with tempfile.TemporaryDirectory(prefix='u04-',dir=ROOT/'evidence') as td:
        for cid in ('H01','H02','H03','H04','H05'):
            hb,db,clock=heartbeat_env(Path(td)/(cid+'.db'))
            try:
                m=hb.HeartbeatManager('fixture-session');m.set('inspect a synthetic queue',60)
                if cid=='H01':
                    clock['now']=1300
                    first=m.due_prompt();second=m.due_prompt()
                    new=hb.HeartbeatManager('fixture-session')
                    o={'first_prompt':first,'second_prompt':second,'loaded':new.state.to_json(),'disk':db.snapshot()}
                    ok=bool(first) and second is None and new.state.fire_count==1 and new.state.last_fired_at==1300
                    expected='Five missed intervals coalesce to one recorded fire'
                elif cid=='H02':
                    m.pause();clock['now']=1400;paused=m.due_prompt()
                    m.resume();just=m.due_prompt();clock['now']=1460;later=m.due_prompt()
                    m.clear();reload=hb.HeartbeatManager('fixture-session')
                    o={'paused':paused,'immediate_after_resume':just,'after_interval':later,'reload_has_heartbeat':reload.has_heartbeat(),'disk':db.snapshot()}
                    ok=paused is None and just is None and bool(later) and not reload.has_heartbeat()
                    expected='Pause suppresses; resume reanchors; clear removes active view'
                elif cid=='H03':
                    clock['now']=1060;m.due_prompt();rewind=m.abandon_fire()
                    after_rewind=db.snapshot();m.due_prompt()
                    newer=hb.HeartbeatManager('fixture-session');newer.pause();stale_rewind=m.abandon_fire()
                    o={'rewind':rewind,'after_rewind':after_rewind,'rewind_after_pause':stale_rewind,'disk':db.snapshot()}
                    ok=rewind and after_rewind['heartbeat:fixture-session']['fire_count']==0 and not stale_rewind and db.snapshot()['heartbeat:fixture-session']['status']=='paused'
                    expected='Abandon rewinds same fire but does not erase a later pause'
                elif cid=='H04':
                    clock['now']=1060;db.fail_write=True;prompt=m.due_prompt()
                    new=hb.HeartbeatManager('fixture-session')
                    o={'prompt_emitted':bool(prompt),'live':json.loads(m.state.to_json()),'reloaded':json.loads(new.state.to_json()),'disk':db.snapshot()}
                    ok=bool(prompt) and m.state.fire_count==1 and new.state.fire_count==0 and new.state.last_fired_at==0
                    expected='Write failure separates live fire from durable anchor/count'
                else:
                    a=hb.HeartbeatManager('fixture-session');b=hb.HeartbeatManager('fixture-session');clock['now']=1060
                    pa=a.due_prompt();pb=b.due_prompt()
                    o={'emitted_prompt_count':sum(bool(p) for p in (pa,pb)),'disk':db.snapshot(),'a':json.loads(a.state.to_json()),'b':json.loads(b.state.to_json())}
                    ok=bool(pa) and bool(pb) and db.snapshot()['heartbeat:fixture-session']['fire_count']==1
                    expected='Two preloaded managers are not one atomic cross-manager claim'
                o['adapter_operations']=db.operations
                record(cid,expected,o,ok)
            finally:
                db.close()
    text=(ROOT/'source/kanban_goal_selection.py').read_text()
    mutant1=text.replace('if status not in ("running", "ready"):', 'if status not in ("running", "ready", "superseded"):')
    assert mutant1!=text
    mo1=exercise(load_selection(mutant1),initial='superseded',max_turns=2)
    mutant2=text.replace('if nudged_to_finalize:', 'if False and nudged_to_finalize:')
    assert mutant2!=text
    mo2=exercise(load_selection(mutant2),verdicts=('done',),max_turns=4)
    changed_rejected=False
    try:
        verify_heartbeat((ROOT/'source/heartbeat.py').read_bytes()+b'\n')
    except ValueError:
        changed_rejected=True
    controls={'superseded_guard_mutant':{'detected':not oracle_superseded(mo1),'observed':mo1},
              'finalize_guard_mutant':{'detected':not oracle_finalize(mo2),'observed':mo2},
              'changed_full_heartbeat_rejected':changed_rejected}
    result={'kind':'EXECUTED_BOUNDED_DIAGNOSTIC_NOT_PRODUCT_VALIDATION',
        'executed_at_utc':datetime.now(timezone.utc).isoformat(),'pin':PIN,
        'python':sys.version,'platform':sys.platform,'sqlite':sqlite3.sqlite_version,
        'inputs':{str(p.relative_to(ROOT)):identity(p.read_bytes()) for p in sorted((ROOT/'source').glob('*')) if p.is_file()},
        'probe':identity(Path(__file__).read_bytes()),'spec_git_blob_before_execution':'ee17ae74098f941b70e07bcf496d6d9be0206892',
        'cases':results,'negative_controls':controls,
        'all_fixed_expectations_matched':all(c['matched'] for c in results),
        'scope':{'heartbeat_full_original_git_match':True,'kanban_manual_selection_parent_byte_AST_verified':False,
          'judge_and_kanban_state_callbacks':'synthetic','heartbeat_db':'real temporary SQLite, fixture state_meta adapter, not Hermes SessionDB',
          'clock':'synthetic','drivers_and_profiles':'not executed','model_provider_network_process':'not executed',
          'previous_suites_rerun':False,'independent_replication':False}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    assert result['all_fixed_expectations_matched'], 'fixed diagnostic expectation mismatch'
    assert controls['superseded_guard_mutant']['detected'] and controls['finalize_guard_mutant']['detected'] and changed_rejected
    print('15 groups matched; 3 bounded negative controls detected. NOT a product PASS.')


if __name__=='__main__':
    main()
