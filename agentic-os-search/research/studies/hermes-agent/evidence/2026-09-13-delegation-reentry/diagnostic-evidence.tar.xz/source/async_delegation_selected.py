# MANUAL SOURCE SELECTION, NOT A FULL UPSTREAM FILE.
# NousResearch/hermes-agent@c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a
# tools/async_delegation.py blob 99330e84f76c043293bbf7a1e1a5c531b4436bca
# Real completion helpers; injected complete_completion_delivery observes requests, not actual SQL.

def complete_event_delivery(evt: Dict[str, Any], claim_id: str) -> None:
    _event_delivery(complete_completion_delivery, evt, claim_id)


def _event_delivery(fn, evt: Dict[str, Any], claim_id: str) -> None:
    if claim_id and evt.get("type") == "async_delegation":
        fn(str(evt.get("delegation_id") or ""), claim_id)
