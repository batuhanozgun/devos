# MANUAL SOURCE SELECTION, NOT A FULL UPSTREAM FILE.
# NousResearch/hermes-agent@c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a
# tui_gateway/prompt_turn.py blob f89bbe8855da9caf31c1de7ea6717bb59ef905f0
# Function bodies transcribed from connector text; whole-parent byte/AST fidelity not verified.
# The harness supplies the upstream module's rebound globals. Thread.start is a scheduling spy;
# the nested run() worker body below is preserved but is NEVER executed by this diagnostic.

def _admit_prompt_turn(
    sid: str, session: dict, text: Any, image_paths: list[str] | None,
    queued_prompt_generation: int | None) -> tuple[list[str], Any] | None:
    """Ownership + liveness gate every turn source must cross; ``(images, agent)`` or None.
    Synthesized turns (auto-continue, wake-ups) call ``_run_prompt_submit`` directly — the
    bypass that once let a second backend run a duplicate turn."""
    # When the session already holds its lease this is a cheap dict check. See #94778.
    if (ownership_refusal := _ensure_active_session_slot(sid, session)) is not None:
        logger.info(
            "Refusing turn for session %s at _run_prompt_submit: %s",
            session.get("session_key") or sid,
            getattr(ownership_refusal, "reason", None) or "refused")
        with session["history_lock"]:
            session["running"] = False
        _emit("error", sid, {"message": str(ownership_refusal)})
        return None
    with session["history_lock"]:
        if session.get("_closing") or (
            queued_prompt_generation is not None
            and int(session.get("_queued_prompt_generation", 0)) != queued_prompt_generation):
            session["running"] = False
            return None
        images = list(session.get("attached_images", []) if image_paths is None else image_paths)
        if image_paths is None:
            session["attached_images"] = []
        inflight = session.get("inflight_turn")
        # A retained failed turn (see _fail_inflight_turn) is a stale leftover
        # by the time a new turn starts — replace it, never append onto it.
        if not isinstance(inflight, dict) or inflight.get("status") == "error":
            _start_inflight_turn(session, text)
        agent = session["agent"]
        with contextlib.suppress(Exception):
            agent.clear_interrupt()
    return images, agent


def _dispatch_followup_turn(rid, sid: str, session: dict, prompt: Any, what: str, *,
                            on_done=None, on_error=None) -> None:
    """Chain one follow-up turn (caller set ``running``); on failure run ``on_error``, log,
    release ``running``."""
    try:
        _emit("message.start", sid)
        _run_prompt_submit(rid, sid, session, prompt)
        if on_done is not None:
            on_done()
    except Exception as exc:
        if on_error is not None:
            on_error()
        _hook_failure(what, exc)
        with session["history_lock"]:
            session["running"] = False


def _run_prompt_submit(
    rid, sid: str, session: dict, text: Any, *, display_kind: str | None = None,
    display_metadata: dict | None = None, image_paths: list[str] | None = None,
    queued_prompt_generation: int | None = None,
    terminal_callback: Callable[[dict[str, Any]], None] | None = None) -> bool:
    admitted = _admit_prompt_turn(sid, session, text, image_paths, queued_prompt_generation)
    if admitted is None:
        return False
    images, agent = admitted
    # The ONE INFO record proving a prompt was accepted by THIS process; ties ui sid,
    # session_key and the agent's live session_id together.  No prompt content is logged.
    _turn_started_monotonic = time.monotonic()
    logger.info(
        # Desktop/TUI observability (#86647): this is the ONE INFO record proving a Desktop/TUI prompt was
        # accepted by THIS process, and it ties together every id a rotation-mute trace needs — the UI
        # session id, the gateway session_key, and the agent's live session_id (which compression rotates
        # independently of the other two). Before this line a Desktop request left no trace in agent.log at
        # all ("0 platform=desktop" — see #86647), so a muted window was structurally indistinguishable from
        # a request that never arrived.
        "tui prompt accepted: ui_session=%s session_key=%s agent_session_id=%s "
        "kind=%s chars=%s images=%d",
        sid, session.get("session_key") or "", getattr(agent, "session_id", "") or "",
        display_kind or "user", len(text) if isinstance(text, str) else "-", len(images))
    _emit("message.start", sid)

    def run():
        # RPC-dispatcher ContextVars do not follow onto this thread: rebind the transport
        # before any tool can commission a child (delegate_task captures it as authority).
        transport_token = bind_transport(session.get("transport"))
        runtime_session_token = _current_runtime_session_record.set(session)
        st = _TurnRun(
            session["agent"], session.pop("one_turn_model_restore", None), terminal_callback,
            receipt_committed=terminal_callback is None)
        st.marker_key = _record_turn_marker(session, text)
        goal_followup = None
        try:
            prepared = _prepare_turn_input(sid, session, st, text, images)
            if prepared is None:
                return
            prompt, run_message, cols, streamer = prepared
            _invoke_agent(
                sid, session, st, prompt, run_message, streamer, images, display_kind,
                display_metadata)
            status_note = _absorb_turn_result(
                sid, session, st, text, display_kind, display_metadata)
            payload, raw, status = _complete_turn_payload(session, st, status_note, cols)
            _emit("message.complete", sid, payload)
            goal_followup = _goal_followup_after_turn(sid, session, st.result, status, raw)
            if status == "complete":
                _after_complete_turn(sid, session, st, raw)
            # Goal judge + loop tick evaluation mutate persisted state AFTER message.complete: publish the
            # structured control snapshot now so the Desktop card never paints the pre-judge turn count.
            _publish_session_control_snapshot(sid, session, only_if_present=True)
        except Exception as e:
            _recover_turn_exception(sid, session, st, e)
        finally:
            _finish_turn(sid, session, st)
            _current_runtime_session_record.reset(runtime_session_token)
            reset_transport(transport_token)
            # A stale interim closure must not fire during a later turn.
            st.agent.interim_assistant_callback = None
            with session["history_lock"]:
                session["running"] = False
                session["last_active"] = time.time()
                if not st.error_retained:
                    _clear_inflight_turn(session)
            # Closing bookend of "tui prompt accepted" — exactly one per accepted prompt.
            # agent.session_id is re-read because compression may have rotated it (an
            # accepted/finished pair whose id changed IS a rotation trace).
            if isinstance(st.result, dict):
                status = _result_status(st.result)
            else:
                status = "error" if st.error_retained else "complete"
            logger.info(
                "tui turn finished: ui_session=%s session_key=%s agent_session_id=%s status=%s "
                "error_retained=%s duration=%.1fs%s",
                sid, session.get("session_key") or "", getattr(st.agent, "session_id", "") or "",
                status, st.error_retained, time.monotonic() - _turn_started_monotonic,
                st.error_detail)
            # Backstop for turns that never reached a terminal frame.
            if st.receipt_committed:
                _retire_turn_marker(session, st.marker_key)
                with session["history_lock"]:
                    if session.get("_active_turn_marker_key") == st.marker_key:
                        session.pop("_active_turn_marker_key", None)
                    session.pop("_hosted_room_task", None)
            session.pop("_auto_continue_scheduled", None)
            _emit_settled_session_info(sid, session, st.agent)
        _run_post_turn_followups(rid, sid, session, st.result, goal_followup)
    run_thread = threading.Thread(target=run, daemon=True)
    with _sessions_lock:
        registered = _sessions.get(sid)
        can_start = not session.get("_closing") and (registered is None or registered is session)
        if can_start:
            session["_run_thread"] = run_thread
            run_thread.start()
    if not can_start:
        with session["history_lock"]:
            session["running"] = False
    return can_start
