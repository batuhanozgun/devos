# MANUAL SOURCE SELECTION, NOT A FULL UPSTREAM FILE.
# NousResearch/hermes-agent@c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a
# tui_gateway/session_notifications.py blob 6524f3e3f11bae3becb988383fddeca635375738
# Function bodies transcribed from connector text; whole-parent byte/AST fidelity not verified.

def _notif_release_turn(session: dict) -> None:
    with session["history_lock"]:
        session["running"] = False


def _notif_submit(rid: str, sid: str, session: dict, text: str, what: str, **kwargs) -> None:
    """message.start + _run_prompt_submit for a claimed (running=True) turn; releases on failure."""
    try:
        _emit("message.start", sid)
        _run_prompt_submit(rid, sid, session, text, **kwargs)
    except Exception as exc:
        _notif_log_failure(what, exc)
        _notif_release_turn(session)
        raise


def _notif_dispatch_event(sid: str, session: dict, evt: dict, text: str) -> None:
    """Run the claimed (running=True) agent turn for one notification event."""
    from tools.async_delegation import claim_event_delivery, complete_event_delivery, release_event_delivery
    if (claim := claim_event_delivery(evt, "tui-poller")) is None:
        return
    kwargs = ({"display_kind": "async_delegation_complete", "display_metadata": _async_delegation_display_metadata(evt)}
              if evt.get("type") == "async_delegation" else {})
    try:
        _notif_submit(f"__notif__{int(time.time() * 1000)}", sid, session, text, "notification poller dispatch failed", **kwargs)
    except Exception:
        release_event_delivery(evt, claim)
        return
    complete_event_delivery(evt, claim)
