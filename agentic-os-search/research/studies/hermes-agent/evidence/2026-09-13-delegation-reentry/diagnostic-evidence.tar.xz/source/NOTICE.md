# U13 source-selection notice

These three *_selected.py files are manual selections of function bodies from Nous Research Hermes Agent, MIT-licensed, pinned at c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a. Original path/blob attribution is in each file. They are NOT the whole upstream modules. The complete original parent files were not downloaded; byte/AST fidelity to those parents has NOT been independently verified. Hashes identify the actual selections tested, not a claim of full upstream identity.

The prompt worker closure is retained in the selected _run_prompt_submit function. Its Thread is replaced by a scheduling spy that NEVER invokes the target. This experiment therefore observes source control flow and acknowledgement requests, not a running model, gateway, thread race, SessionDB or SQL update. Initial running=True is the documented caller precondition, not an executed _notif_handle_event call. Slot/claim outcomes, session replacement and the D06 exception are injected.

The harness and fixtures are project-authored diagnostics. N01/N02 mutate copies in memory; neither the preserved selections nor upstream are patched. All eight cases and both sensitivity variants ran once in one recorded invocation. No earlier failed behavioral invocation occurred. py_compile before execution was syntax checking only.

Authoritative preregistration: research/studies/hermes-agent/evidence/2026-09-13-delegation-reentry/SPEC.md at research-repository commit 2ef205a9bf13d166c15a630e4320dd73eb190fb2, blob ca736ff806d10e940b832b176a045401aeb301ad. PRE-RUN-IDENTITY.json was written before the probe invocation. Execute from the extracted root with: python checks/probe.py . Rerunning overwrites checks/RESULT.json and constitutes a NEW run; preserve the original archive first.

License: LICENSE.archived. License blob verified as 75410e73319c72cd3e991a501c5455eb78f38375; this exact match applies to the license only.
