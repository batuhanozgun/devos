"""U13 selected-source diagnostic. No Hermes install, provider, database or worker body.

Run: python checks/probe.py
The source selections are MANUAL transcriptions; their hashes identify the selection,
not full upstream-file fidelity. Expected traces are separate from tested invariants.
"""
from __future__ import annotations

import __future__
import ast
import contextlib
import hashlib
import json
import logging
from pathlib import Path
import platform
import sys
import threading
import time
from types import ModuleType, SimpleNamespace
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
INPUT = Path(__file__).with_name("INPUTS.json")
RESULT = Path(__file__).with_name("RESULT.json")
FLAGS = __future__.annotations.compiler_flag


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_source() -> dict[str, str]:
    return {p.name: p.read_text(encoding="utf-8") for p in sorted(SOURCE.glob("*_selected.py"))}


def run_case(case: dict, source: dict[str, str], mutant: str | None = None) -> dict:
    trace: list[dict] = []
    obs = {"scheduled": 0, "constructed": 0, "ack_requested": 0, "released": 0,
           "complete_wrapper_calls": 0, "submit_calls": 0, "submit_returns": [],
           "on_done": 0, "on_error": 0, "model_worker_executions": 0}
    mode = case["mode"]
    event = {"type": "async_delegation", "delegation_id": "synthetic-D", "session_key": "parent-test"}
    if mode == "interim":
        event["task_failure_notice"] = True
    session = {"session_key": "parent-test", "running": True, "history_lock": threading.RLock(),
               "agent": SimpleNamespace(session_id="parent-test", clear_interrupt=lambda: None)}
    if mode == "closing":
        session["_closing"] = True
    sessions = {"ui-test": session}

    def record(kind: str, **fields):
        trace.append({"kind": kind, **fields})

    class SchedulingSpy:
        """Only records construction/start; deliberately NEVER calls target."""
        def __init__(self, *, target, daemon):
            obs["constructed"] += 1
            self.target, self.daemon = target, daemon
            record("thread_constructed", daemon=daemon)
            if mode == "replace_before_start":
                sessions["ui-test"] = {"replacement": True}
                record("live_session_replaced")

        def start(self):
            obs["scheduled"] += 1
            record("thread_start_requested", target_not_executed=True)

    def slot(sid, current):
        refused = mode in {"ownership_refused", "followup_refused"}
        record("active_slot_checked", refused=refused)
        return "synthetic ownership refusal" if refused else None

    ns = {"__name__": "selected_gateway", "contextlib": contextlib, "time": time,
          "logger": logging.getLogger("hermes_u13_selected"),
          "threading": SimpleNamespace(Thread=SchedulingSpy), "_sessions_lock": threading.RLock(),
          "_sessions": sessions, "_ensure_active_session_slot": slot,
          "_emit": lambda kind, sid, *args: record("ui_event", event=kind),
          "_notif_log_failure": lambda what, exc: record("notification_exception", error=type(exc).__name__),
          "_hook_failure": lambda what, exc: record("followup_exception", error=type(exc).__name__),
          "_start_inflight_turn": lambda s, text: s.update(inflight_turn={"status": "running"}),
          "_async_delegation_display_metadata": lambda e: {"fixture": True}}
    prompt = source["prompt_turn_selected.py"]
    notif = source["session_notifications_selected.py"]
    if mutant == "N01":
        old = "        _run_prompt_submit(rid, sid, session, text, **kwargs)"
        new = "        if not _run_prompt_submit(rid, sid, session, text, **kwargs):\n            raise RuntimeError('synthetic refusal propagation')"
        assert notif.count(old) == 1
        notif = notif.replace(old, new)
    if mutant == "N02":
        old = '    if (claim := claim_event_delivery(evt, "tui-poller")) is None:\n        return'
        new = '    if (claim := claim_event_delivery(evt, "tui-poller")) is None:\n        _notif_release_turn(session)\n        return'
        assert notif.count(old) == 1
        notif = notif.replace(old, new)
    exec(compile(prompt, "prompt_turn_selected.py", "exec", flags=FLAGS), ns)
    exec(compile(notif, "session_notifications_selected.py", "exec", flags=FLAGS), ns)
    submit = ns["_run_prompt_submit"]

    def submit_observer(*args, **kwargs):
        obs["submit_calls"] += 1
        if mode == "submit_exception":
            raise RuntimeError("injected scheduling exception")
        value = submit(*args, **kwargs)
        obs["submit_returns"].append(value)
        record("submit_returned", value=value)
        return value

    ns["_run_prompt_submit"] = submit_observer
    fake_tools, ad = ModuleType("tools"), ModuleType("tools.async_delegation")
    fake_tools.__path__ = []
    fake_tools.async_delegation = ad

    def durable_ack(delegation_id, claim):
        obs["ack_requested"] += 1
        record("durable_ack_requested", delegation_id=delegation_id, claim=claim, sql_executed=False)
        return True  # fixture return, NOT a database result

    ad.complete_completion_delivery = durable_ack
    exec(compile(source["async_delegation_selected.py"], "async_delegation_selected.py", "exec", flags=FLAGS), ad.__dict__)
    actual_complete = ad.complete_event_delivery

    def complete_observer(evt, claim):
        obs["complete_wrapper_calls"] += 1
        record("complete_wrapper_called", claim=claim)
        return actual_complete(evt, claim)

    def claim_event(evt, consumer):
        value = None if mode == "claim_refused" else "" if mode == "interim" else "synthetic-claim"
        record("claim_returned", value=value, injected=True)
        return value

    def release(evt, claim):
        obs["released"] += 1
        record("claim_release_requested", claim=claim, sql_executed=False)

    ad.complete_event_delivery = complete_observer
    ad.claim_event_delivery = claim_event
    ad.release_event_delivery = release
    sentinel = object()
    previous = {key: sys.modules.get(key, sentinel) for key in ("tools", "tools.async_delegation")}
    sys.modules.update({"tools": fake_tools, "tools.async_delegation": ad})
    try:
        if mode == "followup_refused":
            def done():
                obs["on_done"] += 1
                complete_observer(event, "synthetic-claim")
            def error():
                obs["on_error"] += 1
                release(event, "synthetic-claim")
            ns["_dispatch_followup_turn"]("rid", "ui-test", session, "synthetic result", "probe", on_done=done, on_error=error)
        else:
            ns["_notif_dispatch_event"]("ui-test", session, event, "synthetic result")
    finally:
        for key, value in previous.items():
            if value is sentinel:
                sys.modules.pop(key, None)
            else:
                sys.modules[key] = value
    obs["running"] = bool(session["running"])
    obs["invariants"] = {
        "I1_ACK_REQUIRES_SCHEDULE": "VIOLATED_IN_SELECTION" if obs["ack_requested"] and not obs["scheduled"] else "NO_VIOLATION_OBSERVED",
        "I2_CLAIM_REFUSAL_RELEASES_LOCAL_SLOT": ("VIOLATED_IN_SELECTION" if obs["running"] else "NO_VIOLATION_OBSERVED") if mode == "claim_refused" else "NOT_APPLICABLE"}
    expected = case["expected"]
    if mutant:
        expected = json.loads(INPUT.read_text())["mutants"][mutant]["expected"]
    mismatches = {k: {"expected": v, "observed": obs.get(k)} for k, v in expected.items() if obs.get(k) != v}
    return {"id": mutant or case["id"], "mode": mode, "mutant": mutant,
            "observed": obs, "expected_trace_mismatches": mismatches,
            "expected_trace_matched": not mismatches, "trace": trace}


def main() -> int:
    started = datetime.now(timezone.utc).isoformat()
    inputs = json.loads(INPUT.read_text(encoding="utf-8"))
    sources = load_source()
    for name, text in sources.items():
        ast.parse(text, filename=name)  # syntax only, not parent-source fidelity
    cases = [run_case(case, sources) for case in inputs["cases"]]
    by_id = {case["id"]: case for case in inputs["cases"]}
    mutants = [run_case(by_id[data["case"]], sources, name) for name, data in inputs["mutants"].items()]
    for m in mutants:
        base_id = inputs["mutants"][m["id"]]["case"]
        base = next(c for c in cases if c["id"] == base_id)
        m["original_violation_changed"] = m["observed"]["invariants"] != base["observed"]["invariants"]
    result = {"kind": "SELECTED_FUNCTION_COMPOSITION_DIAGNOSTIC_NOT_PRODUCT_VALIDATION",
              "started_at_utc": started, "finished_at_utc": datetime.now(timezone.utc).isoformat(),
              "python": platform.python_version(), "system": platform.system(),
              "spec_commit": inputs["spec_commit"], "spec_blob": inputs["spec_blob"],
              "input_sha256": sha(INPUT), "probe_sha256": sha(Path(__file__)),
              "source_sha256": {name: sha(SOURCE / name) for name in sources},
              "full_parent_byte_ast_fidelity_verified": False,
              "model_worker_executions": 0, "sql_executions": 0,
              "cases": cases, "mutants": mutants, "limits": inputs["limits"],
              "all_expected_traces_matched": all(c["expected_trace_matched"] for c in cases + mutants)}
    RESULT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"case_ids": [c["id"] for c in cases],
                      "ack_without_schedule": [c["id"] for c in cases if c["observed"]["invariants"]["I1_ACK_REQUIRES_SCHEDULE"] == "VIOLATED_IN_SELECTION"],
                      "claim_refusal_slot_residue": [c["id"] for c in cases if c["observed"]["invariants"]["I2_CLAIM_REFUSAL_RELEASES_LOCAL_SLOT"] == "VIOLATED_IN_SELECTION"],
                      "mutations_changed_violation": {m["id"]: m["original_violation_changed"] for m in mutants},
                      "all_expected_traces_matched": result["all_expected_traces_matched"]}, indent=2))
    return 0 if result["all_expected_traces_matched"] and all(m["original_violation_changed"] for m in mutants) else 1


if __name__ == "__main__":
    raise SystemExit(main())
