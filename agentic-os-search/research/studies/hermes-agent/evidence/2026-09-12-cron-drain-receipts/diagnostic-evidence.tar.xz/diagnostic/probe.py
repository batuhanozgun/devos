"""Bounded real-thread bridge diagnostic. No Hermes host or network is run."""
from __future__ import annotations
import asyncio
import concurrent.futures
import copy
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys
import threading
import traceback
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
EXPECTED_BLOB = '2bc558fad21eeec736c0283cb7df86304349f222'
sys.dont_write_bytecode = True

def digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def git_blob(b: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def identity_gate(b: bytes) -> None:
    if git_blob(b) != EXPECTED_BLOB:
        raise ValueError('source identity mismatch before import')

def demand(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)

def validate_case(r: dict) -> None:
    if r['id'] == 'B01':
        demand(r['receipt'] == {'receipt': 'B01'}, 'normal receipt lost')
        demand(r['file_after'] == 'B01\n', 'normal file effect missing')
        demand(r['cancel_return'] is False, 'completed future cancellation mismatch')
    elif r['id'] == 'B02':
        demand(r['timeout_observed'] is True, 'no actual timeout')
        demand(r['cancel_return'] is True, 'expected counterexample not observed')
        demand(r['file_before_cancel'] == 'B02\n', 'effect not independently observed before cancel')
        demand(r['file_after_cancel'] == 'B02\n', 'file effect changed')
        demand(r['coroutine_cancel_observed'] is True, 'task cancellation not observed')
    elif r['id'] == 'B03':
        demand(r['timeout_observed'] is True, 'no initial timeout')
        demand(r['cancel_return'] is False, 'terminal future was cancelled')
        demand(r['exception_type'] == 'RuntimeError', 'terminal error missing')
        demand(r['exception_message'] == 'B03 transport substitute failed', 'wrong terminal error')
        demand(r['file_exists'] is False, 'unexpected output file')
    else:
        raise ValueError('unknown case')

class LoopHost:
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._serve, name='u08-local-loop')
    def _serve(self):
        asyncio.set_event_loop(self.loop)
        self.loop.call_soon(self.ready.set)
        self.loop.run_forever()
    def __enter__(self):
        self.thread.start()
        demand(self.ready.wait(2), 'loop did not start')
        return self
    def __exit__(self, *_args):
        async def cleanup():
            tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
            for task in tasks:
                task.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            return len(tasks)
        try:
            asyncio.run_coroutine_threadsafe(cleanup(), self.loop).result(timeout=2)
        finally:
            self.loop.call_soon_threadsafe(self.loop.stop)
            self.thread.join(timeout=2)
            demand(not self.thread.is_alive(), 'loop thread survived cleanup')
            self.loop.close()

def append_effect(path: Path, text: str):
    with path.open('a', encoding='utf-8') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())

def run_cases(module, out: Path):
    records = []
    with LoopHost() as host:
        loop = host.loop
        for case in ('B01', 'B02', 'B03'):
            r = {'id': case, 'scope': 'actual bridge + real asyncio thread; synthetic transport/file'}
            path = out / f'{case}-effect.txt'
            try:
                if case == 'B01':
                    async def normal():
                        append_effect(path, 'B01\n')
                        return {'receipt': 'B01'}
                    f = module.safe_schedule_threadsafe(normal(), loop)
                    demand(f is not None, 'scheduling returned None')
                    r['receipt'] = f.result(timeout=2)
                    r['file_after'] = path.read_text()
                    r['cancel_return'] = f.cancel()
                elif case == 'B02':
                    effect_ready = threading.Event()
                    cancelled = threading.Event()
                    async def already_effected():
                        append_effect(path, 'B02\n')
                        effect_ready.set()
                        try:
                            await asyncio.Event().wait()
                        except asyncio.CancelledError:
                            cancelled.set()
                            raise
                    f = module.safe_schedule_threadsafe(already_effected(), loop)
                    demand(f is not None, 'scheduling returned None')
                    demand(effect_ready.wait(2), 'effect barrier missing')
                    r['file_before_cancel'] = path.read_text()
                    r['future_done_before_cancel'] = f.done()
                    r['future_running_after_coroutine_started'] = f.running()
                    r['timeout_observed'] = False
                    try:
                        f.result(timeout=0)
                    except concurrent.futures.TimeoutError:
                        r['timeout_observed'] = True
                    r['cancel_return'] = f.cancel()
                    r['coroutine_cancel_observed'] = cancelled.wait(2)
                    r['file_after_cancel'] = path.read_text()
                    r['future_cancelled'] = f.cancelled()
                else:
                    entered = threading.Event()
                    terminal = threading.Event()
                    controls = {}
                    async def delayed_failure():
                        controls['release'] = asyncio.Event()
                        entered.set()
                        await controls['release'].wait()
                        raise RuntimeError('B03 transport substitute failed')
                    f = module.safe_schedule_threadsafe(delayed_failure(), loop)
                    demand(f is not None, 'scheduling returned None')
                    f.add_done_callback(lambda _: terminal.set())
                    demand(entered.wait(2), 'failure barrier missing')
                    r['timeout_observed'] = False
                    try:
                        f.result(timeout=0)
                    except concurrent.futures.TimeoutError:
                        r['timeout_observed'] = True
                    loop.call_soon_threadsafe(controls['release'].set)
                    demand(terminal.wait(2), 'error did not settle')
                    r['cancel_return'] = f.cancel()
                    exc = f.exception(timeout=0)
                    r['exception_type'] = type(exc).__name__
                    r['exception_message'] = str(exc)
                    r['file_exists'] = path.exists()
                validate_case(r)
                r['outcome'] = 'expectation_met'
            except Exception as exc:
                r.update(outcome='expectation_failed', error=repr(exc), traceback=traceback.format_exc())
            records.append(r)
    return records, {'loop_thread_joined': not host.thread.is_alive(), 'loop_closed': host.loop.is_closed()}

def main():
    out = ROOT / 'run-01'
    out.mkdir(exist_ok=False)
    source = ROOT / 'source/async_utils.py'
    b = source.read_bytes()
    identity_gate(b)
    expected = json.loads((ROOT/'INPUTS.json').read_text())
    demand(expected['probe_sha256'] == digest(Path(__file__).read_bytes()), 'probe input mismatch')
    demand(expected['spec_sha256'] == digest((ROOT/'SPEC.md').read_bytes()), 'spec input mismatch')
    demand(expected['source_git_blob'] == git_blob(b), 'source input mismatch')
    blocked = []
    def audit(event, args):
        if event in {'socket.connect', 'socket.getaddrinfo', 'socket.bind', 'subprocess.Popen', 'os.system', 'os.posix_spawn'}:
            blocked.append(event)
            raise RuntimeError(f'forbidden diagnostic operation: {event}')
    sys.addaudithook(audit)
    spec = importlib.util.spec_from_file_location('hermes_u08_actual_bridge', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'project_calendar_date': '2026-09-12', 'python': sys.version, 'platform': list(os.uname()),
              'scope': 'full-byte-verified Hermes async bridge; no enclosing scheduler/gateway/network/SessionDB',
              'inputs': expected}
    result['cases'], result['cleanup'] = run_cases(module, out)
    negatives = []
    try:
        identity_gate(b+b'\n')
        negatives.append({'id':'N00','rejected':False})
    except ValueError as exc:
        negatives.append({'id':'N00','rejected':True,'reason':str(exc)})
    for nid, cid, key, wrong in [('N01','B02','file_before_cancel',''),('N02','B03','exception_type','NoneType')]:
        r = copy.deepcopy(next(r for r in result['cases'] if r['id']==cid))
        r[key] = wrong
        try:
            validate_case(r)
            negatives.append({'id':nid,'rejected':False})
        except AssertionError as exc:
            negatives.append({'id':nid,'rejected':True,'reason':str(exc)})
    result['negative_controls'] = negatives
    result['forbidden_audit_events'] = blocked
    from asyncio import futures as af
    runtime = {'run_coroutine_threadsafe':inspect.getsource(asyncio.run_coroutine_threadsafe),
               '_chain_future':inspect.getsource(af._chain_future),
               'concurrent_Future_cancel':inspect.getsource(concurrent.futures.Future.cancel)}
    (out/'RUNTIME-EXCERPTS.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n')
    runtime_files = {}
    for obj in (asyncio.run_coroutine_threadsafe, af._chain_future, concurrent.futures.Future.cancel):
        p=Path(inspect.getsourcefile(obj)); data=p.read_bytes()
        runtime_files[str(p)]={'sha256':digest(data),'bytes':len(data)}
    result['runtime_files'] = runtime_files
    result['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
    (out/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if all(r['outcome']=='expectation_met' for r in result['cases']) and all(n['rejected'] for n in negatives) else 1

if __name__ == '__main__':
    raise SystemExit(main())
