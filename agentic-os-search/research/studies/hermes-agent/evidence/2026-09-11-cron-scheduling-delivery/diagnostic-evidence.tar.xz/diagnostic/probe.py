"""Bounded exact-source queue diagnostic. See the pre-run SPEC for all seams."""
from __future__ import annotations
import hashlib, importlib.util, json, logging, os, platform, sqlite3, sys, tempfile, traceback, types
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/delivery_queue.py'
EXPECTED_GIT = '689fd620d6193003bbd168a0e62770a0d0306ac6'
EXPECTED_SHA = '62529e31774f414f9cda886505f0db7f291d13f566cc06982c11cba1da005c4b'
OUT = ROOT / 'raw'
OUT.mkdir(exist_ok=True)


def sha(b): return hashlib.sha256(b).hexdigest()
def git(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def demand(ok, text):
    if not ok: raise AssertionError(text)


def audit(event, args):
    if event in ('socket.connect', 'socket.connect_ex', 'subprocess.Popen', 'os.system'):
        raise RuntimeError('Network and subprocess operations are outside this diagnostic')
sys.addaudithook(audit)


def inject_module(name, **attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


def load_module(path, home, *, original=True):
    raw = path.read_bytes()
    if original and (git(raw) != EXPECTED_GIT or sha(raw) != EXPECTED_SHA):
        raise ValueError('upstream source identity mismatch before import')
    calls = {'wal': 0, 'column_check': 0, 'process_start_tag': 0, 'foreign_owner_probe': 0}
    def set_wal(conn, **kwargs):
        calls['wal'] += 1
        demand(conn.execute('PRAGMA journal_mode=WAL').fetchone()[0] == 'wal', 'WAL required for fixture')
    def column_check(conn, table, name, ddl):
        calls['column_check'] += 1
        demand(table == 'deliveries' and name == 'for_failure', 'unexpected schema seam')
        demand(name in {r[1] for r in conn.execute('PRAGMA table_info(deliveries)')}, 'not a fresh-schema case')
    def owner_probe(*args):
        calls['foreign_owner_probe'] += 1
        raise AssertionError('foreign-owner liveness must not be used in this diagnostic')
    def start_tag(pid):
        calls['process_start_tag'] += 1
        demand(pid == os.getpid(), 'only current-process claim is in scope')
        return 123456789
    inject_module('agent.redact', redact_sensitive_text=lambda s, **kw: s)
    inject_module('cron.executions', _owner_is_live=owner_probe, _process_start_time=start_tag)
    inject_module('hermes_cli.sqlite_util', add_column_if_missing=column_check)
    inject_module('hermes_constants', get_hermes_home=lambda: home)
    inject_module('hermes_time', now=lambda: datetime.now(timezone.utc))
    inject_module('hermes_state_wal', apply_wal_with_fallback=set_wal)
    name = 'u07_queue_' + home.name.replace('-', '_')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module, calls


def snap(q):
    path = q._path()
    if not path.exists(): return {'rows': [], 'tombstones': []}
    con = sqlite3.connect(path); con.row_factory = sqlite3.Row
    try:
        return {'rows': [dict(r) for r in con.execute('SELECT * FROM deliveries ORDER BY execution_id')],
                'tombstones': [dict(r) for r in con.execute('SELECT * FROM delivery_tombstones ORDER BY execution_id')]}
    finally: con.close()


def job(eid): return {'id': 'synthetic-job', 'execution_id': eid, 'deliver': 'synthetic:chat'}
def record_send(trace, calls, *, failure=False):
    def send(j, text, for_failure):
        calls.append({'job': j, 'content': text, 'for_failure': for_failure})
        trace.append({'during_callback': 'synthetic transport only', 'callback_index': len(calls)})
        if failure: raise RuntimeError('synthetic send rejection')
        return None
    return send


def D01(q, trace):
    callbacks = []
    result = q.enqueue_and_wait('e1', job('e1'), 'payload-one', timeout=0)
    s = snap(q); trace.append({'returned': result, 'snapshot': s, 'callback_count': len(callbacks)})
    demand(result is None, 'pending timeout must return no error')
    demand(s['rows'][0]['status'] == 'pending' and s['rows'][0]['content'] == 'payload-one', 'pending payload must remain durable')
    demand(not callbacks, 'no consumer was invoked')


def D02(q, trace):
    calls = []
    q.enqueue('e2', job('e2'), 'original-two', for_failure=True)
    n1 = q.drain(record_send(trace, calls))
    first = snap(q)
    repeated = q.enqueue('e2', job('e2'), 'replacement-must-not-win')
    n2 = q.drain(record_send(trace, calls))
    trace.append({'first_count': n1, 'repeat_count': n2, 'calls': calls, 'first_snapshot': first, 'repeat_result': repeated, 'final_snapshot': snap(q)})
    demand(n1 == 1 and n2 == 0 and len(calls) == 1, 'same execution must not redeliver')
    demand(calls[0]['content'] == 'original-two' and calls[0]['for_failure'] is True, 'original payload and lane must survive')
    demand(first['rows'][0]['status'] == 'delivered' and first['rows'][0]['content'] == '' and first['rows'][0]['job_json'] == '{}', 'terminal payload must be cleared')


def D03(q, trace):
    q.enqueue('e3', job('e3'), 'payload-three')
    claimed = q.claim_next()
    before = snap(q)
    result = q.enqueue_and_wait('e3', job('e3'), 'ignored', timeout=0)
    timed_out = snap(q)
    late = q._finish('e3', error=None)
    after = snap(q)
    retry = q.claim_next()
    trace.append({'claim': claimed, 'before_timeout': before, 'timeout_return': result, 'after_timeout': timed_out, 'late_finish': late, 'after_late_finish': after, 'retry_claim': retry, 'send_callbacks': 0})
    demand(bool(result), 'claimed timeout must report uncertainty')
    demand(timed_out['rows'][0]['status'] == 'unknown', 'timeout must fence claimed row unknown')
    demand(late is False and after['rows'][0]['status'] == 'unknown', 'late finish must not rewrite unknown')
    demand(retry is None, 'uncertain claimed send must not be retried')


def D04(q, trace):
    calls = []
    q.enqueue('e4', job('e4'), 'payload-four')
    q.drain(record_send(trace, calls))
    q.MAX_TERMINAL_DELIVERIES = 0
    q.recover_abandoned()  # real pruning path
    before = snap(q)
    repeated = q.enqueue('e4', job('e4'), 'resurrection-must-not-win')
    retry = q.claim_next()
    trace.append({'pruned_snapshot': before, 'repeat_result': repeated, 'retry_claim': retry, 'callback_count': len(calls), 'final_snapshot': snap(q)})
    demand(not before['rows'] and before['tombstones'][0]['terminal_status'] == 'delivered', 'terminal identity must survive pruning')
    demand(repeated['status'] == 'delivered' and retry is None and len(calls) == 1, 'tombstone must prevent resend')


def D05(q, trace):
    calls = []
    q.enqueue('e5', job('e5'), 'payload-five')
    processed = q.drain(record_send(trace, calls, failure=True))
    before = snap(q)
    again = q.drain(record_send(trace, calls))
    trace.append({'processed_count': processed, 'snapshot': before, 'next_count': again, 'callback_count': len(calls)})
    demand(processed == 1 and before['rows'][0]['status'] == 'failed', 'processed count must remain distinct from delivered count')
    demand(before['rows'][0]['error'] == 'RuntimeError: synthetic send rejection', 'synthetic error must be retained')
    demand(again == 0 and len(calls) == 1, 'failed terminal request must not auto retry')


def D06(q, trace):
    calls = []
    q.enqueue('e6', job('e6'), 'payload-six')
    con = sqlite3.connect(q._path())
    try:
        con.execute("""CREATE TRIGGER fail_terminal_update BEFORE UPDATE ON deliveries
                       WHEN NEW.status IN ('delivered','failed')
                       BEGIN SELECT RAISE(ABORT, 'injected terminal SQLite write fault'); END""")
        con.commit()
    finally: con.close()
    caught = None
    try: q.drain(record_send(trace, calls))
    except sqlite3.IntegrityError as exc: caught = {'class': type(exc).__name__, 'text': str(exc)}
    before = snap(q); active = sorted(q._ACTIVE_DELIVERIES)
    recovered = q.recover_abandoned()
    after = snap(q)
    second = q.drain(record_send(trace, calls))
    trace.append({'caught': caught, 'after_failed_finish': before, 'active_set': active, 'recovered': recovered, 'after_recovery': after, 'second_drain_count': second, 'calls': calls})
    demand(caught is not None and len(calls) == 1, 'injected actual SQLite fault must propagate after callback')
    demand(before['rows'][0]['status'] == 'delivering' and not active, 'failed outcome write must leave durable delivering but clear local active marker')
    demand(recovered == 1 and after['rows'][0]['status'] == 'unknown', 'same-process orphan must become unknown')
    demand(second == 0 and len(calls) == 1, 'uncertain result must not resend')


CASES = [D01, D02, D03, D04, D05, D06]


def run_case(fn, path=SOURCE, *, original=True, label=None):
    label = label or fn.__name__
    trace = []
    result = {'id': label, 'oracle': fn.__name__, 'trace': trace}
    with tempfile.TemporaryDirectory(prefix='u07-queue-') as temp:
        q, seams = load_module(path, Path(temp), original=original)
        try:
            fn(q, trace)
            result['outcome'] = 'expectation_met'
        except BaseException as exc:
            result.update(outcome='expectation_failed', exception=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        finally:
            result['dependency_seams'] = seams
            demand(seams['foreign_owner_probe'] == 0, 'scope expanded to foreign owner probe')
            if q._path().exists():
                src = sqlite3.connect(q._path()); dst = sqlite3.connect(OUT / (label + '.db'))
                try: src.backup(dst)
                finally: dst.close(); src.close()
    return result


def main():
    logging.basicConfig(level=logging.WARNING)
    raw = SOURCE.read_bytes()
    result = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'full byte-matched cron delivery_queue module; real temporary SQLite; dependency seams and synthetic send; NOT full Hermes runtime',
              'python': sys.version, 'platform': list(os.uname()), 'sqlite': sqlite3.sqlite_version,
              'identities': {'source_git_blob': git(raw), 'source_sha256': sha(raw), 'spec_sha256': sha((ROOT/'SPEC.md').read_bytes()), 'probe_sha256': sha(Path(__file__).read_bytes())},
              'cases': [run_case(fn) for fn in CASES], 'negative_controls': []}
    bad = ROOT/'source/identity_bad.py'; bad.write_bytes(raw+b'\n# identity negative control\n')
    try:
        load_module(bad, ROOT/'never-used', original=True)
        result['negative_controls'].append({'id': 'N00', 'rejected_before_import': False})
    except ValueError as exc:
        result['negative_controls'].append({'id': 'N00', 'rejected_before_import': True, 'error': str(exc), 'mutant_sha256': sha(bad.read_bytes())})
    text = raw.decode()
    old1 = '            return ""\n        conn.execute(\n            """UPDATE deliveries SET status=\'unknown\''
    new1 = '            return "synthetic mutation: pending deadline error"\n        conn.execute(\n            """UPDATE deliveries SET status=\'unknown\''
    demand(text.count(old1) == 1, 'N01 mutation site must be unique')
    old2 = "WHERE execution_id=? AND status='delivering'\n                 AND owner_process_id=? AND owner_pid=?"
    new2 = "WHERE execution_id=?\n                 AND owner_process_id=? AND owner_pid=?"
    demand(text.count(old2) == 1, 'N02 mutation site must be unique')
    for ident, fn, old, new in [('N01', D01, old1, new1), ('N02', D03, old2, new2)]:
        path = ROOT/'source'/f'{ident}_mutant.py'; path.write_text(text.replace(old,new), encoding='utf-8')
        observed = run_case(fn, path, original=False, label=ident)
        result['negative_controls'].append({'id': ident, 'mutant_sha256': sha(path.read_bytes()), 'oracle_rejected': observed['outcome'] == 'expectation_failed', 'observation': observed})
    result['ended_at_utc'] = datetime.now(timezone.utc).isoformat()
    (ROOT/'RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'cases':[(c['id'],c['outcome']) for c in result['cases']], 'negative_controls':[(c['id'],c.get('oracle_rejected',c.get('rejected_before_import'))) for c in result['negative_controls']]}, indent=2))
    return 0 if all(c['outcome']=='expectation_met' for c in result['cases']) and all(c.get('oracle_rejected',c.get('rejected_before_import')) for c in result['negative_controls']) else 1

if __name__ == '__main__': raise SystemExit(main())
