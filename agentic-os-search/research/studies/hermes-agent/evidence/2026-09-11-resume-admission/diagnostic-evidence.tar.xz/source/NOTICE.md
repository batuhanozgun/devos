# Upstream source notice

`turn_lease.py` is the complete, unchanged `gateway/turn_lease.py` from NousResearch/hermes-agent commit c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a, Git blob 1f65614e66e748ec61573aced3fa48b57ee20281 (9,190 bytes). Included for reproducibility under the accompanying MIT LICENSE, copyright Nous Research. The diagnostic/probe.py is new research code. N01/N02 are explicitly labelled negative-control-only derived mutants, not upstream versions. No other upstream runtime/dependencies are bundled or represented as executed.
