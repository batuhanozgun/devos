"""U06-L: bounded exact-source asyncio registry diagnostics; no Hermes host or DB."""
from __future__ import annotations
import asyncio
import hashlib
import json
import logging
from pathlib import Path
import platform
import sys
import traceback
import types
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source/turn_lease.py'
EXPECTED_BLOB = '1f65614e66e748ec61573aced3fa48b57ee20281'

def blob(b: bytes) -> str:
    return hashlib.sha1(f'blob {len(b)}\0'.encode() + b).hexdigest()

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def checked_source(b: bytes) -> bytes:
    if blob(b) != EXPECTED_BLOB:
        raise ValueError('upstream source identity mismatch before import')
    return b

def load(b: bytes, name: str):
    module = types.ModuleType(name)
    module.__file__ = str(SOURCE) if name == 'u06_original' else f'<{name}>'
    sys.modules[name] = module
    exec(compile(b, module.__file__, 'exec'), module.__dict__)
    return module

def demand(condition, message: str) -> None:
    if not condition:
        raise AssertionError(message)

async def barrier(predicate):
    for _ in range(1000):
        if predicate():
            return
        await asyncio.sleep(0)
    raise AssertionError('event-loop barrier did not become ready')

async def L01(m, t):
    r = m.SessionTurnLeaseRegistry()
    a = await r.acquire('shared', owner_key='route-A', generation=1)
    t.append('A admitted')
    async def second():
        b = await r.acquire('shared', owner_key='route-B', generation=2)
        t.append('B admitted')
        return b
    pending = asyncio.create_task(second())
    try:
        await barrier(lambda: r._leases['shared'].pending_acquires == 1)
        demand(not pending.done(), 'B entered before A released')
        t.append('B waiting')
        demand(r.release(a), 'A release failed'); t.append('A released')
        b = await pending
        demand(t == ['A admitted', 'B waiting', 'A released', 'B admitted'], 'bad admission order')
        demand(r.release(b), 'B release failed'); t.append('B released')
    finally:
        if not pending.done():
            pending.cancel()
            await asyncio.gather(pending, return_exceptions=True)
        r.release(a)

async def L02(m, t):
    r = m.SessionTurnLeaseRegistry()
    a = await r.acquire('held', owner_key='owner', generation=1)
    entered, raised = False, False
    try:
        try:
            await r.acquire('held', owner_key='waiter', generation=2, timeout=0.02)
            entered = True
            t.append('post-acquire synthetic body entered')
        except m.TurnLeaseTimeoutError as e:
            raised = True
            t.append({'exception':type(e).__name__, 'session':e.session_id, 'generation':e.generation})
        demand(raised and not entered, 'timeout must raise before subsequent body')
        demand(r._leases['held'].holder is a and r._leases['held'].lock.locked(), 'timeout changed holder')
        demand(r._leases['held'].pending_acquires == 0, 'timeout left waiter count')
        t.append('original holder and lock retained; zero waiters')
    finally:
        r.release(a)

async def L03(m, t):
    r = m.SessionTurnLeaseRegistry()
    a = await r.acquire('parent', owner_key='A', generation=1)
    demand(r.rebind(a, 'child'), 'normal rebind failed')
    demand(r._leases['child'] is r._leases['parent'] and a.session_id == 'child', 'alias not shared')
    t.append('parent/child share held lease')
    async def waiter(sid, label):
        token = await r.acquire(sid, owner_key=label, generation=2, timeout=1)
        t.append(label + ' admitted')
        return token
    b_task = asyncio.create_task(waiter('parent', 'B'))
    await barrier(lambda: r._leases['parent'].pending_acquires == 1)
    c_task = asyncio.create_task(waiter('child', 'C'))
    try:
        await barrier(lambda: r._leases['parent'].pending_acquires == 2)
        demand(not b_task.done() and not c_task.done(), 'alias waiter entered held region')
        r.release(a); t.append('A released')
        b = await b_task
        demand(not c_task.done(), 'C overlapped B')
        r.release(b); t.append('B released')
        c = await c_task
        r.release(c); t.append('C released')
        demand(t == ['parent/child share held lease', 'A released', 'B admitted', 'B released', 'C admitted', 'C released'], 'alias order mismatch')
    finally:
        for task in (b_task,c_task):
            if not task.done(): task.cancel()
        await asyncio.gather(b_task,c_task,return_exceptions=True)
        r.release(a)

async def L04(m, t):
    r = m.SessionTurnLeaseRegistry()
    old = await r.acquire('old', owner_key='A', generation=1)
    new = await r.acquire('new', owner_key='B', generation=2)
    old_lease,new_lease = r._leases['old'],r._leases['new']
    try:
        result = r.rebind(old, 'new')
        t.append({'rebind_result':result, 'token_sid':old.session_id, 'maps_same':r._leases['old'] is r._leases['new']})
        demand(result is False, 'conflicting target rebind must return False')
        demand(old.session_id == 'old', 'old token moved despite conflict')
        demand(r._leases['old'] is old_lease and r._leases['new'] is new_lease, 'live target overwritten')
        demand(old_lease.holder is old and new_lease.holder is new, 'holder changed')
    finally:
        r.release(old); r.release(new)

async def L05(m, t):
    r = m.SessionTurnLeaseRegistry()
    a = await r.acquire('id', owner_key='A', generation=1)
    lookalike = m.TurnLeaseToken('id','A',1)
    demand(not r.release(lookalike), 'value-equal nonowner token released lock')
    demand(r._leases['id'].holder is a, 'lookalike changed holder')
    r.release(a)
    b = await r.acquire('id', owner_key='B', generation=2)
    demand(not r.release(a) and r._leases['id'].holder is b, 'stale release removed successor')
    t.append('lookalike rejected; stale repeated release rejected; successor retained')
    r.release(b)

async def L06(m, t):
    r = m.SessionTurnLeaseRegistry(max_entries=1)
    a = await r.acquire('A', owner_key='routeA', generation=1)
    pending = asyncio.create_task(r.acquire('A',owner_key='waiter',generation=2,timeout=1))
    await barrier(lambda:r._leases['A'].pending_acquires==1)
    pending.cancel()
    try:
        await pending
    except asyncio.CancelledError:
        t.append('waiter cancelled')
    demand(r._leases['A'].pending_acquires == 0 and r._leases['A'].holder is a, 'cancel corrupted owner/count')
    b = await r.acquire('B',owner_key='routeB',generation=1)
    demand(r._leases['A'].holder is a and r._leases['B'].holder is b and len(r._leases)==2, 'capacity evicted live entry')
    t.append({'max_entries':1,'live_entries':len(r._leases)})
    r.release(a); r.release(b)
    c=await r.acquire('C',owner_key='routeC',generation=1)
    demand(set(r._leases)=={'C'}, 'idle entries not evicted at next acquire')
    t.append('idle cleanup on next acquire')
    r.release(c)

async def L07(m,t):
    r1,r2=m.SessionTurnLeaseRegistry(),m.SessionTurnLeaseRegistry()
    a=await r1.acquire('same',owner_key='r1',generation=1)
    b=await r2.acquire('same',owner_key='r2',generation=1)
    demand(a is not None and b is not None and r1._leases['same'] is not r2._leases['same'], 'unexpected cross-registry fence')
    t.append('two independent registries both admit same SID; no DB or process restart exercised')
    r1.release(a);r2.release(b)

async def run_case(name, fn, module):
    trace=[]
    try:
        await asyncio.wait_for(fn(module,trace),timeout=3)
        return {'id':name,'outcome':'expectation_met','trace':trace}
    except BaseException as e:
        return {'id':name,'outcome':'expectation_failed','trace':trace,'exception':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}

async def main():
    source=checked_source(SOURCE.read_bytes())
    spec=(ROOT/'diagnostic/SPEC.md').read_bytes()
    pre=json.loads((ROOT/'diagnostic/PRE-RUN.json').read_text())
    demand(sha(spec)==pre['spec_sha256'],'SPEC changed since pre-run')
    original=load(source,'u06_original')
    result={'started_at_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),
            'scope':'exact full process-local asyncio lease module; no actual DB, gateway host, model, OS restart or upstream suite',
            'identities':{'source_git_blob':blob(source),'source_sha256':sha(source),'spec_sha256':sha(spec),'probe_sha256':sha(Path(__file__).read_bytes())},
            'cases':[],'negative_controls':[]}
    for fn in (L01,L02,L03,L04,L05,L06,L07):
        result['cases'].append(await run_case(fn.__name__,fn,original))
    try:
        checked_source(source+b'\n')
        result['negative_controls'].append({'id':'N00','rejected_before_import':False})
    except ValueError as e:
        result['negative_controls'].append({'id':'N00','rejected_before_import':True,'message':str(e)})
    text=source.decode()
    old='''            raise TurnLeaseTimeoutError(
                session_id, owner_key=owner_key, generation=generation, wait_seconds=wait) from None'''
    demand(text.count(old)==1,'timeout mutation site not unique')
    mutant1=text.replace(old,'            return None').encode()
    old2='        if existing is not None and existing is not lease and not existing.idle:'
    demand(text.count(old2)==1,'rebind mutation site not unique')
    mutant2=text.replace(old2,'        if False:  # U06 negative-control-only mutant').encode()
    for label,b,fn in [('N01',mutant1,L02),('N02',mutant2,L04)]:
        (ROOT/f'diagnostic/{label}-mutant.py').write_bytes(b)
        outcome=await run_case(fn.__name__,fn,load(b,'u06_'+label))
        result['negative_controls'].append({'id':label,'mutant_sha256':sha(b),'target':fn.__name__,'oracle_rejected':outcome['outcome']=='expectation_failed','observation':outcome})
    result['ended_at_utc']=datetime.now(timezone.utc).isoformat()
    (ROOT/'diagnostic/RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    good=all(c['outcome']=='expectation_met' for c in result['cases'])
    negatives=all(c.get('rejected_before_import',c.get('oracle_rejected',False)) for c in result['negative_controls'])
    print(json.dumps({'cases':len(result['cases']),'expectations_met':good,'negative_controls_discriminated':negatives,'source_git_blob':blob(source)}))
    return 0 if good and negatives else 1

if __name__=='__main__':
    logging.basicConfig(level=logging.WARNING)
    raise SystemExit(asyncio.run(main()))
