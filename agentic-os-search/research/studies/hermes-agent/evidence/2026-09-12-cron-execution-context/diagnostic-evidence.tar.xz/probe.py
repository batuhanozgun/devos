from __future__ import annotations
import copy, datetime, hashlib, importlib.util, json, os, pathlib, sys, types
ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT / 'source' / 'cron' / 'scheduler_prompt.py'
EXPECTED = '91d673649d6dca8ba3120d10671a8966e67a01ce'
BASE_PROMPT = 'U10_CURRENT_TASK'
violations = []
def audit(event, args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.posix_spawn','os.posix_spawnp','os.fork','os.exec'}:
        violations.append(event)
        raise RuntimeError('disallowed: '+event)
sys.addaudithook(audit)
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
# This is intentionally not a fake scheduler. Only unused module names and the
# output-root provider are supplied; the native selector owns its whole decision.
cron = types.ModuleType('cron'); cron.__path__=[]; sys.modules['cron']=cron
for n in ['scheduler','scheduler_delivery','scheduler_script','jobs']:
    m=types.ModuleType('cron.'+n);sys.modules['cron.'+n]=m;setattr(cron,n,m)
cron.scheduler_delivery._cron_job_origin_log_suffix=lambda job:''
ht=types.ModuleType('hermes_time');ht.now=lambda:datetime.datetime.now(datetime.timezone.utc);sys.modules['hermes_time']=ht
current_root=None
cron.jobs.get_cron_output_dir=lambda:current_root

def load(data, name, mutant=False):
    if not mutant and blob(data)!=EXPECTED: raise ValueError('source identity mismatch')
    m=types.ModuleType(name);m.__file__=str(SOURCE);sys.modules[name]=m
    exec(compile(data,str(SOURCE),'exec'),m.__dict__)
    return m

def record_file(p):
    b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'mtime_ns':p.stat().st_mtime_ns}

def put(root, name, text, mtime):
    p=root/'aa11'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8');os.utime(p,ns=(mtime,mtime));return p

def make_fixtures():
    inputs={}
    good='# Cron Job: probe\n\n## Response\nU10_OLDER_SUBSTANTIVE\n'
    for cid in ['C01','C02','C03','C04','C05','C06']:
        d=ROOT/'fixtures'/cid;d.mkdir(parents=True,exist_ok=True)
        files=[]
        if cid!='C06': files.append(put(d,'older.md',good,1700000000000000000))
        latest={
          'C01':'# Cron Job: probe\n\n## Response\nU10_LATEST_SUBSTANTIVE\n',
          'C02':'# Cron Job: probe\n\n**Mode:** monitor\n**Status:** no_change (agent run suppressed)\n',
          'C03':'  \n\t\n',
          'C04':'# Cron Job: probe\n\n## Prompt\n'+'U10_PROMPT_FILL '*600+'\n\n## Response\nU10_FINAL_ANSWER\n',
          'C05':'# Cron Job: probe (FAILED)\n\n## Error\nU10_FAILURE_DETAIL\n',
        }.get(cid)
        if latest is not None: files.append(put(d,'latest.md',latest,1700000010000000000))
        inputs[cid]={'root':str(d.relative_to(ROOT)),'files':[record_file(p) for p in files]}
    return inputs

def observation(m, cid, label):
    global current_root
    current_root=ROOT/'fixtures'/cid
    job={'id':'aa11','context_from':['self']} if cid!='C06' else {'id':'aa11','context_from':['bb22']}
    original=copy.deepcopy(job)
    prompt,injected=m._inject_context_from(job,BASE_PROMPT)
    out=ROOT/'outputs'/label;out.mkdir(parents=True,exist_ok=True)
    f=out/(cid+'.txt');f.write_text(prompt,encoding='utf-8')
    return {'injected':injected,'job_unchanged':job==original,'output':record_file(f),'text':prompt}

def oracle(cid,o):
    text=o['text']; common=o['job_unchanged']
    if cid=='C01': return common and o['injected'] and 'U10_LATEST_SUBSTANTIVE' in text and 'U10_OLDER_SUBSTANTIVE' not in text and "Your previous run's output" in text
    if cid=='C02': return common and o['injected'] and 'no_change (agent run suppressed)' in text and 'U10_OLDER_SUBSTANTIVE' not in text
    if cid=='C03': return common and not o['injected'] and text==BASE_PROMPT
    if cid=='C04': return common and o['injected'] and 'U10_FINAL_ANSWER' not in text and '[... output truncated ...]' in text
    if cid=='C05': return common and o['injected'] and 'U10_FAILURE_DETAIL' in text and 'U10_OLDER_SUBSTANTIVE' not in text
    if cid=='C06': return common and not o['injected'] and text==BASE_PROMPT
    raise ValueError(cid)

def compact(o):return {k:v for k,v in o.items() if k!='text'}

def main():
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    source=SOURCE.read_bytes();spec=(ROOT/'SPEC.md').read_bytes()
    original=load(source,'u10_native_prompt')
    fixtures=make_fixtures();(ROOT/'INPUTS.json').write_text(json.dumps(fixtures,indent=2)+'\n')
    observations={}
    for cid in fixtures:
        o=observation(original,cid,'original');observations[cid]={**compact(o),'expectation_met':oracle(cid,o)}
    negative={}
    try:load(source+b'\n# identity mutation\n','u10_identity_reject')
    except ValueError:negative['N00']={'identity_rejected_before_import':True}
    else:negative['N00']={'identity_rejected_before_import':False}
    for nid,cid,old,new in [('N01','C01',b'reverse=True,',b'reverse=False,'),('N02','C04',b'_MAX_CONTEXT_CHARS = 8000',b'_MAX_CONTEXT_CHARS = 16000')]:
        assert source.count(old)==1
        data=source.replace(old,new);p=ROOT/'mutants';p.mkdir(exist_ok=True);(p/(nid+'.py')).write_bytes(data)
        m=load(data,'u10_'+nid,mutant=True);o=observation(m,cid,nid)
        negative[nid]={'source_sha256':sha(data),'case':cid,'original_oracle_rejected':not oracle(cid,o),'observation':compact(o)}
    after={cid:{**row,'files':[record_file(ROOT/item['path']) for item in row['files']]} for cid,row in fixtures.items()}
    inputs_unchanged=(fixtures==after)
    result={'unit':'U10','kind':'full-source native selector / synthetic root / actual local files','upstream_ref':'c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a','source_git_blob':blob(source),'source_sha256':sha(source),'source_bytes':len(source),'spec_sha256':sha(spec),'probe_sha256':sha(pathlib.Path(__file__).read_bytes()),'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'cases':observations,'negative_controls':negative,'fixtures_unchanged':inputs_unchanged,'audit_violations':violations,'whole_product_run':False,'actual_model_request_observed':False,'independent_replication':False}
    passed=all(o['expectation_met'] for o in observations.values()) and inputs_unchanged and not violations and negative['N00']['identity_rejected_before_import'] and all(negative[n]['original_oracle_rejected'] for n in ['N01','N02'])
    result['predeclared_expectations_met']=passed
    (ROOT/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'passed': passed, 'cases': {k: v['expectation_met'] for k, v in observations.items()}}))
    if not passed:raise SystemExit(1)
if __name__=='__main__':main()
