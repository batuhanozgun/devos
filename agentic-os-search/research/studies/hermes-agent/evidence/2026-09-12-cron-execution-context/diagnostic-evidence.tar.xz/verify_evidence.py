"""Read-only verification of recorded U10 evidence. Does not execute target/probe."""
from pathlib import Path
import hashlib, json
R=Path(__file__).resolve().parent

def digest(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def main():
 result=json.loads((R/'RESULT.json').read_text())
 source=(R/'source/cron/scheduler_prompt.py').read_bytes()
 assert gitblob(source)==result['source_git_blob']=='91d673649d6dca8ba3120d10671a8966e67a01ce'
 assert len(source)==result['source_bytes']==16049
 assert digest(source)==result['source_sha256']
 assert digest((R/'SPEC.md').read_bytes())==result['spec_sha256']
 assert digest((R/'probe.py').read_bytes())==result['probe_sha256']
 assert digest((R/'RESULT.json').read_bytes())=='cdf30b7cb1b599b3b87d2d757bfaa26ed93508669f0c26f0b6c639b95b0537f7'
 assert gitblob((R/'source/LICENSE').read_bytes())=='75410e73319c72cd3e991a501c5455eb78f38375'
 inputs=json.loads((R/'INPUTS.json').read_text());count=0
 def check_record(row):
  b=(R/row['path']).read_bytes()
  assert len(b)==row['bytes'] and digest(b)==row['sha256'],row['path']
 for case,row in inputs.items():
  for record in row['files']:check_record(record);count+=1
  if row['files']:
   assert row['files'][0]['mtime_ns']<row['files'][-1]['mtime_ns']
 for row in result['cases'].values():check_record(row['output'])
 for nid in ['N01','N02']:
  row=result['negative_controls'][nid]
  assert digest((R/'mutants'/f'{nid}.py').read_bytes())==row['source_sha256']
  assert row['original_oracle_rejected']
  check_record(row['observation']['output'])
 assert count==10 and len(result['cases'])==6
 assert result['fixtures_unchanged'] and not result['audit_violations']
 assert (R/'stderr.log').stat().st_size==0
 assert 'SyntaxError' in (R/'attempt-00/stderr.log').read_text()
 assert not list((R/'attempt-00').glob('RESULT*'))
 # Recorded timestamps are provenance; tar extraction need not retain nanosecond metadata.
 print(json.dumps({'target_executed_by_this_check':False,'raw_identity_links':True,'input_files':count,'output_records':8,'failed_parse_attempt_preserved':True,'recorded_timestamps_not_reinterpreted':True},indent=2))
if __name__=='__main__':main()
