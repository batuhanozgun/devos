"""Bounded selected-function/real-SQLite diagnostic. Run: python probe.py --output RESULT.json"""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import json
import platform
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
PIN = 'c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a'
EXPECTED = {
    'selected/schema.sql':'e13247ad65e127e91cf7fc13c489b0f5089ba00243372003337bc81d9f78ad8d',
    'selected/transactions.py':'7c6f3df4eb9aa129663e20ccd902ce78a802789b44ce223f8faba3f628b0e6db',
    'selected/transitions.py':'2a8790857ed8f9c8c699badf73c5ee3138934e90ce091158f570ec4304f9b5e6',
    'SPEC.md':'b6f7be06a5f048b5319049b3e4c718a8777930b6fe7d3cfd2f710ef9a908e2e8',
}

def digest(b):
    return hashlib.sha256(b).hexdigest()

def verify_blob(name, data):
    if digest(data) != EXPECTED[name]:
        raise ValueError(f'local input identity rejected: {name}')

def inputs():
    result = {}
    for name in EXPECTED:
        data = (ROOT/name).read_bytes()
        verify_blob(name, data)
        result[name] = data.decode('utf-8')
    return result

def prohibited(*a, **kw):
    raise RuntimeError('network/process launch prohibited by this offline probe')

def connect(path):
    c = sqlite3.connect(path, isolation_level=None, timeout=3)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA busy_timeout=3000')
    return c

def fixture_bindings(c):
    # Each omitted dependency is explicit. We do not silently import product modules.
    def task(conn, tid):
        row = conn.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone()
        return SimpleNamespace(**dict(row)) if row else None
    def no_cards(conn, tid, cards, preview):
        if cards:
            raise RuntimeError('created_cards validation outside this diagnostic')
        return []
    def no_dangling(conn, tid, **kw):
        # Only fixtures without leaked runs; do NOT emulate actual dangling-run recovery.
        row = conn.execute('SELECT status,current_run_id FROM tasks WHERE id=?',(tid,)).fetchone()
        if row and row['status']=='ready' and row['current_run_id'] is not None:
            raise RuntimeError('dangling run outside selected fixture')
    def clear(conn, tid):
        with c.write_txn(conn):
            conn.execute('UPDATE tasks SET consecutive_failures=0,last_failure_error=NULL WHERE id=?',(tid,))
    c.get_task = task
    c._resolve_claim_ttl_seconds = lambda ttl: max(1,int(ttl)) if ttl is not None else 900
    c._claimer_id = lambda: 'fixture:no-process'
    c._reclaim_dangling_run = no_dangling
    c._fire_task_hook = lambda *a, **kw: None
    c._gate_created_cards = no_cards
    c._merge_completion_prose_artifacts = lambda conn, tid, metadata, **kw: metadata
    c._stage_completion_artifacts = lambda *a: None
    c._flag_phantom_prose_refs = lambda *a: None
    c._clear_failure_counter = clear
    c.recompute_ready = lambda conn: 0  # child promotion is SOURCE-READ, not this execution's endpoint
    c._cleanup_workspace = lambda *a: None
    c._synthesize_ended_run = lambda *a, **kw: (_ for _ in ()).throw(RuntimeError('manual zero-run synthesis outside fixture'))
    c._REVIEW_APPROVED_NOTE = 'Review approved without additional evidence.'
    c._terminate_reclaimed_worker = lambda *a, **kw: {'termination_attempted':False,'terminated':False,'fixture':'no worker process'}
    c._retry_status_for_run = lambda *a: 'ready'  # these cases use implementation lane, never review


def load(sel, *, stale_mutant=False, rollback_mutant=False):
    tx_src = sel['selected/transactions.py']
    tr_src = sel['selected/transitions.py']
    if stale_mutant:
        old = ('        if expected_run_id is not None:\n'
               '            sql += " AND current_run_id = ?"\n'
               '            params = (*params, int(expected_run_id))\n')
        assert tr_src.count(old)==1
        tr_src = tr_src.replace(old,'')
    if rollback_mutant:
        old='conn.execute("ROLLBACK")'
        assert tx_src.count(old)==2
        tx_src=tx_src.replace(old,'conn.execute("COMMIT")')
    tx = SimpleNamespace()
    exec(compile(tx_src,'selected/transactions.py','exec'),tx.__dict__)
    tx._kb = SimpleNamespace(_assert_not_delegated_child_mutation=lambda:None)
    tx._check_file_length_invariant = lambda conn:None
    c = SimpleNamespace()
    exec(compile(tr_src,'selected/transitions.py','exec'),c.__dict__)
    c.write_txn=tx.write_txn
    fixture_bindings(c)
    return c


def seed(conn, tid, status='ready', assignee='fixture-profile'):
    conn.execute('INSERT INTO tasks(id,title,status,assignee,created_at) VALUES(?,?,?,?,?)',
                 (tid,'synthetic task '+tid,status,assignee,int(time.time())))

def snapshot(conn, tid):
    return {
      'task':dict(conn.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone()),
      'runs':[dict(r) for r in conn.execute('SELECT * FROM task_runs WHERE task_id=? ORDER BY id',(tid,))],
      'events':[dict(r) for r in conn.execute('SELECT * FROM task_events WHERE task_id=? ORDER BY id',(tid,))],
    }

def completion_events(s):
    return [e for e in s['events'] if e['kind']=='completed']

def fresh_snapshot(path, tid):
    c=connect(path)
    try: return snapshot(c,tid)
    finally: c.close()

def run_case(case_id, sel, fn, *, stale_mutant=False, rollback_mutant=False):
    with tempfile.TemporaryDirectory(prefix='hermes-u03-') as d:
        path=Path(d)/'fixture.db'; conn=connect(path)
        try:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.executescript(sel['selected/schema.sql'])
            c=load(sel,stale_mutant=stale_mutant,rollback_mutant=rollback_mutant)
            obs, matched=fn(c,conn,path)
            return {'id':case_id,'observed':obs,'matched':bool(matched)}
        except Exception as e:
            return {'id':case_id,'error':f'{type(e).__name__}: {e}','matched':False}
        finally: conn.close()

def normal(c,conn,path):
    seed(conn,'n'); t=c.claim_task(conn,'n',claimer='fixture:a'); rid=t.current_run_id
    first=c.complete_task(conn,'n',summary='synthetic outcome; not evaluated for quality',expected_run_id=rid)
    s=fresh_snapshot(path,'n')
    retry=c.complete_task(conn,'n',summary='retry',expected_run_id=rid)
    after=fresh_snapshot(path,'n')
    return {'first':first,'duplicate':retry,'durable':s,'unchanged_on_duplicate':s==after}, (
        first is True and retry is False and s==after and s['task']['status']=='done'
        and s['task']['current_run_id'] is None and len(s['runs'])==1
        and s['runs'][0]['outcome']=='completed' and s['runs'][0]['ended_at'] is not None
        and len(completion_events(s))==1)

def contest(c,conn,path):
    seed(conn,'race'); barrier=threading.Barrier(2)
    def claim(label):
        local=connect(path)
        try:
            barrier.wait(timeout=3)
            t=c.claim_task(local,'race',claimer=label)
            return {'claimer':label,'won':t is not None,'run_id':t.current_run_id if t else None}
        finally: local.close()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        result=list(pool.map(claim,['fixture:a','fixture:b']))
    s=fresh_snapshot(path,'race')
    return {'attempts':result,'durable':s}, sum(v['won'] for v in result)==1 and len(s['runs'])==1 and len(s['events'])==1

def stale(c,conn,path):
    seed(conn,'stale'); a=c.claim_task(conn,'stale',claimer='fixture:a').current_run_id
    released=c.reclaim_task(conn,'stale',reason='controlled owner replacement')
    b=c.claim_task(conn,'stale',claimer='fixture:b').current_run_id
    before=fresh_snapshot(path,'stale')
    old=c.complete_task(conn,'stale',summary='late A',expected_run_id=a)
    after=fresh_snapshot(path,'stale')
    current=c.complete_task(conn,'stale',summary='current B',expected_run_id=b)
    final=fresh_snapshot(path,'stale')
    return {'run_A':a,'run_B':b,'reclaimed':released,'late_A_return':old,'B_preserved':before==after,
            'current_B_return':current,'durable':final}, (
        released is True and a!=b and old is False and before==after and current is True
        and final['runs'][0]['outcome']=='reclaimed' and final['runs'][1]['outcome']=='completed'
        and len(completion_events(final))==1)

def parents(c,conn,path):
    seed(conn,'parent','running'); seed(conn,'child'); conn.execute('INSERT INTO task_links VALUES(?,?)',('parent','child'))
    denied=c.claim_task(conn,'child',claimer='fixture:a')
    demoted=fresh_snapshot(path,'child')
    conn.execute("UPDATE tasks SET status='done' WHERE id='parent'")
    conn.execute("UPDATE tasks SET status='ready' WHERE id='child'")
    run=c.claim_task(conn,'child',claimer='fixture:a').current_run_id
    conn.execute("UPDATE tasks SET status='ready' WHERE id='parent'")
    done=c.complete_task(conn,'child',summary='parent reopened',expected_run_id=run)
    s=fresh_snapshot(path,'child')
    return {'claim_denied':denied is None,'demotion':demoted,'completion_return':done,'durable':s}, (
      denied is None and demoted['task']['status']=='todo' and not demoted['runs']
      and done is False and s['task']['status']=='running' and s['runs'][0]['ended_at'] is None)

def inflight_fault(c,conn,path):
    seed(conn,'pre'); rid=c.claim_task(conn,'pre',claimer='fixture:a').current_run_id
    before=fresh_snapshot(path,'pre')
    def fault(*args): raise OSError('synthetic artifact staging failure')
    c._stage_completion_artifacts=fault
    error=None
    try: c.complete_task(conn,'pre',summary='proposed',metadata={},expected_run_id=rid)
    except OSError as e: error=str(e)
    after=fresh_snapshot(path,'pre')
    c._stage_completion_artifacts=lambda *args:None
    retry=c.complete_task(conn,'pre',summary='retry',metadata={},expected_run_id=rid)
    return {'exception':error,'rollback_preserved_all_rows':before==after,'after_failure':after,
            'retry':retry}, error is not None and before==after and retry is True

def postcommit_fault(c,conn,path):
    seed(conn,'post'); rid=c.claim_task(conn,'post',claimer='fixture:a').current_run_id
    def fault(*args): raise OSError('synthetic post-commit child-promotion failure')
    c.recompute_ready=fault; error=None
    try: c.complete_task(conn,'post',summary='proposed',expected_run_id=rid)
    except OSError as e: error=str(e)
    s=fresh_snapshot(path,'post')
    c.recompute_ready=lambda *args:0
    retry=c.complete_task(conn,'post',summary='retry',expected_run_id=rid)
    return {'exception':error,'durable_after_exception':s,'retry':retry}, (
      error is not None and s['task']['status']=='done' and s['runs'][0]['outcome']=='completed'
      and len(completion_events(s))==1 and retry is False)

def no_expected(c,conn,path):
    seed(conn,'operator'); c.claim_task(conn,'operator',claimer='fixture:a')
    accepted=c.complete_task(conn,'operator',summary='operator-style low-level call',expected_run_id=None)
    s=fresh_snapshot(path,'operator')
    return {'return':accepted,'durable':s}, accepted is True and s['task']['status']=='done'

def nested(c,conn,path):
    seed(conn,'nested'); rid=c.claim_task(conn,'nested',claimer='fixture:a').current_run_id
    conn.execute('BEGIN IMMEDIATE'); err=None
    try: c.complete_task(conn,'nested',summary='not yet durable',expected_run_id=rid)
    except RuntimeError as e: err=str(e)
    finally: conn.execute('ROLLBACK')
    conn.execute('BEGIN IMMEDIATE')
    with c.write_txn(conn,allow_nested=True):
        conn.execute("UPDATE tasks SET result='inner release is not durable' WHERE id='nested'")
    conn.execute('ROLLBACK')
    s=fresh_snapshot(path,'nested')
    return {'nested_rejected':err,'after_outer_rollback':s}, (
      err is not None and s['task']['status']=='running' and s['task']['result'] is None
      and len(completion_events(s))==0)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--output',default='RESULT.json'); args=parser.parse_args()
    dest=Path(args.output)
    if dest.exists(): raise FileExistsError(f'will not overwrite original result: {dest}')
    sel=inputs(); socket.create_connection=prohibited; socket.socket=prohibited; subprocess.Popen=prohibited
    cases=[run_case(f'K{i:02}',sel,fn) for i,fn in enumerate(
      [normal,contest,stale,parents,inflight_fault,postcommit_fault,no_expected,nested],1)]
    stale_m=run_case('MUTANT_RUN_GUARD_REMOVED',sel,stale,stale_mutant=True)
    rollback_m=run_case('MUTANT_ROLLBACK_COMMITS',sel,inflight_fault,rollback_mutant=True)
    identity_rejected=False
    try: verify_blob('selected/transitions.py',(ROOT/'selected/transitions.py').read_bytes()+b'\n# mutation')
    except ValueError: identity_rejected=True
    out={'kind':'SELECTED_KANBAN_TRANSITIONS_REAL_SQLITE_NOT_FULL_APPLICATION',
         'executed_at_utc':datetime.now(timezone.utc).isoformat(),'pin':PIN,
         'python':sys.version,'sqlite':sqlite3.sqlite_version,'platform':sys.platform,
         'inputs_sha256':EXPECTED,'probe_sha256':digest(Path(__file__).read_bytes()),
         'parent_full_byte_or_AST_fidelity':'NOT VERIFIED; manual selections, not full modules',
         'cases':cases,'negative_controls':{'local_mutation_rejected':identity_rejected,
            'stale_guard_mutant_detected':not stale_m['matched'],'rollback_mutant_detected':not rollback_m['matched'],
            'mutant_observations':[stale_m,rollback_m]},
         'all_expectations_matched':all(x['matched'] for x in cases),
         'not_executed':['product init/migrations','actual worker/dispatcher process','real model/provider',
                         'actual artifact copying','real OS termination','full authorization/profile stack',
                         'review/goal judge','automatic retry/watchdog','notification delivery'],
         'previous_suites_rerun':False,'independent_replication':False}
    dest.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'cases':[(r['id'],r['matched']) for r in cases],
       'negative_controls':{k:v for k,v in out['negative_controls'].items() if k!='mutant_observations'}},ensure_ascii=False))
    if not out['all_expectations_matched'] or not identity_rejected or stale_m['matched'] or rollback_m['matched']:
        return 1
    return 0

if __name__=='__main__':
    raise SystemExit(main())
