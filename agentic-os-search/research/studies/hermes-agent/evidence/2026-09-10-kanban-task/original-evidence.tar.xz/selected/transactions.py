"""Manual source selection, NOT a full upstream module.
Parent: hermes_cli/kanban_db_connect.py@c4a5deeffa959f8ebc891e02c5bcf767aff1dd2a
Parent blob: 9067dfd0e571bc02cb02859c80fb4a551b8f55ce; selected 1100--EOF.
Imports/constants reproduced here; _kb and file-invariant callback supplied by harness.
"""
import contextlib
import random
import secrets
import sqlite3
import time

_BUSY_MAX_RETRIES = 5
_BUSY_RETRY_MIN_S = 0.020
_BUSY_RETRY_MAX_S = 0.150


def _is_busy_error(exc: BaseException) -> bool:
    return isinstance(exc, sqlite3.OperationalError) and (
        "database is locked" in str(exc).lower()
        or "database is busy" in str(exc).lower()
    )


def _execute_boundary_with_retry(conn: sqlite3.Connection, sql: str) -> None:
    for attempt in range(_BUSY_MAX_RETRIES + 1):
        try:
            conn.execute(sql)
            return
        except sqlite3.OperationalError as exc:
            if not _is_busy_error(exc) or attempt == _BUSY_MAX_RETRIES:
                raise
            time.sleep(random.uniform(_BUSY_RETRY_MIN_S, _BUSY_RETRY_MAX_S))


@contextlib.contextmanager
def write_txn(conn: sqlite3.Connection, *, allow_nested: bool = False):
    """IMMEDIATE write transaction; a claim CAS inside is atomic — at most one
    concurrent writer succeeds.

    Nesting is an explicit opt-in (``allow_nested=True`` → savepoint; otherwise
    a loud ``RuntimeError``). Only composition primitives (``create_task``,
    ``add_comment``) opt in — helpers with post-commit side effects
    (``complete_task`` & co.) must never run under an open outer transaction,
    since those side effects would fire while the outer txn can still roll back.
    """
    _kb._assert_not_delegated_child_mutation()
    if getattr(conn, "in_transaction", False):
        if not allow_nested:
            raise RuntimeError(
                "write_txn: already inside a transaction. Nested composition "
                "must opt in explicitly with write_txn(conn, allow_nested=True) "
                "(savepoint semantics; the inner RELEASE is not durable until "
                "the outer transaction commits)."
            )
        savepoint = f"hermes_nested_{secrets.token_hex(8)}"
        conn.execute(f"SAVEPOINT {savepoint}")
        try:
            yield conn
        except Exception:
            with contextlib.suppress(sqlite3.OperationalError):
                conn.execute(f"ROLLBACK TO {savepoint}")
                conn.execute(f"RELEASE {savepoint}")
            raise
        else:
            conn.execute(f"RELEASE {savepoint}")
        return

    _execute_boundary_with_retry(conn, "BEGIN IMMEDIATE")
    try:
        yield conn
    except Exception:
        with contextlib.suppress(sqlite3.OperationalError):
            conn.execute("ROLLBACK")
        raise
    else:
        try:
            _execute_boundary_with_retry(conn, "COMMIT")
        except Exception:
            with contextlib.suppress(sqlite3.OperationalError):
                conn.execute("ROLLBACK")
            raise
        _check_file_length_invariant(conn)
