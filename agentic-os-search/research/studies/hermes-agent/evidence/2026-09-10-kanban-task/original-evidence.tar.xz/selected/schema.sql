-- Research fixture DDL projection, NOT the whole upstream SCHEMA_SQL/init/migrations.
-- Fields used by the selected transition consumers retain upstream column types/defaults.
CREATE TABLE tasks (
 id TEXT PRIMARY KEY,title TEXT NOT NULL,body TEXT,assignee TEXT,status TEXT NOT NULL,
 priority INTEGER DEFAULT 0,created_by TEXT,created_at INTEGER NOT NULL,
 started_at INTEGER,completed_at INTEGER,workspace_kind TEXT NOT NULL DEFAULT 'scratch',
 workspace_path TEXT,claim_lock TEXT,claim_expires INTEGER,result TEXT,
 consecutive_failures INTEGER NOT NULL DEFAULT 0,worker_pid INTEGER,last_failure_error TEXT,
 max_runtime_seconds INTEGER,last_heartbeat_at INTEGER,current_run_id INTEGER,
 current_step_key TEXT,max_retries INTEGER,block_kind TEXT,block_recurrences INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE task_links (parent_id TEXT NOT NULL,child_id TEXT NOT NULL,PRIMARY KEY(parent_id,child_id));
CREATE TABLE task_events (id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT NOT NULL,run_id INTEGER,kind TEXT NOT NULL,payload TEXT,created_at INTEGER NOT NULL);
CREATE TABLE task_runs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT NOT NULL,profile TEXT,step_key TEXT,
 status TEXT NOT NULL,claim_lock TEXT,claim_expires INTEGER,worker_pid INTEGER,max_runtime_seconds INTEGER,
 last_heartbeat_at INTEGER,started_at INTEGER NOT NULL,ended_at INTEGER,outcome TEXT,summary TEXT,metadata TEXT,error TEXT
);
