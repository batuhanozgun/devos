# Harness repair, not changed acceptance criteria

The first invocation ran the cases but failed before serializing RESULT.json: `platform.platform()` attempted `uname -p` through subprocess, correctly rejected by the probe's process-launch guard. No first-run case result is claimed. The exact first script is `probe.initial.py` (SHA-256 `b039fb491580c0814b70ddb391935af638158a90241f0233f1a0695aaccd8482`); its stdout/stderr are retained.

One metadata-only change replaced `platform.platform()` with `sys.platform`, which makes no subprocess call. SPEC.md, selected functions, schema, expected observations and mutants were not changed. The corrected probe was freshly executed; RESULT.json belongs only to that corrected run. No upstream fault was inferred from this harness issue.
