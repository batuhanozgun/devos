# Reproduce the bounded K run

Extract this archive into a new temporary directory. With Python 3.10+ and its stdlib SQLite, run `python probe.py --output RESULT.rerun.json`. Do not overwrite `RESULT.json`. No package installation is needed. The probe uses temporary SQLite files and blocks network/process launch during the cases.

This is NOT the full Hermes application. `selected/` contains manually transcribed control-flow/SQL selections and a reduced DDL fixture, not full upstream modules. Outside dependencies are explicitly bound in `fixture_bindings()`. See SPEC.md, INPUT-IDENTITIES.json and the containing repository's SOURCES.md. The fixed hashes prove local input identity only, not source-parent fidelity or independent validation.

The original first invocation could not serialize its results because platform metadata tried to launch a subprocess and the guard refused it. `HARNESS-REPAIR.md`, `probe.initial.py`, `stdout.initial.txt` and `stderr.initial.txt` preserve that failure and repair. The corrected invocation owns RESULT.json/stdout.txt/stderr.txt. No first-run case result is inferred.
