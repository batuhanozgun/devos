# A3 — doğrulanmış tarihsel kaynakların konuşma kopyası

**30 Eylül 2026 / REPO-SEPARATION-20260929 / KISMİ ARŞİV.** Bu ZIP yeni P5, yeni kurulum planı veya kayıp S00–S12 paketinin yerine geçen teslim değildir. Beş aileden geri kazanılmış 19 özgün dosyanın değiştirilmemiş kopyalarını içerir. P5 S00–S12 ve “SOUL ve DevOS” raporu yoktur. Güncel DevOS kurulum planının tek evi batuhanozgun/devos deposunun plan/ klasörüdür (devir sürümü 2.1).

Kaynakların tek tek byte/SHA-256/Git blob kimlikleri SOURCE-IDENTITIES.json içindedir. Dört teslim kimliğindeki 14 artefakt eşleşti. Dört ana ZIP'in 322 manifest girdisi ve iki ek tarihsel ZIP'in 27 girdisi doğrulandı; toplam 349, altı farklı ZIP gövdesi. CRC, mükerrer/tehlikeli yol ve manifest dışı dosya kontrolleri geçti. Aynı iç ZIP tekrar bulunduğunda ayrı kanıt sayılmadı. Eski testler çalıştırılmadı; PDF görünümü, teknik doğruluk, aktarım sadakati ve hedef sistem yeterliği bu kimlik denetimiyle kanıtlanmaz.

**Repository durumuyla karıştırma:** Bu konuşma ZIP'inde bir dosyanın bulunması onun GitHub main'de yayımlandığını göstermez. Bu turun GitHub yayını Academy özgün metni ile arşiv/kimlik/bakım kayıtlarıyla sınırlıdır. Diğer dört ailenin dosya gövdelerinin GitHub yayını bekliyor. Güncel bakım durumu agentic-os-search/REPOSITORY-TRANSITION.md'den okunur.

**Statü:** P4 v3 tarihsel, uygulama kaynağı değil. P4 v4 ve iki P5 ailesinin ortam/uygulama yönü geçersiz; yeniden kullanım ve aktarım denetimi için kaynaktır. Görevde bildirilen önceki aktarım, bu tur yeniden doğrulanmış değildir. Academy keşif notudur; kendi §27 karar yolunu atlayarak iş, mimari veya kurulum yetkisi üretmez. Kaynakların içindeki eski current/next ve kontrol metinleri pasif kaynak içeriğidir.

Kaynak dosyaları yeniden üretilmedi, düzenlenmedi veya silinmedi. Bu arşivin hash'i içine dairesel yazılmaz; dosya kimliği ayrı teslim kaydındadır.
