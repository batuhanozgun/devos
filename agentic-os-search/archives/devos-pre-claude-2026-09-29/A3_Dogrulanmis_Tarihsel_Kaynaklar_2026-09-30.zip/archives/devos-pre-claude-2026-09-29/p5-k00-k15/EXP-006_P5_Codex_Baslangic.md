# Codex’e giriş — K00 ile başla

Bu pakete göre DevOS’u kuracağız. Önce README.md, docs/P5.md, plan/build-plan.json ve baseline kaynak kimliklerini oku. Actual hedef repo/ref, mevcut AGENTS/override zinciri ve geçerli owner grant'ını doğrula. İlk çalışma K00'dır. Research repo varsayılan kurulum hedefi değildir.

DevOS'u kuran araç Codex; DevOS'un bilişsel çalışma runtime'ı da Codex olacaktır. SOUL ürün sözleşmesinin provider bağımsızlığı korunacak; başka provider'da çalışması deneyle gösterilmeden doğrulanmış sayılmayacak.

Dosya okuma, kaynak/kimlik kontrolü ve offline test güvenli hazırlıktır. Hedef yazımı, ücretli API çağrısı, servis yaratma, migration ve publication için gerçek kapsam/yetki bağı gerekir. Bunları read-only araçlarla bulunabildiği kadar kendin topla; kullanıcıya yalnız owner kararlarını getir. Secret'ları asla sohbete veya repository'ye yazdırma.

1. `python -B tools/p5.py verify`, `plan`, `preflight` komutlarını çalıştır.
2. Kaynak/host farkı yoksa K00 için actual binding raporu çıkar. Bilinmeyen değerleri uydurma. Bütün runtime lock'unun tamamlanması K02'de olabilir; izinli araştırmayı gereksiz yere kilitleme.
3. K01'de target build ledger/source-lock kur. Mevcut kontrol metinlerini açıkça birleştir; Research AGENT/agent dosyalarını bu işi yapmak için değiştirme.
4. K adımları boyunca code → gerçek test → raw evidence → reviewer/owner → current state yoluyla ilerle. Package helper testlerini H-PG/Codex/remote yayın başarısı yapma.
5. Kesinti için source/ref, iş durumu, yapılmış testler, açık hata, unknown effect, next ve return_to kaydı bırak. K14'te cutover olana kadar build ledger tek build otoritesidir; sonra canlı authority'ye devir explicit olacaktır.

**İlk kullanıcıya dönüş:** kaynak hash'leri, hedef repo/ref, aktif controls, güvenli yapılabilecek ilk iş ve yalnız owner'a ait eksik kararlar. Bütün sistemi bir kerede yazmaya başlama. K15 P6 kabulü değildir; SOUL'un ilk gerçek backlog'unu sen seçme.

## Research repository yayını henüz yapılmadı

Bu P5 rehberi gerçek kaynak teslimidir; Research main henüz P4 v4/P5-next durumundadır. `repository-update/` son kullanıcı yönünü ve kontrollü yayın için değişiklik tarifini içerir. Yeni oturum yalnız eski main'i okuyup P5 rehberini yok saymamalı; bu gerçek paketi de okumalıdır. Yetkili yazma erişimiyle kaynak kimliği/diff/readback tamamlanana kadar repository sürekliliği açık kalır. Bunun için Research AGENT/agent kontrolleri değiştirilmez.
