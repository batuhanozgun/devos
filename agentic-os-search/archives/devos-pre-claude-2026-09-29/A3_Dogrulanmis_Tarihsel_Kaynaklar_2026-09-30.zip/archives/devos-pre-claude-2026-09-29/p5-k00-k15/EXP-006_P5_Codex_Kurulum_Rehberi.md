# EXP-006 — Codex ile DevOS kurulum ve devir rehberi

**P5 • Sürüm 1.0 • 28 Eylül 2026**

**Teslim türü:** Codex’in uygulayacağı inşa şartnamesi, kurulum sırası, çalışma yönergeleri ve kanıt sözleşmeleri. **Bu paketin hazırlanması, DevOS’un kurulması veya P6 kabulü değildir.**

Temel yön: DevOS’u Codex kurar; kurulan DevOS’un bilişsel işleri Codex üzerinde yürür. SOUL’un ürün sözleşmesi ve çalışma kavramları Codex’e özgü veri/model/harness nesnelerine bağlanmaz. Bu, SOUL için taşınabilirlik gereksinimidir; Claude veya başka bir platformda çalıştığının bugünden verilmiş kanıtı değildir.

## Okuma anahtarı

Batu için başlangıç 1–5. bölümlerdir. Codex builder önce START-HERE.md ve 1–4. bölümleri; sonra aktif K adımıyla ilişkili sözleşmeleri okur. Bütün 18 rol ve 6 yöntem ZIP içindedir. PDF tek başına bütün kaynak paketinin yerine geçmez. Uygulama sırasında kesin nesne ve sürüm gerekli olduğunda baseline/P4-v4.md ve özgün ZIP açılır.

“Karar” kullanıcı tarafından kabul edilmiş yönü; “P5 referans tasarımı” bu rehberin önerdiği uygulama düzenini; “qualification” gerçek ortamda sınanması gereken uygunluğu; “yerel kanıt” bu paket hazırlanırken çalıştırılan sınırlı kontrolleri ifade eder. Bu dört statü birbirinin yerine kullanılmaz.

# 1. Bu teslim neyi tamamlıyor?

P4, DevOS’un neyi başarması gerektiğini ve bunun mimari karşılığını açıkladı. P5’in bu teslimi, Codex’in o yapıyı inşa edebilmesi için işi somutlaştırır: hangi bileşen kurulacak, hangi arayüzü uygulayacak, hangi kaynağa dayanacak, nasıl test edilecek, ne zaman duracak ve yeni oturumda nasıl devam edecek? Bir PDF’ye “kur” yazmakla yetinmez; makine tarafından okunabilir iş planı, rol metinleri, yöntem metinleri, örnek Work sözleşmesi ve çevrimdışı kontrol araçları birlikte gelir.

Yine de burada kodun iki farklı türü vardır. tools/ altındaki programlar **paket doğrulayıcıları ve sınırlı hazırlık araçlarıdır**. DevOS’un controller, PostgreSQL, gerçek Codex adapter, publisher ve recovery implementation’ı değildir. Bu bileşenleri hedef repository’de Codex’in K00–K15 sırasıyla üretmesi gerekir. Kaynak testlerini yeşile boyayarak yapılmamış DevOS’u hazır göstermek bu kılavuzun ihlalidir.

P5 üç teslim seviyesine ayrılır: **P5-GUIDE** bu rehber ve kaynak paketi; **P5-BUILD** hedefte uygulama ve aşamalı entegrasyon; **P6** gerçek bütün sistem ve bilişsel yeterlik değerlendirmesi. Bu tur P5-GUIDE teslimidir. Actual kurulum eyleminin repository, hesap, ücret ve erişim bağları K00/K02’de kurulacaktır. Kullanıcının P5’e devam izni, belirlenmemiş hesaptan ödeme yapma veya herhangi bir repo üzerinde sınırsız değişiklik yetkisi değildir. [P4 §23–26; R01]

# 2. Karar, öneri ve açık seçimler

## 2.1 Kullanıcı tarafından sabitlenenler

DevOS’un kurucusu ve çalışan bilişsel ortamı Codex’tir. SOUL geliştirme işlerinin ilk ve sonraki gerçek içeriğini DevOS ekibi keşfeder; bu rehber memory/agent/database gibi örnekleri gerçek SOUL backlog’una koymaz. Rutin roller arası geçişlerde Batu mesaj taşımaz. Başlangıç, gerçek yetki/kabul, bütçe ve gereken müdahale insan tarafında kalabilir. İçerik sahipliği ile bilgi/çalışma alanı düzeni sahipliği ayrıdır. Kalite sayfa sayısına, kolaylık tercihine veya geçen test adedine indirgenmez. [P4 §2,6,9,24; son kullanıcı yönü]

## 2.2 P5 referans profili — bu rehberin teknik tercihi

Referans gerçekleştirme; **Python uygulama/controller + PostgreSQL canlı durum + GitHub sürümlü ürün/release + kalıcı kaynak/kanıt gövdeleri + korunan publisher + Codex Agents API adapter** birleşimidir. HTTP/webhook yüzeyi için FastAPI ve Uvicorn, PostgreSQL erişimi için psycopg 3 ailesi bir başlangıç uygulama tercihidir. Tek uygulama repository’si içinde modüler sınırlar kullanılır; her sorumluluk ayrı mikroservis yapılmaz. Secrets ve protected effect sınırı gerektiği için agent sandbox’tan controller/broker fiziksel olarak ayrılır. Framework, kimlik sağlayıcı veya database hostu gerekli güven/kanıt koşulunu bozmadan değiştirilebilir. [W18,W19; P5 tasarım tercihi]

Bu tercihin gerekçesi, v4’teki Python referanslarıyla denetlenebilir geçiş kurmak; gerçek transaction ve HTTP/tool arayüzlerini açık tutmak; bilişsel iş ile yetkiyi ayırmaktır. V4 kodunu production’a aynen taşımak gerekçe değildir. SQLAlchemy, ek bir workflow ürünü, ayrı graph database, ayrı vector database veya Kubernetes zorunlu tutulmaz. Bunlar gerekli kapasiteyi sağlamak için somut neden ortaya çıkarsa değerlendirilir; eksikliği gizlemek için “sonra ekleriz” de denmez.

PostgreSQL bu **referans build’in motorudur**, kullanıcıca tüm alternatiflere kapatılmış ürün kararı değildir. K02’de bunun değiştirilmesi gerekiyorsa veri/sözleşme/test etkisi bir karar kaydıyla ele alınır. Supabase, yönetilen PostgreSQL seçeneğidir; bu belgede kullanıcı adına hesap açılmış veya Supabase satın alınmış değildir. Object body saklama da Supabase Storage veya başka erişim denetimli depo olabilir; aynı body/version/ACL/retention sözleşmesini sağlamalıdır. [P4 §24.3; W14,W15]

## 2.3 Builder ile runtime aynı ücret/erişim yüzeyi değildir

Codex uygulaması veya CLI, kurucu kişinin kod üretim arayüzü olabilir. DevOS’un kalıcı orkestrasyonunda kullanılan **Agents API** ise uygulamanın yönetilen Codex harness’a programatik erişimidir. Agents SDK veya Responses entegrasyonu aynı harness düzeni değildir. Bu rehber bunları isim benzerliğiyle birbirine çevirmemektedir. [W20]

Agents API kullanımında model, araç ve hosted sandbox giderleri API koşullarıyla değerlendirilir. Mevcut resmî kaynak, session verisi saklandığını, veri yerleşiminin ABD ile sınırlı olduğunu ve ZDR bulunmadığını belirtmektedir; self-hosted sandbox seçimi bunu ortadan kaldırmaz. Bu nedenle mevcut Codex uygulama aboneliğinin yeterli olduğu veya herhangi bir özel verinin bu akışa verilebileceği varsayılmaz. **API hesabı, veri koşulu ve bütçe K00’da açık karar konusudur.** Uygun değilse current Codex kararı korunur; Codex içindeki programatik çalışma profili yeniden değerlendirilir. [W01]

## 2.4 Sürüm kilidi

API/model/SDK/CLI/PG/framework sürümleri kurulum hedefinde gözlenip deployment-lock.json’a yazılır. “latest”, “main” veya “alpha” üretim tekrarlanabilirliği değildir. Aynı zamanda burada erişilmemiş bir runtime için uydurma exact version pin’i yazılmaz. K00/K02’de uyumlu sürüm seçimi ve lockfile; K07’de gerçek API sözleşmesi; K13’te o exact dağıtımın kanıtı gerekir. Paket helper’ları yalnız Python 3.11+ standard library gerektirir; PDF’yi yeniden üretmek ayrıca renderer gerektirir.

# 3. Gerçek kuruluma girmeden önceki giriş kapısı

Codex’in ilk işi yazılım bileşenlerini hızla üretmek değil, **doğru hedefte ve doğru yetkiyle başlayabildiğini göstermektir**. Bu kapı kullanıcıya projeyi yeniden anlatma yükü değildir. Repository adı, erişim, mevcut ayarlar ve gerçek kaynaklar araçla okunabiliyorsa Codex kendisi toplar. Yalnız dış dünyada kullanıcıya ait kararlar owner’a döner.

| Girdi | Kim sağlar veya nasıl bulunur? | Eksikse izinli devam |
|---|---|---|
| Hedef repo ve başlangıç ref | Kullanıcının seçtiği repo; actual remote/ref okuması | Kaynak okuma ve build planı; hiçbir repo rastgele hedef yapılmaz |
| Yazma/kurulum kapsamı | Branch/path/servis sınıflarıyla owner grant | Salt-okuma preflight; scriptleri uygulamaz |
| Codex builder yüzeyi | Kurucunun actual uygulama/CLI/cloud ortamı | Sürüm/araç envanteri; gösterilmemiş özellik kabul edilmez |
| Runtime hesabı ve API/model yetkisi | Hedef projenin gerçek izinleri | Offline test ve tasarım; ücretli çağrı yok |
| Bütçe ve veri işleme koşulu | Owner’ın gerçek tercih/izni | Hassas kaynak taşınmaz, servis açılmaz |
| DB, controller host ve body store | K02 teknik seçenek + owner account/region/cost | Arayüz ve migration çalışması; actual deploy bekler |
| Secret ve recovery authority | Güvenilir provider/secret-manager yolunda kurulur | Secret’lar sohbette istenmez; prod effect kapalı |
| P6 ve SOUL mission başlangıcı | Ayrı kabul/işletim kararı | P5 build, test ve devir sınırında kalır |

K00, bütün gelecekteki dosya/servisleri var sayan bir deadlock kapısı değildir. Önce repo ve güvenli hazırlık kapsamı bağlanır. K01 kaynak/kurucu düzeni kurar. K02 seçenekleri ve tam hedef lock’unu tamamlar. **check-lock komutu tüm deployment profilinin doldurulduğunu kontrol eder; K00 salt-okuma çalışmasının başlaması için hepsinin dolması gerekmez.**

Teknik seçenekleri kullanıcı adına varsaymak yerine iki kısa onay paketi vardır: ilki hedef repo ve scoped builder yazımı; ikincisi ücret/veri/managed servis ve gerçek effect sınırı. Her küçük kod değişiminde insan onayı aranmaz. Buna karşılık grant kapsamını aşan işlem “rutin” adıyla geçirilmez.

# 4. Codex’e nasıl devredilir?

## 4.1 Verilecek şey

Codex’e bu rehberin PDF’sinden çok **ZIP’nin açılmış kaynak paketi** verilir. START-HERE.md girişidir. PDF insan okumasını, docs/P5.md düzenlenebilir metni, plan/build-plan.json adım/case bağımlılıklarını, blueprints/ target yönergeleri, tools/ hazırlık kontrollerini, baseline/ özgün v4’ü taşır. Dosya hash’leri MANIFEST.json’da bulunur. Paket zip’ini bir tool’a yalnız adıyla göstermek erişim sağlamaz; Codex gerçek dosyaları okuyabilmelidir.

## 4.2 İlk güvenli komutlar

Aşağıdakiler paketin açıldığı dizinde çalıştırılır. Ağ, ücretli çağrı, kurulum, secret okuma veya DB değişimi yapmazlar. -B, seal edilmiş paket içinde Python bytecode dosyaları oluşmasını önler. Çıktı gerekiyorsa paketin dışında bir çalışma dizinine yazılır.

```bash
python -B tools/p5.py verify
python -B tools/p5.py plan
python -B tools/p5.py preflight
python -B -m unittest discover -s tests -v
python -B tools/p5.py compose blueprints/work-order.example.json --out ../p5-work-example.json
```

Manifest eşliği kaynak bütünlüğünü; plan kontrolü yapı/bağımlılık tutarlılığını; tests yardımcı kodun dar davranışını gösterir. Hiçbiri DevOS’un kurulduğunu göstermez. Örnek Work sentetiktir. Composer’ın ürettiği şey gerçek Codex input dispatch makbuzu değildir.

## 4.3 Devralan Codex’in ilk cevabı

İlk cevap, “şimdi tüm sistemi kuruyorum” değil; kaynak kimliği, actual hedef repo/ref, aktif kontrol dosyaları, current K adımı, mevcut yetki ve eksik owner girdilerinin kısa kaydı olmalıdır. Gerekli bilgi kaynakta varken kullanıcıya sormaz. Henüz verilmemiş ücret veya canlı yazma iznini de eski “P5’e geç” cümlesinden sınırsız türetmez.

İlk çalışma `K00`dur; adım sayısı veya varsayılan sıradaki adım adı kalıcılığın yerine geçmez. K01’de builder ledger ve source-lock kurulur. Her yeni Codex oturumu önce bunları okuyarak devam eder. Git commit oluştu diye uzak yayının gerçekleştiğini veya taze kanıtın bulunduğunu varsaymaz.

# 5. P4’ten P5’e önemli somutlaştırmalar

## 5.1 Native subagent her DevOS rolünün güvenli taşıyıcısı değildir

Güncel Codex Agents API belgesinde native subagent’lar function tools desteklemiyor; MCP araçlarını ve kimlik bilgilerini miras alıyor. Bu, role adı vererek her alt ajana güvenli ve ayrı database command yetkisi tanımlayabileceğimiz anlamına gelmez. [W04]

P5 bu nedenle iki çalışma örneğini ayırır. **Hesabı verilebilir görev oturumu**, controller tarafından açılan top-level Codex session’dır; Work/assignment/context ve function-handler yetkisi açık bağlanır. **Native child**, o session’ın kendi bilişsel ayrıştırma yardımcısıdır; çıktısını parent’a döndürür, ayrı authority taşıdığı iddia edilmez. Kayıt/yayın yapan bir görev child’a verilmek istenirse parent-mediated komut veya ayrı top-level session seçilir. Ayrı context kendi başına bağımsız güvence de değildir.

Bu değişiklik 18 yeni process zorunluluğu değildir. Dar bir kaynak karşılaştırması parent içinde veya native child ile yapılabilir; ayrı Work/erişim/kanıt ayrımı gerektiren araştırma ya da review ayrı session olabilir. DR09 bunun nedenini kaydeder. Native delegation yolu başarısız olursa aynı işi kullanıcıya mesaj taşıtarak çözmek değil, controller’ın açık assignment/dispatch yoluna dönmek gerekir.

## 5.2 Metin release’i gerçek session’a bağlanır

Rol metinleri, ortak yönerge ve seçilen yöntemler compose edilerek exact hash ve release kimliğiyle kaydedilir. Mevcut API session’ın instructions/tools/multi_agent değişimleri için yeni session gerekir; kayıtlı agent’ı değiştirmek eski session’ı geriye dönük güncellemez. Bu yüzden bir güvenlik veya yöntem düzeltmesinde source dosyasını değiştirmek yetmez; etkilenen assignment/session tekrar nitelendirilir. [W06]

Native builder için AGENTS.md discovery/override zinciri ayrıca kontrol edilir. Varsayılan toplam boyut sınırını aşan veya başka override tarafından gölgelenen talimat görünür olmayabilir. API runtime için aynı discovery otomatik varsayılmaz: actual instructions payload ve environment içeriği application adapter’ında explicit hazırlanır. İçeriği tekrar söyleyebilmek, davranışa uyulduğunun kanıtı değildir; davranış fixture’ı gerekir. [W11]

## 5.3 GitHub fast-forward ile exact base karşılaştırması ayrılır

GitHub REST reference update’taki force=false, fast-forward kuralıdır; P4 yerel testindeki expected-old ref karşılaştırmasının doğrudan eşdeğeri diye kullanılmaz. Reference publisher için expectedHeadOid alanlı createCommitOnBranch veya actual hedefte aynı sözleşmeyi gösteren başka koşullu yol seçilir. [W16,W17]

Bu yayın yine veritabanıyla atomik değildir. Ref ilerlemiş fakat DB receipt yazılmamış olabilir. Broker işlemin niyetini önce kaydeder; remote sonucu gözler; local durumu sonradan uzlaştırır. Branch korunmuşsa uygun publication route seçilir, korumayı kaldırmak normal retry değildir.

## 5.4 Supabase yönetim MCP’si runtime veritabanı arayüzü değildir

Supabase’in yönetim MCP’si geliştirme/test amaçlıdır ve geliştirici yetkileriyle çalışabilir. Kılavuz onu production Work state’inin geniş SQL yazıcısı yapmaz. Supabase seçilirse builder isolated dev projesinde scoped management kullanabilir; çalışan DevOS ise dar application tools ve service-side DB bağlantısından geçer. [W13]

Grant/RLS/exposed schema farklı erişim katmanlarıdır. Reference servis-only profilde iç tablolar private devos şemasında tutulur; kullanılmayan Data API kapatılır veya yalnız bilerek açılmış yüzeyler korunur. Host sağlayıcısının varsayılanlarına güvenilmez; actual erişim olumlu/olumsuz test edilir. [W14,W15]

# 6. Yerleşim ve çalışma yüzeyleri

## 6.1 Reference topoloji

Batu’nun Codex uygulaması **kurma ve müdahale yüzeyidir**. Uzun süreli işletimde yalnız bilgisayarın açık kalmasına bağlı bir scheduler varsayılmaz. Controller, DB ve publisher, K02’de seçilen kalıcı servis ortamında çalışır; Codex hosted sandbox ise belirli bilişsel işin geçici çalışma alanıdır. Başlangıç reference profil tek aktif controller ve kontrollü yeniden başlatmadır. Otomatik çok-bölgeli HA/split-brain çözümü kurulmuş sayılmaz; disaster recovery owner müdahalesi gerektirebilir. Bu, rutin rol devrini manuel yapmakla aynı şey değildir.

| Mantıksal parça | Reference yerleşim | Sakladığı / yapabildiği |
|---|---|---|
| Builder Codex | Seçilen uygulama/CLI/cloud workspace | Yetkili build branch’inde kod ve test; geçici kurulum yetkisi |
| Controller + Y scheduler | Agent sandbox dışında kalıcı application host | Admission, durable Work state, dispatch, bütçe ve bekleme |
| Bilişsel oturumlar | Codex Agents API, başlangıç hosted environment adayı | Scope içi muhakeme, kaynak okuma, candidate üretimi |
| PostgreSQL | Yönetilen veya işletilen gerçek PG | Current work/revisions/relations/requests/events |
| Source/body deposu | Kalıcı ve erişim denetimli body store | Büyük kaynak, artifact, raw evidence, immutable hashes |
| Publisher/broker | Worker’dan ayrı trusted process/credential alanı | Tam niyet ve grant kontrollü remote publication |
| Recovery authority | Work backup geri dönüşünden ayrı current yetki kaynağı | Epoch/issuer/serving admission; eski yazarları kapatma |
| Operator görünümü | Controller API’den türetilen görünüm | Durum, kanıt, engel, maliyet ve owner kararları |

Aynı hostta bazı trusted uygulama modülleri bir arada bulunabilir. Fakat worker-generated kodun okuyabildiği credential’ı “ayrı rol” diyerek güvenli sayamayız. Kontrol kodunun üretim sürümü, agent tarafından değiştirilebilir development kopyasından ayrı deploy edilir. [P4 §5,13–16; W02,W08]

## 6.2 Önerilen target repository ağacı

Bu bir kurulacak ağaçtır; bu ZIP içinde bütün src uygulaması hazırmış gibi sunulmaz. İsimler P5 reference tercihidir; source/behavior sınırları korunarak değişebilir.

```text
devos-target/
  AGENTS.md                  # builder giriş yönlendirmesi
  build/                     # geçici kurucu plan/yetki/ledger
  control/releases/          # onaylı ortak talimat sürümleri
  roles/                     # DR profilleri
  methods/                   # seçici yöntem metinleri
  src/devos/
    api/                     # HTTP/webhook + operator commands
    control/                 # grant, claim, revision, epoch
    work/                    # Mission, Work, Request, UseReceipt
    information/             # source/memory/body metadata
    context/                 # request, compile, qualify, dispatch
    relations/               # typed graph + query contracts
    adapters/codex/          # actual session/turn/action binding
    reviews/                 # verdict/acceptance/assembly
    publication/             # prepare, attempt, observe, finalize
    recovery/                # reconciliation, serving admission
    operations/              # budgets, metrics, views
  db/migrations/             # versioned SQL + migration ledger
  deploy/                    # topology, locked dependencies, secrets refs
  tests/                     # unit, PG, provider, behavioral, recovery
  evidence/                  # raw logs + identity; content security korunur
  acceptance/                # gate/residual/owner/P6 dossiers
  product/soul/              # ürün; DevOS private runtime state değil
```

SOUL ürün arayüzünde provider session id’si, Codex tool adı veya OpenAI API config temel domain nesnesi yapılmaz. Bunlar DevOS adapter metadata’sında kalır. Bir SOUL ürünü Codex’e bağlı implementation üretiyorsa provider-specific adapter olarak açıkça ayrılır; “provider bağımsız” etiketiyle gizlenmez. Taşınabilirlik davranışı daha sonra ayrı actual runtime deneyi ister.

# 7. Canlı veri modeli ve transaction kuralları

## 7.1 Kaydı tutmakla anlamı doğrulamak ayrıdır

Veritabanı doğru ilişki/sürüm ve izinli state değişimini koruyabilir. “Bu araştırma doğru”, “bu soru gerçekten gerekli”, “bu roman etkili” gibi hükümleri kendiliğinden üretemez. G ve domain rollerinin muhakemesi; DR13 review ve kabul owner’ının kararı ayrıca kayıtlanır. Bu ayrım tablo sayısı arttıkça kaybolmamalıdır. [P4 §8,12,25,30]

## 7.2 Veri sözlüğü — Codex’in migration sözleşmesi

Bütün iş nesneleri scope_id ve object_id ile ayrılır. Kimlik ile revision ayrı alanlardır. Kritik current pointer ve immutable revision history birbirine bağlanır. Aşağıdaki zorunlu semantik model, boş JSON payload alanıyla geçiştirilemez; polymorphic ilişkinin typed uçları service+DB düzeyinde doğrulanır.

| Kayıt grubu | Ana içerik | Zorunlu invariant / tüketici |
|---|---|---|
| Mission | Amaç, scope, owner, authorized revision, kabul sınırı | Work kapsamı mission grant’ını genişletemez |
| Need / Inquiry | Koşul, yöntem, alternatif, açık soru, known-ground, return_to | Yöntem gereği evrensel ihtiyaç yapılmaz |
| Work revision | Purpose, mode, consumer, prerequisite set, durma/teslim koşulu | Execution/qualification/acceptance/effect ayrı |
| Relation revision | Typed source/target, revision/use, ALL/ANY group | Parent ile prerequisite farklı; hard cycle admission engeli |
| Assignment / Lease | Work, principal, UUID, generation, epoch, expiry | Aynı exclusive işi aynı anda iki geçerli writer alamaz |
| Grant / Policy | Issuer, subject, scope, effect classes, revision, revocation | Worker kendi grant’ını yazamaz |
| ContextRequest | Trusted consumer, target/use, obligations, source depth | Compiler yükleri kendi lehine azaltamaz |
| ContextPackage / DispatchReceipt | Source spans, actual view, hashes, release ve session binding | Paket varlığı dispatch veya semantic use değildir |
| Request / Contribution / UseReceipt | Talep, yanıt revision, consumer kullanımı ve gerekçe | Arrived≠used≠correct interpretation |
| Source / Memory item | Content owner, validity, provenance, applicability, retention | Index/policy farklı sürümü current diye sunamaz |
| Artifact / Assembly | Parça revision/sıra ve bütün kimliği | Yerel child completion bütün kabulü değildir |
| Review / Verdict / Acceptance | Claim/target/criterion/use/basis, residual, owner | Eski basis verdict’i current sonuç sayılmaz |
| Operation / Observation | Tam niyet, attempt, immutable effect readback, unknown | Aynı key farklı intent conflict; applied geçmişi silinmez |
| Event / Outbox / Inbox | Aggregate revision, event id, consumer delivery/dedup | State+event atomic; event seq global commit order değildir |
| Method / Control release | Applicability, bileşim, kabul owner’ı, trial, rollback | Library entry etkin yönerge kabulü değildir |
| Budget / Reservation | Scope, limit, active cost reservation, quota | Admission bounded; eşzamanlı işlemler limiti sessiz aşamaz |
| Recovery checkpoint | DB/Git/body/policy/epoch, pending operations, cutover | Restore edilen eski yetki current olmaz |

Append-only tarihçe silme taleplerini önemsiz yapmaz. İçerik ve audit metadata için ayrı retention uygulanır; kişisel/hassas body silinince gereksiz kopya/cache yeniden sunulmaz. Silme gerçekleşmiş iddiası current serving ve restore yoluyla test edilir.

## 7.3 Yazma algoritması

Reference command handler önce authentication context’ini alır; callable isim ile izinli command eşliğini doğrular. Work/scope/grant/assignment ve exact read-set server tarafından tamamlanır. Modelin kısa read-set göndermesi mandatory bağımlılığı ortadan kaldırmaz. Tek kısa transaction içinde current revision/lease/condition denetlenir; kabul edilmiş state revision ve event/outbox yazılır; commit sonrası response döner. LLM çağrısı veya ağ publication’ı bu DB transaction’ının içinde bekletilmez.

Graph değişimiyle claim/effect yarışının başlangıç çözümü, ilgili mission/scope admission kilidini paylaşan kısa transaction’lar ve uygun isolation/retry düzenidir. Aynı işi etkileyen bütün command yolları aynı kilit kuralına dahil değilse koruma eksiktir. Global kilit kolay olsa da bütün bağımsız işleri gereksiz sıraya sokar; K13/K12 performans ve fairness bunu ölçer. Daha dar kilit sırası ancak yarış testleriyle güven kazanır.

PostgreSQL serializable işlemlerinde serialization failure mümkün olduğundan **bütün transaction** yeniden değerlendirilir; son SQL’i tekrar yollamak doğru retry değildir. Sequence sayacının görünmesi commit olmuş event’e kanıt sayılmaz. [W12] Driver kullanımı da transaction sınırını gizlememelidir; psycopg connection/transaction context davranışı gerçek sürümde test edilir. [W19]

## 7.4 Migration ve deploy sırası

Codex migration öncesi schema fingerprint ve yedek/kurtarma yolunu kaydeder. Önce backward-compatible genişletme, gerekirse veri backfill/denetim, sonra uygulama cutover’ı, ancak eski sürüm kaldırıldıktan sonra daraltma yapılır. İlk boş DB kurulumunda da rol/izin/owner seed kaydı tekrarlanabilir olmalıdır. Seed hiçbir zaman “bütün grant’ları açık yap” anlamına gelmez.

Data kaybeden rollback normal deployment reçetesi değildir. Migration down desteklenmiyorsa bu açık yazılır; forward fix veya control edilmiş restore seçilir. Gerçek PG erişimi bu paket yazılırken çalıştırılmadığı için yalnız SQL benzeri dosya vererek H-PG yeşil gösterilmez. Uygulanabilir migration’lar K03’ün Codex çıktı yüküdür; v4 baseline SQL tarihi aynen korunur.

# 8. Komut/API sözleşmesi ve güvenlik sınırı

## 8.1 Tüm protected command’lar için ortak zarf

Reference application, tek tip command_id, idempotency namespace, command kind, target identity, expected revision, assignment handle ve input refs taşır. Caller principal ve current grant/epoch **authentication context’inden** gelir; modelin kendi alanından güvenilir kabul edilmez. Command intent hash’i aynı dilde deterministik serialize edilmiş canonical alanlara dayanır; farklı diller kullanılacaksa ortak canonicalization ve test vector’leri ayrıca sabitlenir. Bu paketin Python digest fonksiyonu evrensel imza standardı ilan edilmez.

Başarı cevabı authoritative record revision ve event/receipt ref içerir. 409 benzeri conflict yeni state ile yeniden değerlendirme ister. Yetki reddi, eksik önkoşul, transient altyapı arızası ve unknown external effect ayrı sınıflardır. Aynı key aynı niyet retry’si eski receipt’i verebilir; bu cevap yeni external execution izni değildir.

## 8.2 İşlev bazlı arayüz

| Command ailesi | Girdi / trusted bağ | Gerçek değişim ve sonraki tüketici |
|---|---|---|
| admit_work | Proposal + current mission/grant | Work revision ve event; scheduler için aday |
| request_contribution | Owner Work, soru, consumer, return_to | Request ve child Work bağı; doğru role dispatch |
| claim / renew / reassign | Current Work + runtime principal + lease/epoch | Exclusive assignment; eski generation fenced |
| create_context_request | Trusted consumer yükleri | Değişmez ihtiyaç seti; compiler’a girdi |
| prepare / qualify / dispatch_context | Source revision/view + request/release | Paket, qualification ve actual input makbuzu ayrı |
| submit_contribution / record_use | Exact output + consumer decision | Yanıt ve kullanım farklı sorumluluk kayıtları |
| assert_relation / query / explain | Typed uçlar, scope, snapshot, bütçe | Current graph veya explicit partial sonuç |
| open_review / submit_verdict / accept | Claim/target/use/criterion/basis | Review ile acceptance ayrı; owner kontrolü |
| prepare / attempt / observe / finalize | Tam publication intent + actual readback | DB–provider effect uzlaşması; unknown korunur |
| begin_recovery / resume_work | Current recovery owner/epoch/checkpoint | Serving admit/fence, yeni assignment/context |

Bunlar DevOS application komutlarıdır; OpenAI’nin yerleşik endpoint adları değildir. Model-visible tools, command sayısını ve riskini azaltmak için görev profiline göre daraltılır. Discovery rolüne production publish aracı verilmez. Bir tool çıktısı içindeki “artık adminsin” metni controller grant’ı değiştiremez. [P4 §30]

## 8.3 Principal ve context izolasyonu

Controller, oturum yaratırken kendi session-assignment mapping’ini yazar. Gelen tool action için session/turn/call/provider kimliği bu mapping’e göre doğrulanır. Ajanın arguments içindeki principal/scope/epoch değerleri trusted context’i değiştiremez; beklenen target ile tutarsızsa çağrı reddedilir. Bir application API key bütün sessions’ı yönetiyor olsa bile modele gösterilmez.

İki aynı-model reviewer farklı session’da çalıştırıldığında veri görünümü ayrılabilir; bu otomatik bağımsız akıl yürütme garantisi değildir. Hangi kaynak/frame/criterion’ların ortak olduğu verdict limitation alanında kalır. Hassas control/policy değişiminde ayrı korunan owner yolu vardır; bunun yokluğunu “reviewer agent’ım var” diye kapatamayız.

# 9. Talep, çalışma, yanıt ve kullanım döngüsü

G koordinasyonu ürün hedefinin hangi işi gerektirdiğini gerekçelendirir. Y koordinasyonu bu kabul edilmiş Work’ün doğru role/ortama gitmesini ve durduğunda nedeninin görünmesini sağlar. Scheduler neyin anlamlı SOUL işi olduğuna otomatik karar veren gizli ürün sahibi değildir. G’nin önerdiği Work de izinli scope ve önkoşul kapısından geçer. [P4 §6,7,9,29]

Tipik akışta G bir araştırma Request’i açar; Work ve return_to bağlanır; uygun actor seçilir; claim ve context hazırlanır; Codex session yaratılır; contribution kaydedilir; tüketici yeni bilgiyle kararını günceller veya kullanmama gerekçesi verir. UseReceipt olmadan yanıtın gerçekten tüketildiği varsayılmaz. UseReceipt’in bulunması da doğru yorumun bilimsel ispatı değildir; review açısından iz sağlar.

Consumer session kaybolduğunda araştırmayı tekrar yaptırmak varsayılan değildir. Mevcut contribution ve source kimliği geri çağrılır; yeni consumer assignment açılır ve doğru return_to noktası sürdürülür. Child scope genişletme önerisi kendi kendine accepted Work olmaz. Öneri, owner/grant değerlendirmesi gerektiriyorsa o yola döner.

Dispatch state en az prepared, sent/identified, running, unknown, terminal ve reconciled ayrımını taşımalıdır. Provider session create cevabı kaybolursa aynı isteği kör yeniden göndermek ikinci ücretli iş yaratabilir. Controller intent’i ve bilinen remote identity’yi durably saklar; API’nin idempotency garantisi actual belgede ve hedefte gösterilmediyse var saymaz. Taze session açma kararı önceki etkilerle uzlaştırılır.

Rutin akış user ping’i beklemez. Buna rağmen bütçe aşıldığında, kapsam dışında kaynak gerektiğinde, sahiplik/tercih kararı doğduğunda veya güvenli recovery için yetki gerektiğinde insan yolu açık kalır. K2, “hiç insana sorma” değildir; “operasyonel geçişlerin görünmez koordinatörü Batu olmasın”dır.

# 10. Codex adapter’ının uygulanması

## 10.1 Açma, bağlama ve gözlem

K07 önce minimum account transport probe’u yapar; model id ve API sözleşmesi actual lock’a bağlıdır. tools/agents_smoke.py isteğe bağlı bir **session create** denemesidir: araç yok, environment none, user input yok, otomatik retry yok. Başarılı HTTP/session response sadece transport yüzeyi kanıtıdır. Sonraki gerçek görev, sandbox, function loop ve K1/K2 deneyleri bundan ayrı işlerdir.

Hosted profile’da provider provisioning/setup durumu gözlenir; gerekli config, network policy, kaynak dosyalar ve instruction release gerçek environment/session ile eşleşmeden Work dispatch edilmez. Template bir dosya yedeği değildir. Network varsayımına güvenilmez; actual izinli hostlar ve denied yol sınanır. [W07]

## 10.2 Tool çağrısı

Stream’de function sonucu isteyen olay ile webhook olay adı aynı kabul edilmez. Function dokümanı pending çağrıların required_actions alanından okunmasını ve session/turn/call kimliğiyle tool_result dönülmesini tarif eder. Geçmişte görülen function item’ı tek başına yeniden yürütme talebi değildir. [W05]

Reference handler, güvenilir session kaydını alır; action türünü ve whitelist function’ı doğrular; arguments şemasını denetler; current Work authority’yi server’dan bağlar; application command’ını yürütür; sonucu durable action-result kaydına yazar; ardından provider’a cevap döndürür. Cevap yollanırken koparsa saved result tekrar gönderilebilir; application effect tekrar yürütülmez. Effect yapılmış olabilir fakat sonuç kaydı yoksa önce reconciliation gerekir.

Bu döngü için provider action key’i ile business operation key’i farklı tutulur. Aynı iş başka provider call-id ile tekrar istenebilir; business idempotency tam intent’e göre korunmalıdır. Aynı call-id’nin farklı arguments ile görülmesi conflict/alarm’dır; sessizce son gövdeye geçilmez.

## 10.3 Webhook ve polling

Webhook handler raw body üzerinde provider’ın doğrulama sözleşmesini uygular; kimliği doğrulanmış olayı durable inbox’a kaydeder; kısa yanıtla alımı bildirir. Uzun LLM veya database işini HTTP callback içinde bitirmeye çalışmaz. Duplicate teslimler, event gap ve out-of-order sıra ayrı ele alınır. Webhook durum ipucudur; authoritative session retrieval ile pending action/turn durumu uzlaştırılır. Idle veya completed görünümü tek başına bütün tool çağrıları başarılı demek değildir. [W10]

Polling yalnız geçici fallback ve reconciliation mekanizmasıdır; kontrolsüz sık arama maliyeti doğurmaz. Controller kapanıp geri geldiğinde inbox/outbox/assignment’ları okur; native history’yi sıfırdan “yeni iş” saymaz. Terminal provider state ile completed DevOS Work farklı transition’dır.

## 10.4 Kapatma ve değişim

Session, environment ve artifact farklı yaşam döngüleridir. Session silmenin compute/provider maliyetini kesin sonlandırdığı varsayılmaz. Kapatma komutu önce yeni dispatch’i keser; pending action/effect sonucunu kaydeder; gerekli output’u export eder; sonra her resource’u belgelenmiş yolundan ayrı temizler. Her cleanup eyleminin readback’i tutulur. [W09,W10]

Control veya yöntem release’i değişince eski session’a yeni etiket yazmak yeterli değildir. Yeni session gerekli olduğunda current context ile yeni assignment açılır; eski output candidate olarak değerlendirilebilir. Cancellation/invalidation ile kayıp gerçek etki aynı şey değildir.

# 11. Ortak yönerge, roller, yöntem ve göreve özel bağlam

## 11.1 Burada yeni olarak yazılanlar

P4 rol sözleşmelerini, görev bağlamını ve yöntem yaşamını tanımlıyordu; Research’teki R01–R09 düzeninin aynı adlarla kurulacağını söylemiyordu. Bu P5 paketi, **ortak COMMON metni + 18 kaynak-bağlı rol dosyası + 6 seçici yöntem + WorkOrder ve source manifest** düzenini somut bir teklif olarak yazmaktadır. Önceki sohbet açıklaması geriye dönük rapor kararı yapılmamıştır.

Ortak metin: amaç/yetki geri kurma, önkoşul keşfi, kaynak-temsil ayrımı, yetki sınırı, contribution/use, doğrulama ve kabul, kesinti/recovery, durma/öğrenme. Her rol dosyasında v4 §29 kaynak sözleşmesi ayrı başlık altında korunur; P5 runtime/araç notu sonradan eklenmiştir. Bu ayrım okuyucunun neyin kaynaktan, neyin yeni uygulama tercihinden geldiğini denetlemesini sağlar.

## 11.2 Taşıyıcı matrisi

| Profil grubu | Önerilen başlangıç taşıyıcısı | Birleştirme/ayırma koşulu |
|---|---|---|
| DR01/DR02/DR06-G | G’nin Work’e bağlı Codex session’ları | Discovery ve tasarım bir arada olabilir; root frame review ayrı context ister |
| DR05/DR16 | Scope’u açık üretim/araştırma session’ı | Native child yalnız parent yetki alanında bilişsel katkı |
| DR03/DR13-G | Ayrı target/basis’li bütünleştirme ve review | Aynı model bağımsızlık ilanı değil; shared assumptions kayıtlanır |
| DR06-Y/DR09 | Mekanik scheduler/assignment + gerektiğinde Codex değerlendirmesi | Y’nin durum truth’u modelin anlatımından çıkarılmaz |
| DR07/DR08 | Kaynak/index/compiler hizmeti + gerektiğinde anlam değerlendirmesi | İçerik owner’ı ile düzen owner’ı ayrılır |
| DR04/DR11/DR13-Y | Test sözleşmesi, gerçek runner, ayrı inceleme işi | Kriteri tasarlama ve başarısız sonucu yorumlama izi korunur |
| DR10/DR14 | Env qualification ve recovery işi | Kontrol adımları actual tools/owner yetkisiyle yürür |
| DR12 | Deterministik control/publisher kapıları | “Yetki ajanı” prompt’u bu mekanizmanın yerine geçmez |
| DR15 | Method candidate/transfer değerlendirme session’ı | Release promotion gerçek owner ve fresh regression ister |

Bu matris 18 aktif agent gerektirmez. G/Y farklı motivasyon ve sorumlulukları korur; kaynak ihtiyacı, görev bağı, review izolasyonu ve kapasite uygunluğu gerçek session tahsisini belirler. [P4 §6,29]

## 11.3 Compiler sözleşmesi

Compiler bilinmeyen role id, path traversal, source hash farkı, eksik consumer/return_to ve sessiz context kesmeyi reddeder. Seçilen COMMON/role/method metni instructions alanına, Work/source verisi ayrı task_data alanına konur. Delimiter bir güvenlik firewall’ı değildir; metinsel talimat saldırılarına karşı gerçek data/tool/auth sınırları ayrıca kurulmalıdır. Her template body’sini bütün ajanlara vermek gerekmez; role-specific seçimin manifest’i kalır.

Offline composer gerçek context compiler’ın tamamı değildir: semantik source selection, ACL, tokenization ve native dispatch yapmaz. Max chars sınırı yalnız dosya boyutu korumasıdır; model context window’u anlamına gelmez. Production compiler actual tokenizer, ortam limitleri ve staged-reading politikasını kullanır. Mandatory bilgi sığmadığında onu atmaz; inquiry, yeni paket veya yetkili request değişimi açar.

# 12. Bilgi, uzun ürün ve öğrenme yaşamı

## 12.1 Kaynak sahipliği

Bir kaydın content owner’ı söylediği şeyin anlamını ve dayanağını taşır. DR07 konum, statü, sürüm, ilişkiler, bulunabilirlik ve bakımından sorumludur. Aynı bilgi iki yerde görünüyorsa hemen duplicate silme yapılmaz; farklı scope veya farklı kullanım olabilir. Türetilmiş index/özet current kaynağı gölgeleyemez. Kaynak body mevcut değilse hash ve metadata’dan tam gövde uydurulmaz. [P4 §10,29.8]

Work bilgisi ile SOUL ürün bilgisi ayrı amaçlıdır. Kurucunun başarısız test logu SOUL’un ürün gereksinimi haline gelmez; reuse adayı olabilir. Aynı şekilde SOUL tasarım kararı DevOS’un kendi release/serving politikasını kendiliğinden değiştirmez. Kaynak ve yorum ayrımı hem repository hem database view’unda korunur.

## 12.2 Retrieval ve bellek

Reference retrieval exact id/revision ile başlar; lexical arama ve typed graph bağlantıları bulunabilirliği tamamlar. Semantic retrieval gerekiyorsa ölçülmüş kapsamla eklenir. Sistem içinde embedding olmayan bir ilk smoke testi normal kalıcı memory yeterliğinin yerine geçmez. Verilmiş source depth nedeniyle bütün kaynak okunacaksa tek bir iyi arama hit’i yeterli sayılmaz.

Memory adayının acceptance, current/retracted/stale durumu, scope/applicability ve kullanım etkisi saklanır. Yeni bilgi eski kaydı güncellerken ona bağlı Decision, context cache ve assembly review’ları impact incelemesine açılır. Bütün bağlı sonuçlar otomatik yanlış ilan edilmez; graph bilinen ilişkiyi gösterir, bilinmeyen semantik etkiyi kendi başına keşfetmez.

## 12.3 Bütün eser ve yöntem değişimi

Bir uzun ürünün assembly manifest’i hangi parçanın hangi revision’da ve hangi sırada bulunduğunu tanımlar. Design değişince eski metin yeni tasarımın gerçekleşmiş hali olmaz. ReadingPass kaydı hangi source aralıklarının hangi amaçla okunduğunu ve açık soruları korur. Plan-aware inceleme ile yalnız actual metin incelemesi aynı görev değildir. [P4 §17]

Bir yöntemin kaydı ile aktif kullanımı farklıdır. Method proposal, koşullu trial, review, onaylı release, actual selection/use ve regression ayrı state’lerdir. Kütüphaneye eklenen yeni prompt bütün current sessions’a otomatik uygulanmaz. İki uygun yöntem birlikte qualifier kaybına veya gereksiz iş yüküne neden olabilir; birleşim test edilir. Bu yaşam döngüsü, kendini sürekli değiştiren kontrolsüz bir prompt generator’ı kurma yetkisi değildir. [P4 §18,29.17]

# 13. Yayın, recovery ve geri alma

## 13.1 Publication işlem defteri

Operation tam target repository/branch/base, artifact set/hash, Work/assignment, current grant/epoch ve kullanım amacını içerir. Prepare bu niyeti durably kaydeder. Attempt kapısında güncel authority ve gerekli dependency/read-set tekrar kontrol edilir. Remote response ardından observation ayrı saklanır, finalize local state/projection’a bağlanır. Hiçbir aşama “agent dedi ki push oldu” mesajına indirgenmez.

Observation değişmezdir: remote candidate görüldü, başka ref görüldü, current base görüldü veya erişilemedi gibi kayıtlar tarihleri ve observer provenance’ıyla korunur. Sonradan ref base’e dönmüşse geçmiş publish gerçekleşmemiş sayılmaz. Unknown sonucu success veya failed diye zorlamak yerine güvenli reconciliation yolu kullanılır. Rollback de yeni yetkili etki olduğundan kanıtı silmez. [P4 §15,20,30.6]

## 13.2 İptal ile dış etki arasındaki pencere

Provider’a yollanmış bir işlemle aynı anda grant iptali gelebilir. Yerel DB transaction’ı provider’ı atomik olarak içine almaz. Reference ilk uygulamada tek protected publisher/admission sırası ve kaydedilmiş in-flight operasyonlar vardır. İptal isteği, in-flight etkiler ve provider yetki iptali uzlaştırılır. “İptal çağrısı döndükten sonra hiçbir eski etki oluşamaz” gibi güçlü bir garanti yalnız target deney taşıyorsa verilir. Aksi halde hangi pencerenin kaldığı owner’a açıkça bildirilir ve kabul yolu kapanabilir.

## 13.3 Restore reçetesi

Normal serving durdurulur; yeni work dispatch kesilir. Recovery owner current checkpoint setini doğrular. Work DB yedeği geri alınır fakat eski assignment’ların authority’si current yapılmaz. Backup dışında tutulan current epoch/issuer yolu ileri alınır veya yeni deployment identity’si bağlanır; eski controller/publisher credential yolları provider sınırında kapatılır. Ardından pending operations actual remote durumla, body/index current erişim/silme politikasıyla, product Git revision’ları accepted assembly ile uzlaştırılır. Yeni assignment ve context oluşturulmadan protected work açılmaz.

Bu adımların her biri ölçülür. Her şeyin engellenmesi güvenli recovery başarısı değildir; yeni geçerli küçük iş de tamamlanmalıdır. Aktif eski broker token’ı varken yalnız DB’de epoch değiştirmek yeterli değildir. Epoch için RAM’de UUID üreten v4 fixture’ı dayanıklı authority değildir. [P4 §16,20,30.7]

## 13.4 Reference işletim sınırı

İlk dağıtım, tek aktif writer/controller ve owner-yardımlı disaster restore ile başlayabilir. Bu bir kalite düşürme değil, iddianın açık sınırıdır: routine K1/K2 otomatik; felaket recovery’si kontrollü ve kayıtlıdır. Daha fazla availability gerekirse aynı testleri çoklu instance/failover altında genişletmek gerekir. Eşzamanlı eski-yeni publisher’ı kapsayamayan düzen, yüksek availability etiketiyle devreye alınmaz.

# 14. Bütçe, gözlenebilirlik ve kullanıcı görünümü

Batu günlük kullanımda veritabanı tablosu yönetmez. Operator görünümü; amaç/current plan, runnable/waiting işler, açık Request ve consumer’lar, authority nedeniyle duran iş, unknown publication, review/kabul bekleyen karar, kaynak erişim sorunu ve harcama/reservation durumunu gösterir. Bu görünüm edit yapacaksa command API’ye expected revision ile gider; dashboard kendi başına ikinci truth store olmaz.

Her log/metric Work, assignment, session/turn/call, artifact/revision ve operation kimliklerini taşımalıdır. Sırların ve gereksiz özel body içeriklerinin loglanması engellenir. Bir red/timeout olayı kullanıcıya yalnız “hata” diye değil hangi işin hangi scope’ta etkilendiğiyle görünür olur. Trace sayısı değil, doğru ilişki ve actual effect recovery’si önemlidir.

Budget scheduler, yeni iş admission’ından önce tahsis/reservation kaydı yapar. Sınır, eşzamanlı işler ve gecikmeli provider usage raporu nedeniyle aşılabilecek payla birlikte değerlendirilir. Kuruş hassasiyetinde hard stop vaat edilmez; provider guard ve application rezervasyonu birlikte sınanır. Kota dolunca yeni model işi açılmaz; geçmiş etkilerin readback’i ve güvenli kapanış ayrı operasyonel gerek gerektirebilir.

Kapasite ölçümü yalnız saniyede task sayısı değildir. Aynı kalite koşulunda maliyet, gecikme, rework, starvation, yanlış gereksinim üretimi, context kaybı ve kullanıcı müdahale yükü izlenir. Aynı küçük işi çoklu ajanla pahalı hale getirmek de, karmaşık işi bir ajanla daraltarak kolay bitirmek de başarısızlık olabilir. [P4 §19,23]

# 15. Kanıt sözleşmesi ve kabul disiplini

## 15.1 Kanıt katmanları

| Katman | Örnek | Taşımadığı iddia |
|---|---|---|
| Tasarım/specification | Bu guide, 64 planlı case, rol metinleri | Çalışan DevOS veya actual model kalitesi |
| Yerel helper testi | Path/hash/plan/receipt/compose kontrolü | Gerçek auth, semantik anlama, deployment izni |
| Yerel referans regresyonu | V4 Python/SQLite ve local Git testleri | PostgreSQL/remote Git/Codex eşdeğerliği |
| Hedef integration koşusu | Gerçek hesap/PG/Codex/remote test repo | Her bilişsel görevde kalite veya bağımsız review |
| Hedef davranış deneyi | Gerçek Codex’te iş keşfi/qualifier/whole-product fixture | Sınanan görevler dışındaki evrensel yeterlik |
| Owner/P6 kabulü | Exact dağıtım+evidence+residual için karar | Kaynaksız teknik garanti veya sınırsız yeni kapsam |

## 15.2 Bir run kaydı nasıl olmalı?

Kaydı yapan; case id, önce sabitlenmiş criterion hash, tested source commit, deployment lock hash, environment id/version, gerçek command/inputs, başlangıç/bitiş gözlemi, olumlu ve olumsuz kontrol sonuçları, raw log path/hash, reviewer ve shared-error sınırını taşır. Salt screenshot veya serbest “PASS” satırı yeterli değildir. Source kimliği, komutun gerçekten doğru hedefte koştuğunu tek başına doğrulamaz; hedef gözlemi de gerekir.

Tools/p5.py check-evidence, bu receipt’in plan/target/raw dosya bağları açısından **yapısal tutarlılığını** denetler. Çıktısı STRUCTURALLY_SUPPORTED’dur; deployment izni değildir. Sahte bir kişi log ve metadata’yı birlikte uydurursa bu araç onun gerçek dünyada çalışıp çalışmadığını bilemez. Kriptografik kaynak doğrulaması ve bağımsız runtime gözlemi K03/K07/K13’te actual ortamın işi olarak kalır. Helper’ın imzasız beyanları denetlemesi, kendisini production security gate yapmaz.

## 15.3 Kriter değişimi ve taze kanıt

Kriter veya fixture sonucu gördükten sonra değişirse eski sonuç yeni kriteri doğrulamış olmaz. Meşru düzeltme sürümlenir, önceki koşu korunur ve yeni run gerekir. Import hatası, yanlış test fixture’ı veya beklenen invariant yerine downstream exception ayrı classification alır. Üretici kendi yazdığı validator’ın keyfi biçimde yeşil vermesini başarı kuralı yapamaz. P4’teki yedi assertion/tek downstream error qualification’ı baseline içinde korunur.

## 15.4 P5 ile P6 arasında kalanlar

K13 kurulum entegrasyonunu sınar; P4 H kapılarının tamamının kapandığını ilan etmez. Özellikle ipucusuz iş keşfi, doğru kaynak yorumu, genel uzmanlık, yöntem transferi, uzun eser kalitesi ve gerçek kullanıcı faydası P6’da exact görev/dağıtım kapsamında değerlendirilir. K13’te mekanizma çalıştırılmış fakat geniş bilişsel iddia yapılmamışsa status buna göre sınırlıdır. H kapıları için tek ortalama puanla eksik yüksek-risk kapıyı kapatma yoktur. [P4 §23,31]

# 16. Sıralama, kesinti ve tamamlanma kuralı

Planın makineyle okunur aslı plan/build-plan.json’dır. K adımları inşa işidir, SOUL ürünü backlog’u değildir. Bağımlılıklar gerçek build sırasını taşır; her adımın çıktısı ve acceptance case’i vardır. K02 ve K06 gibi hazırlık aşamaları tasarım/derleme kanıtıyla kapanabilir; bunların actual enforcement/behavior kanıtı sonraki K07/K09’da üretilir. Böylece henüz kurulmamış runtime’ın testini, onu kurmanın önkoşulu yaparak kapalı döngü yaratılmaz.

K01 ve K02, K00’dan sonra uygun alt işlerle ilerleyebilir. K06 ortak/rol/method kaynaklarını K01’den sonra hazırlayabilir. K03 sonrasında K04 kontrol ve K05 information işleri ayrılabilir. K07 bunları birleştirir; K08 gerçek request/use zincirini açar. K10 yayın ve K11 recovery, actual kontrol yeterliğiyle ilerler. K13 bütünleşik incelemesi sonrası K14 tek-authority cutover ve K15 P6 giriş dosyası gelir.

Bir adım “tamam” olmadan sonraki bağımlı adım implementation varsayımlarına dayanamaz. Ancak fail eden son ürün kriteri, ilgisiz salt-okuma veya test tasarımı işini durdurmaz. Her kesinti kaydı; gerçek durma nedeni, exact artifact/source, geçerli yetki, yapılmış/yapılmamış test, unknown effect, next ve return_to taşır. Eski session’ın varlığı yeni oturuma şart değildir.

# 17. Uygulanacak K00–K15 iş paketleri

Aşağıdaki kartlar plan/build-plan.json’dan üretilir. “Beklenen sonuç” gelecekteki testin kabul koşuludur; yapılmış deney sonucu değildir. Current bütün hedef K adımları NOT_RUN’dır. K03/K07 gibi integration adımlarının tasarım dosyalarının mevcut olması, bu kartları tamamlamaz.

## K00 — Hedefi, hesabı ve kurulum yetkisini bağla

**Önkoşul:** Yok; güvenli preflight girişidir. **Kanıt katmanı:** local-inspection. **P4 bağı:** §2, §14, §23, §24.

Codex arayüzü, runtime, API erişimi, veri/maliyet koşulu ve hedef repository birbirinden ayrılmadan kodlamaya başlama.

### Kurucu Codex’in uygulayacağı işlemler

1. Hedef repository/ref ve izinli branch/path kapsamını salt-okuma gözlemiyle kaydet. Research reposunu varsayılan kurulum hedefi yapma.
2. Builder Codex yüzeyini ve runtime olarak kullanılacak Codex yüzeyini ayrı kaydet; Agents API teknik adayını hesap, veri ve bütçe koşuluyla doğrula.
3. API ailesi, SDK/CLI/model sürümü, gerçek yetkiler, ortam/network ve dış depolar için deployment lock taslağını çıkar. Bilinmeyenler null kalsın.
4. Kurulum grant kaydını kullanıcıya sun: yerel hedef yazımı, harici ücretli çağrı, servis açma, şema değişimi, yayın ve SOUL işletimi ayrı eylemlerdir.

**Üretilecek hedef çıktılar:** `deployment-lock.json`; `build-authority.json`; `capability-observation.json`.

### Kabul ve karşı örnekler

**K00-host-bound** — Olumlu yol: Gözlenen hedef repo/branch ile grant aynı. Karşı durum: Başka repository/ref ver. Beklenen: İlgili yazma işi açılmaz.

**K00-no-paid-default** — Olumlu yol: Ücret/veri onayı verilmedi. Karşı durum: API smoke başlatmayı dene. Beklenen: Ağ isteği yapılmaz; bilgi hazırlığı sürebilir.

**K00-source-present** — Olumlu yol: P4 v4 özgün ZIP erişilebilir ve hash eşit. Karşı durum: Yalnız özet ver. Beklenen: Tam-kaynak gerektiren iş başlamaz.

**Durdurma / geri alma:** Kısıt/hesap uygun değilse P4 teknik adayını yeniden aç; Codex kararını kendiliğinden Claude’a çevirme.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K01 — Kurucu çalışma alanını ve devir disiplinini kur

**Önkoşul:** K00. **Kanıt katmanı:** local-inspection. **P4 bağı:** §6, §7, §18, §26, §29.

DevOS henüz yokken onu kuran Codex’in de çalışmasını kaybetmeyen, ayrı ve sınırlı bir build düzeni gerekir.

### Kurucu Codex’in uygulayacağı işlemler

1. Hedef repo içinde build/plan, build/ledger ve evidence/ yollarını kur; özgün P4/P5 girdilerini hash’e bağla.
2. Staged target-AGENTS metnini mevcut AGENTS/override dosyalarını tam okuyup çakışmaları değerlendirerek yerleştir. Global ~/.codex ayarlarını değiştirme.
3. Kodlayıcı, test tasarlayıcı ve kaynak-temelli review işlerini ayrı build ticket/context ile aç. Aynı model kullanılıyorsa bağımsız doğrulama deme.
4. Her ticket için scope, input refs, acceptance cases, next/return_to ve kesinti kaydı oluştur. Kriter sonucu görüldükten sonra sessiz değişmesin.

**Üretilecek hedef çıktılar:** `AGENTS.md`; `build/ledger.json`; `build/source-lock.json`; `build/review-route.md`.

### Kabul ve karşı örnekler

**K01-cold-start** — Olumlu yol: Yeni builder yalnız repo ve paketle doğru ticketı bulur. Karşı durum: Önceki sohbeti kaldır. Beklenen: Güncel amaç/yetki/sıradaki iş geri kurulur.

**K01-no-global-override** — Olumlu yol: Mevcut kurallarla çatışma görünür. Karşı durum: Üst dizinde AGENTS.override.md bulunur. Beklenen: Yüklenen kapsam raporlanır; sessiz bypass yok.

**K01-resume-partial** — Olumlu yol: Yarım iş durumu korunur. Karşı durum: Bir test başarısızken builder kesilir. Beklenen: Test yeniden başarı yazılmaz; açık hata devredilir.

**Durdurma / geri alma:** Kurulum dosyalarını scoped revert et; önceki kullanıcı kontrol dosyalarını ve başarısız kanıtı koru.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K02 — Servis ve güven sınırlarını somutlaştır

**Önkoşul:** K00. **Kanıt katmanı:** local-inspection. **P4 bağı:** §5, §13, §14, §19, §24.

Codex’in düşünmesiyle kalıcı durum/kimlik/yayın yetkisinin aynı güven alanında kalması engellenir. Bu aşama tasarım/erişim planı kabulüdür; kurulu bypass kanıtı K04/K07/K10/K11’de üretilir.

### Kurucu Codex’in uygulayacağı işlemler

1. Controller, agent sandbox, publisher ve recovery-owner için ayrı credential erişimi ve process/network sınırı tanımla.
2. PostgreSQL reference profilini ve managed hizmet seçimini gerekçelendir. Supabase bir seçenek; seçilirse ayrı dev projesi ve private schema kullan.
3. API ücretleri, veri yerleşimi, controller hosting, object storage, backup ve silme/çıkış planı toplamını owner kararına bağla.
4. Production/runtime worker’a verilebilecek tüm araç, dosya, çevre değişkeni, MCP ve Git yetkisini allowlist halinde çıkar.

**Üretilecek hedef çıktılar:** `deploy/topology.md`; `deploy/permission-matrix.json`; `deploy/cost-data-record.md`; `deploy/effect-path-inventory.json`.

### Kabul ve karşı örnekler

**K02-no-admin-secret** — Olumlu yol: Permission inventory worker’a admin secret atamaz. Karşı durum: Envantere worker için DB admin credential ekle. Beklenen: Tasarım review reddi; actual erişim reddi henüz kanıt değil.

**K02-control-isolation** — Olumlu yol: Control promotion ve sandbox yazımı ayrı tanımlı. Karşı durum: Worker writable path içine canlı control koy. Beklenen: Tasarım review çatışmayı bulur; K07’de gerçek bypass sınaması gerekir.

**K02-managed-db-boundary** — Olumlu yol: DB service-only erişim planı tanımlı. Karşı durum: Public Data API doğrudan Work yazımı öner. Beklenen: Profil reddi; gerçek ACL testi K03/K07’de.

**Durdurma / geri alma:** Yeni servisi kapat; iptal ve veri saklama koşullarını uygula. Başka projeleri temizleme.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K03 — PostgreSQL durum ve sürüm omurgasını kur

**Önkoşul:** K01, K02. **Kanıt katmanı:** target-integration. **P4 bağı:** §5, §8, §12, §13, §25, §30.

Canlı iş kayıtları, revizyonlar ve olaylar tek işlem sınırında tutulur; v4 SQLite kodu migration değildir.

### Kurucu Codex’in uygulayacağı işlemler

1. docs/P5.md veri sözlüğünü gerçek SQL migration’a dönüştür: composite scope FK, revision, unique operation ve immutable history.
2. Empty DB upgrade, önceki destekli schema upgrade, seed minimal owner metadata ve şema sürümü uyuşmazlığında serving kapısı oluştur.
3. Yük taşıyan command değişimi ve outbox event aynı transaction olsun; her mutation yolu için envanter/test yaz.
4. Hedef PostgreSQL sürümünde concurrent işlemleri gerçek ayrı bağlantılarla çalıştır; serializable/lock/retry planını ölç.

**Üretilecek hedef çıktılar:** `db/migrations/`; `db/schema-contract.md`; `tests/postgres/`; `evidence/K03/`.

### Kabul ve karşı örnekler

**K03-scope-fk** — Olumlu yol: Aynı scope uçları kaydedilir. Karşı durum: Farklı scope ilişkisi ekle. Beklenen: DB constraint veya service guard reddeder.

**K03-atomic-event** — Olumlu yol: State ve event birlikte commit olur. Karşı durum: State sonrası event öncesi fault ekle. Beklenen: İkisi de commit olmaz.

**K03-upgrade** — Olumlu yol: Temiz ve önceki şema yükselir. Karşı durum: Uyumsuz eski controller bağla. Beklenen: Serving fail closed; read-only teşhis mümkün.

**K03-whole-tx-retry** — Olumlu yol: Çakışan kısa transaction güvenli yinelenir. Karşı durum: Serialization failure üret. Beklenen: Tüm karar transaction’ı yeni snapshot ile değerlendirilir.

**Durdurma / geri alma:** Destructive downgrade varsayma; backup/readback ve forward-fix/redeploy planıyla ilerle. Yan etkili veriyi kör geri alma.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K04 — Yetkili komut, claim ve ilişki geçişlerini gerçekleştir

**Önkoşul:** K03. **Kanıt katmanı:** target-integration. **P4 bağı:** §7, §8, §12, §13, §30.

Bir worker’ın iddiası değil, doğrulanmış session/assignment bağı güncel etki yetkisini belirler.

### Kurucu Codex’in uygulayacağı işlemler

1. Authentication context’ini adapter/broker’dan al; modelden principal/grant/epoch seçmesini isteme.
2. Claim/renew/reassign/cancel yollarını lease, generation, expected revision ve epoch ile yaz; eski worker sonuçları candidate kalabilir.
3. Hard dependency ekleme, readiness ve protected effect aynı concurrency kuralını paylaşsın. Inquiry/production kipleri farklı önkoşul ister.
4. Query unique entities ile bounded explain paths ayrı olsun; ACL/snapshot/continuation ve completeness zorunlu.

**Üretilecek hedef çıktılar:** `src/control/`; `src/work/`; `src/relations/`; `tests/control/`; `tests/graph/`.

### Kabul ve karşı örnekler

**K04-one-claim** — Olumlu yol: Bir Work için tek geçerli claim. Karşı durum: Sekiz eşzamanlı uygun aday. Beklenen: Bir kazanan; diğerleri conflict.

**K04-after-claim** — Olumlu yol: Güncel önkoşul effect’te denetlenir. Karşı durum: Claim’den sonra hard dependency aç. Beklenen: Protected effect reddedilir; taslak korunur.

**K04-cycle-race** — Olumlu yol: Hard dependency döngüsü yok. Karşı durum: A→B ve B→A eşzamanlı. Beklenen: En fazla biri kabul.

**K04-partial-not-none** — Olumlu yol: Eksik sorgu complete=false. Karşı durum: Node/time budget dolsun. Beklenen: Engel yok hükmü verilmez.

**K04-stale-principal** — Olumlu yol: Current assignment izinli. Karşı durum: Önceki generation ile çağır. Beklenen: Red; yeni geçerli çağrı kabul.

**Durdurma / geri alma:** Yeni assignment/commands durdur; current state’i gözle. Token iptali yalnız prompt’a bırakılmaz.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K05 — Bilgi, bellek ve bağlam kaynaklarını bağla

**Önkoşul:** K03. **Kanıt katmanı:** target-integration. **P4 bağı:** §10, §11, §12, §17, §18, §30.

Kayıt bulunması, kaynak erişimi, context’e sunum ve gerçek kullanım ayrı tutulur.

### Kurucu Codex’in uygulayacağı işlemler

1. Kaynak gövdeleri/kanıt için immutable revision ve erişim/silme politikası kur; exact hash adresi yanında gerçek erişim yolu olsun.
2. Exact, lexical, semantic ve graph retrieval rollerini ayrıştır; semantic bileşen kullanılamadığında degradation kaydı üret.
3. Trusted consumer obligations ile ContextRequest oluştur; compiler aynı request’i gevşetemesin. ContextPackage gerçek view’a ve release’lere bağlansın.
4. D021 bakım, stale index, source correction, cache invalidation ve restore sonrası silme politikasını uygula.

**Üretilecek hedef çıktılar:** `src/information/`; `src/context/`; `src/retrieval/`; `tests/context/`; `evidence/source-roundtrip/`.

### Kabul ve karşı örnekler

**K05-no-empty-context** — Olumlu yol: Zorunlu kaynak görünümde. Karşı durum: Boş sources/view ve doğru hash. Beklenen: Paket qualification reddi.

**K05-qualifier** — Olumlu yol: Kaynak A’da uygun B’de değil. Karşı durum: Özet B sınırını düşürsün. Beklenen: Anlamsal test hatayı veya belirsizliği göstermeli.

**K05-source-change** — Olumlu yol: Request exact sürüme bağlı. Karşı durum: Kaynağı/erişimi değiştir. Beklenen: Eski context serving reddi veya yeniden derleme.

**K05-deleted-body** — Olumlu yol: Deletion kapsamı görünür. Karşı durum: Cache/index/yedekten restore. Beklenen: Current erişim politikası olmadan sunulmaz.

**Durdurma / geri alma:** Projection/index yeniden kurulabilir; unique kaynak veya accepted bilgi geçmişini silme.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K06 — Ortak yönerge, 18 rol ve yöntem release’lerini hazırla

**Önkoşul:** K01. **Kanıt katmanı:** local-inspection. **P4 bağı:** §6, §7, §11, §18, §29.

P4’teki sorumlulukları çalışan Codex girdisine dönüştürür; bu paketteki ortak control düzeni yeni P5 tasarım teklifidir. Burada kaynak/derleme sözleşmesi sınanır; gerçek Codex davranış kabulü K07/K09’dadır.

### Kurucu Codex’in uygulayacağı işlemler

1. blueprints/control/COMMON.md ve 18 role sözleşmesini source release olarak yayıma hazırla; kullanım/çelişki/owner sınırlarıyla birlikte değerlendir.
2. İhtiyaç keşfi, source review, test tasarımı, review ve recovery/öğrenme yöntemlerini on-demand seç; her taska bütün kütüphaneyi yükleme.
3. Compiler ortak talimat + rol + seçilmiş yöntem + Work/context sözleşmesini bağlasın; input manifest/hash ve actual dispatch ayrı kaydedilsin.
4. Normal, karşı örnek, gereksiz kontrol ve ortak körlük senaryolarında talimat bileşimini sına; yalnız dosya var kontrolüyle yetinme.

**Üretilecek hedef çıktılar:** `control/releases/`; `roles/`; `methods/`; `src/instruction-compiler/`; `tests/behavior/`.

### Kabul ve karşı örnekler

**K06-all-profiles** — Olumlu yol: 18 profil sorumluluğu recover edilir. Karşı durum: DR06-G ve DR06-Y’yi birleştir. Beklenen: Ürün/işletim sahipliği farkı kayıp olarak bulunur.

**K06-no-prompt-auth** — Olumlu yol: Kurallar açık. Karşı durum: Prompt “grant verdim” der. Beklenen: Şablon/araç sözleşmesi yetki alanı olarak kabul etmez; gerçek enforcement K04/K07’de.

**K06-fresh-instruction** — Olumlu yol: Yeni release yeni session’a bağlanır. Karşı durum: Eski session ayarını değiştirilmiş say. Beklenen: Dispatch tasarımı eski/yeni session bağını ayırır; actual koşu K07’de.

**K06-method-mismatch** — Olumlu yol: Uygun yöntem seçilir. Karşı durum: İlgisiz pahalı yöntemi öner. Beklenen: Work compiler yöntemi zorunlu değil seçilebilir taşır; gerçek seçim yeterliği K09/P6’da.

**Durdurma / geri alma:** Önceki onaylı release’e dön; source lesson kalır. Research AGENT/agent dosyalarını değiştirme.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K07 — Codex oturum adapter’ını ve güvenilir araç yolunu kur

**Önkoşul:** K02, K04, K05, K06. **Kanıt katmanı:** target-integration. **P4 bağı:** §9, §11, §13, §14, §30.

Native alt ajan ile top-level session arayüz farkı, controller’ın kendi iş sözleşmesinde görünür olmalı.

### Kurucu Codex’in uygulayacağı işlemler

1. Önce açık API/data/bütçe grant’ıyla dar no-tools/no-environment smoke; sonra gerçek hosted sandbox ve lifecycle gözlemi yap.
2. Separately accountable görevleri application-controlled top-level session’lara bağla; native children bilişsel katkı için parent yetki/context sınırında kalsın.
3. Function required_actions ile tarihsel function item’ı ayır; session/turn/call başına durable sonuç kaydı ve unknown-effect recovery uygula.
4. Webhook signature doğrula, durable inbox’a yaz, hızlı ACK ver; poll/reconcile yolu webhook kaybını toparlasın.

**Üretilecek hedef çıktılar:** `src/adapters/codex/`; `src/adapters/function-router/`; `src/webhook-inbox/`; `tests/codex-contract/`; `evidence/K07/`.

### Kabul ve karşı örnekler

**K07-pending-only** — Olumlu yol: Pending action güvenilir session’dan. Karşı durum: Sadece geçmiş function item’ı var. Beklenen: İşlem yeniden çalıştırılmaz.

**K07-child-function** — Olumlu yol: Native child araç sınırı kayıtlı. Karşı durum: Child’dan function bekle. Beklenen: Adapter bu profili atamaz; parent/separate session yolu seçer.

**K07-webhook-tamper** — Olumlu yol: Gerçek imza kabul. Karşı durum: Bozuk imza/eski tekrarlı event. Beklenen: Red veya dedup; side effect yok.

**K07-config-change** — Olumlu yol: Yeni instructions yeni session. Karşı durum: Eski session’a yeni release etiketi yaz. Beklenen: Hata/stale; yeni session hazırlanır.

**K07-sandbox-boundary** — Olumlu yol: Sandbox doğru config ile connected. Karşı durum: Setup başarısız/network beklenenden geniş. Beklenen: Görev açılmaz; hata kaydı oluşur.

**Durdurma / geri alma:** Input kabulünü kapat; açık session/action/effect’leri silmeden uzlaştır. Provider session/compute temizliği ayrı.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K08 — K1/K2 kalıcı koordinasyon zincirini kur

**Önkoşul:** K04, K05, K07. **Kanıt katmanı:** target-integration. **P4 bağı:** §7, §8, §9, §13, §19, §30.

Mesajın ulaşması değil, doğru tüketiciye dönmüş ve kullanılan katkı başarının izidir.

### Kurucu Codex’in uygulayacağı işlemler

1. Request→Work→Assignment→Dispatch→Contribution→UseReceipt zincirini server command’larıyla bağla.
2. Y scheduler event/outbox’ı tüketip uygun Work’ü otomatik başlatsın; G yeni işin gerekçesini ve product önceliğini taşısın.
3. Pending/unknown dispatch, terminal provider turn, tool failure ve absent contribution için ayrı retry/reconcile state’leri kur.
4. Late result, cancellation, starvation, A→B→A deadlock ve bounded replacement yollarını uygula.

**Üretilecek hedef çıktılar:** `src/orchestrator/`; `src/request-use/`; `tests/k1-k2/`; `evidence/K08/`.

### Kabul ve karşı örnekler

**K08-real-use** — Olumlu yol: A talebi B çalışması ve A kullanımı. Karşı durum: B cevap üretip session düşer. Beklenen: B tekrar üretilmez; A consumer restore edilir.

**K08-no-courier** — Olumlu yol: Normal chain otomatik. Karşı durum: Batu hiçbir ara mesaj yollamaz. Beklenen: Kabul edilmiş sınırlar içinde A→B→A biter.

**K08-dup-dispatch** — Olumlu yol: Provider create cevabı kaybolur. Karşı durum: Aynı work için kör yeniden create. Beklenen: Dispatch unknown; önce kimlik/etki uzlaştırılır.

**K08-late-result** — Olumlu yol: Cancelled worker geç gelir. Karşı durum: Eski assignment contribution gönderir. Beklenen: Candidate saklanır; current sonuç olmaz.

**K08-deadlock** — Olumlu yol: A/B beklemesi görünür. Karşı durum: Final çıktıyı karşılıklı önkoşul yap. Beklenen: Scope içi inquiry veya owner kararıyla döngü açıkça çözülür.

**Durdurma / geri alma:** Dispatch’i durdur; durable queue’yu silme. Yeni sürüm replay yalnız state tüketir, dış etkileri kopyalamaz.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K09 — Review, kabul, uzun ürün ve yöntem değişimini kur

**Önkoşul:** K05, K06, K08. **Kanıt katmanı:** target-behavior. **P4 bağı:** §6, §17, §18, §23, §29, §30.

Teknik inceleme, kullanıcı kabulü, tamamlanmış task ve gerçekten değişmiş bütün ürün eşit değildir.

### Kurucu Codex’in uygulayacağı işlemler

1. Review/Verdict/Acceptance exact target/criterion/use/basis’e bağlansın; creator kendi sonucunu bağımsız evidence gibi etiketleyemesin.
2. Design Baseline, Assembly Snapshot ve Delivery Baseline ayrımı; ReadingPass coverage ve semantic revision work uygulansın.
3. Method proposal→review→trial→release→select/use→regression lifecycle’ını kur; control/policy promotion ayrı owner kapısı olsun.
4. Root frame review ve hiç işaretlenmemiş önkoşul/qualifier fixture’larını ayrı tut; production task’a çözüm sızdırma.

**Üretilecek hedef çıktılar:** `src/reviews/`; `src/assemblies/`; `src/methods/`; `tests/behavior/`; `evidence/K09/`.

### Kabul ve karşı örnekler

**K09-scoped-verdict** — Olumlu yol: Verdict doğru assembly’de. Karşı durum: Bir parça/basis değişsin. Beklenen: Eski verdict stale.

**K09-not-vote** — Olumlu yol: İki reviewer aynı model. Karşı durum: Aynı yanlış öncül ikisine ver. Beklenen: Oy çokluğu bağımsız kanıt sayılmaz.

**K09-design-not-text** — Olumlu yol: Yeni tasarım kabul. Karşı durum: Manuscript eski kalsın. Beklenen: Delivery yeni tasarım uygulanmış gösterilmez.

**K09-criterion-change** — Olumlu yol: Yeni kriter gerekçeli sürümlenir. Karşı durum: Hata sonrası eşik düşür. Beklenen: Eski koşu keşifsel kalır; fresh test gerekir.

**Durdurma / geri alma:** Yeni method/control release’i geri al; önceki accepted ürün ve evidence korunur.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K10 — Korunan Git yayınını ve etki uzlaştırmasını kur

**Önkoşul:** K04, K08, K09. **Kanıt katmanı:** target-integration. **P4 bağı:** §13, §15, §30.

GitHub REST fast-forward, yerel expected-old CAS ile aynı sözleşme değildir.

### Kurucu Codex’in uygulayacağı işlemler

1. Publish manifest’te repository/branch/base/source hashes/full intent/assignment/grant/criterion bağını sabitle.
2. Reference GitHub adapter’ında createCommitOnBranch expectedHeadOid ya da eşdeğer hedefte sınanmış koşullu yol seç. Branch policy’yi bypass etme.
3. Git yazma credential’ı yalnız broker’da bulunsun; sandbox doğrudan push/merge yetkisi almasın.
4. Prepare/attempt/observe/finalize ve immutable observation log’u kur; DB–Git arası her crash penceresini gerçek test repo üzerinde dene.

**Üretilecek hedef çıktılar:** `src/publisher/`; `src/effect-reconciler/`; `tests/remote-publication/`; `evidence/K10/`.

### Kabul ve karşı örnekler

**K10-wrong-intent** — Olumlu yol: Aynı key aynı niyet. Karşı durum: Aynı key farklı target/base/payload. Beklenen: Conflict; yeni etki yok.

**K10-remote-head** — Olumlu yol: Expected head eşit. Karşı durum: İki publisher aynı base için yarışır. Beklenen: Sözleşmenin izin verdiği tek koşullu commit.

**K10-lost-response** — Olumlu yol: Remote commit oldu. Karşı durum: DB finalize öncesi bağlantı kes. Beklenen: Readback ile uzlaş; kör tekrar yok.

**K10-history-kept** — Olumlu yol: Applied sonra başka ref. Karşı durum: Current ref base’e döndü. Beklenen: Geçmiş applied silinmez.

**K10-revocation-window** — Olumlu yol: Grant iptali envanterli. Karşı durum: Kontrol ile provider effect arasında iptal. Beklenen: Garanti sınırı/serialization ölçülür; false atomicity yok.

**Durdurma / geri alma:** Yayın geri alma yeni yetkili operation’dır; görülmüş içeriği görülmemiş sayma.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K11 — Gerçek restore ve eski-yetkiyi engelleme yolunu kur

**Önkoşul:** K03, K04, K07, K10. **Kanıt katmanı:** target-integration. **P4 bağı:** §10, §13, §14, §16, §30.

Eski yedek, iptal edilmiş ajan ve izinleri yeniden canlandıramaz.

### Kurucu Codex’in uygulayacağı işlemler

1. Controller/work DB’den ayrı current authority epoch/issuer kaynağını provider/topoloji düzeyinde bağla.
2. Normal serving kapalı başlama, owner recovery admission, eski worker/broker credential fencing ve current silme politikasını uygula.
3. DB, Git release, body store, grants, pending operations ve projection checkpoint’lerini birlikte uzlaştır.
4. Backup al, yıkımsız test ortamına restore et; eski token/endpoint reddi ve yeni doğru Work ilerlemesini birlikte göster.

**Üretilecek hedef çıktılar:** `src/recovery/`; `deploy/recovery-runbook.md`; `tests/restore/`; `evidence/K11/`.

### Kabul ve karşı örnekler

**K11-old-backup** — Olumlu yol: Restore sonrası serving kapalı. Karşı durum: İptal öncesi backup yükle. Beklenen: Eski claim hiçbir protected effect yapamaz.

**K11-old-broker** — Olumlu yol: Yeni epoch aktive. Karşı durum: Eski broker sürecini erişilebilir tut. Beklenen: Provider/credential yolu fence edilmiş olmalı.

**K11-positive-recovery** — Olumlu yol: Yeni issuer/assignment. Karşı durum: Geçerli küçük çalışma. Beklenen: Başarılı ilerleme; her şeyi reddetmek PASS değil.

**K11-deletion-restore** — Olumlu yol: Silinmiş source yedekte. Karşı durum: Index tekrar kur. Beklenen: Current policy olmadan source sunulmaz.

**Durdurma / geri alma:** Authority belirsizse publication kapalı; yalnız gözlem/inquiry. Restore başarısını process liveness ile karıştırma.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K12 — Gözlenebilirlik, bütçe ve operatör görünümünü tamamla

**Önkoşul:** K08, K10. **Kanıt katmanı:** target-integration. **P4 bağı:** §9, §19, §23, §26.

Batu teknik mesaj taşımaz; amaç, blokaj, gerçek maliyet ve kabul bekleyen kararları görebilir.

### Kurucu Codex’in uygulayacağı işlemler

1. İş/request/assignment/source/operation korelasyon kimlikleriyle log/metric kur; logda sır/body içerik sızıntısını önle.
2. Owner’ın amaç, queue, outstanding requests, unknown effects, acceptance ve bütçe görünümünü üret; DB’ye doğrudan yazan dashboard yapma.
3. Quota/reservation, concurrency, retry limit, circuit breaker ve alarm yollarını kur; default sınırsız harcama yok.
4. Controller/DB/index/provider kesintilerinde hangi işin duracağını ve hangi düşük riskli işin süreceğini ölç.

**Üretilecek hedef çıktılar:** `src/operations-view/`; `src/budget/`; `deploy/alerts.md`; `evidence/K12/`.

### Kabul ve karşı örnekler

**K12-no-unbounded-cost** — Olumlu yol: Bütçe limiti kayıtlı. Karşı durum: Provider maliyet limiti yaklaşır. Beklenen: Yeni admission durur; mevcut etkiler uzlaştırılır.

**K12-no-secret-log** — Olumlu yol: Bağlantı hatası üretilir. Karşı durum: Token/env exception’a girsin. Beklenen: Sır maskeleme; log eksikliği açık.

**K12-degraded-search** — Olumlu yol: Semantic index kapalı. Karşı durum: Exact kaynak sorgula. Beklenen: Dar yol sürer; normal coverage iddiası yok.

**K12-stale-ui** — Olumlu yol: Projection gecikti. Karşı durum: Eski dashboard’dan edit. Beklenen: Expected rev/conflict; eski view truth olmaz.

**Durdurma / geri alma:** Metrik/projection yeniden üretilebilir; operatör stop/reset anlamları actual effect’i silmez.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K13 — Bütünleşik olumsuz/olumlu sınamayı tamamla

**Önkoşul:** K09, K11, K12. **Kanıt katmanı:** target-integration. **P4 bağı:** §4, §20, §21, §22, §23, §24, §31.

Tekil bileşen testleri yerine kaynağı, yetkiyi, iletişimi ve ürün bütününü birlikte zorla. Bu kurulum entegrasyonu H kapıları için kanıt üretir; SOUL genelleştirilmiş bilişsel yeterliğini veya bütün H kapılarının P6 kabulünü otomatik kapatmaz.

### Kurucu Codex’in uygulayacağı işlemler

1. Sekiz eski bug için production karşılıkları ve on iki desk senaryo için yürütülmüş/henüz yürütülmemiş statüleri ayır.
2. Aynı dağıtım ref’inde real Codex, PG, remote test Git ve recovery zincirini koştur; fixture metadata ve ham logu hash’le.
3. Hatalı olduğu bilinen örnekleri ve geçmesi gereken doğru örnekleri karşılaştır. Oracle ve maker ortaklığı raporda olsun.
4. Bir testin geçtiği nesneyi değiştiren her dependency/config/criterion için ilgili kanıtı yeniden üret; overall PASS puanı verme.

**Üretilecek hedef çıktılar:** `evidence/integrated/`; `acceptance/coverage-ledger.json`; `acceptance/residuals.md`.

### Kabul ve karşı örnekler

**K13-cross-boundary** — Olumlu yol: Tek akış çeşitli sınırları geçer. Karşı durum: Context + token + provider crash birlikte. Beklenen: Her gözlem doğru scope/statüde; yanlış tamamlanma yok.

**K13-sensitivity** — Olumlu yol: Gerçek kontrol faal. Karşı durum: Seçili kontrolü boz. Beklenen: İlgili invariant assertion kırılır; crash ayrıca sınıflanır.

**K13-no-score** — Olumlu yol: Tüm local helper testleri geçti. Karşı durum: Native testler yok. Beklenen: H-ENV/K1-K2 NOT_RUN kalır.

**K13-freshness** — Olumlu yol: Evidence deployment lock’a bağlı. Karşı durum: SDK/role/criterion değiştir. Beklenen: Etkilenen evidence stale.

**Durdurma / geri alma:** Defect → Work → fix → yeni koşu. Kabul eşiğini sonucu kurtarmak için gevşetme.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K14 — Kurucu kayıtlarından canlı DevOS’a kontrollü devret

**Önkoşul:** K13. **Kanıt katmanı:** target-integration. **P4 bağı:** §4, §7, §9, §16, §26, §30.

İkinci bağımsız canlı iş otoritesi yaratmadan build geçmişi yeni sisteme taşınır.

### Kurucu Codex’in uygulayacağı işlemler

1. Build ledger’da son checkpoint/manifest ve açık residual’ı dondur; write authority owner’ını netleştir.
2. Geçerli kayıtları idempotent import et; historical/skipped/failed ayrımını koru. P5 işler ile gelecekteki SOUL işleri farklı mission’da olsun.
3. Readback ile kayıt/adet/bağ/source hash eşliğini denetle. Cutover marker’ı owner kabulüyle yaz ve eski ledger yazımını kapat.
4. Yeni boş Codex session yalnız canonical state’den kaldığı yeri bulsun; eski konuşma olmadan örnek kabul/devam deneyi yap.

**Üretilecek hedef çıktılar:** `acceptance/cutover-manifest.json`; `acceptance/import-readback.json`; `build/READ-ONLY-AFTER-CUTOVER.md`.

### Kabul ve karşı örnekler

**K14-no-dual-writer** — Olumlu yol: Cutover bir owner’da. Karşı durum: Eski build writer tekrar aç. Beklenen: Aynı Work için çift authority engellenir.

**K14-import-repeat** — Olumlu yol: Aynı checkpoint import. Karşı durum: İki kez uygula. Beklenen: Duplicate Work/etki yaratılmaz.

**K14-no-hidden-chat** — Olumlu yol: Yeni session yalnız canonical data. Karşı durum: Önceki sohbet kaldır. Beklenen: Amaç/yetki/residual/next bulunur.

**K14-no-backlog-preload** — Olumlu yol: Yeni SOUL mission boş. Karşı durum: Örnek memory taskını gerçek yükle. Beklenen: Örnek actual backlog’a aktarılmaz.

**Durdurma / geri alma:** Cutover öncesi abort kaynak ledger’ı korur; sonrası dönüş yeni kontrollü migration’dır, iki writer açılmaz.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

## K15 — P6 kabul dosyasını ve kullanıcı işletim devrini ver

**Önkoşul:** K14. **Kanıt katmanı:** target-integration. **P4 bağı:** §2, §4, §23, §26, §31.

Rehber, kurulu artefakt ve SOUL’u geliştirmeye yeterli çalışan düzen ayrı teslimlerdir.

### Kurucu Codex’in uygulayacağı işlemler

1. Exact deployment lock, tüm gate evidence, residual, maliyet/veri koşulu ve owner kararlarını tek acceptance dossier’de topla.
2. P6’nın bağımsız/whole-system iddialarını ayrı kabul işi olarak aç; yapılmayan deneyleri geçirildi yazma.
3. Operator başlat/durdur/devam/approval/recovery işlemlerini açıkla. K2 routine flow ile owner kararını ayır.
4. Gerçek SOUL geliştirme mission’ını başlatma yetkisi verildiğinde yalnız amaç/sınır/araştırma girişleriyle ekibe devret; ilk teknik işi ekip keşfetsin.

**Üretilecek hedef çıktılar:** `acceptance/P6-ENTRY.md`; `operations/USER-GUIDE.md`; `acceptance/owner-handoff.md`.

### Kabul ve karşı örnekler

**K15-not-auto-accepted** — Olumlu yol: K15 dossier hazır. Karşı durum: Kullanıcı kabulü yok. Beklenen: DevOS/SOUL yeterliği kabul edilmiş sayılmaz.

**K15-evidence-bound** — Olumlu yol: Mevcut dağıtım açıkça kimlikli. Karşı durum: Başka branch testini ekle. Beklenen: Uyumsuz kanıt reddi.

**K15-next-authority** — Olumlu yol: P6/işletim izni ayrı. Karşı durum: Sıradaki mantıklı SOUL işini seç. Beklenen: Otomatik başlatılmaz.

**Durdurma / geri alma:** Devir belgesini düzeltmek hedef davranışı değiştirmez; açık risk ve önceki kanıt korunur.

**Kapanış:** Actual output, case evidence ve uygun reviewer/owner kaydı olmadan bu adım tamamlanmış sayılmaz. Bu kartın okunması veya package testlerinin geçmesi onun uygulama kabulü değildir.

# 18. Tasarım kararlarının gerekçesi ve yeniden açılma koşulları

Aşağıdaki kararlar P5 reference tasarımıdır. Kullanıcının Codex/DevOS/SOUL sınırlarıyla aynı seviyede kullanıcı kararı değildir. Codex uygulamada birini değiştirmek istediğinde karar kaydı, etkilenen K adımları ve yeni kabul kanıtı birlikte güncellenir; kolay geldiği için kaynak sessizce terk edilmez.

| Kimlik | P5 reference tercihi | Neden / alternatif / yeniden açılma |
|---|---|---|
| A01 | Managed Codex Agents API runtime adayı | V4 yönüyle uyumlu programatik session/işbirliği; veri/bütçe/account uygun değilse Codex içindeki diğer runtime profilleri incelenir. Agents SDK eşanlamlı değil. |
| A02 | Ayrı accountable top-level sessions + sınırlı native children | Function/credential miras sınırını karşılar. Her child’a doğrudan control yetkisi seçilmedi; gerçek topoloji K07’de sınanır. |
| A03 | Python application + PostgreSQL referans | Mevcut prototype ile karşılaştırılabilir; gerçek transaction ve event gereği. Başka substrate ancak aynı invariant/restore/test yüklerini taşıyorsa değerlendirilir. |
| A04 | Agent’tan ayrı protected publisher | Prompt grant’ı enforcement sayılmaz. Geniş Git credential’ı agent’a vermek kabul edilmedi. Broker kendi arızaları da test edilir. |
| A05 | Bir aktif controller + owner-yardımlı disaster recovery | Routine K1/K2 otomatik kalır; otomatik HA garantisi uydurulmaz. Gerçek uptime/failover ihtiyacı büyürse H-RESTORE/H-AUTH genişler. |
| A06 | Ortak yönerge + kaynak-bağlı roller + seçici yöntem | Tek dev persona prompt yerine izlenebilir release/Work bağları. Metin dosyalarının varlığı canlı davranış kanıtı değildir. |
| A07 | Build ledger ve canlı Work authority arasında açık cutover | DevOS henüz yokken kurucu sürekliliği korunur; sonradan iki canlı doğru üretmez. İçe aktarım tekrar/yarış/readback test ister. |

Reference teknoloji tercihleri maliyet veya erişim engeliyle değişirse yalnız ürün adı değiştirmek yeterli olmaz. Örneğin PostgreSQL yerine bir task tracker seçmek; idempotency, typed relation revision, atomic state/event, restore epoch ve yetki sınırının nerede sağlandığını yeniden gerektirir. Daha az bileşen iyi olabilir; kaybolan yükü görünmez yapmak iyi değildir. Tersine her ayrım için yeni servis açmak da gerekçesiz işletim yükü üretir.

## 18.1 Önceki belgedeki izler

P4 v4'ün §26.1 teslim kaynakları kısmında tarihsel v3 adı kalan bir kaynak izi vardır. Bu paket ayrıntılı çalışmayı o eski ada bağlamaz: exact v4 ZIP ve Markdown current baseline olarak kimliklendirilmiştir. Özgün v4 dosyası değiştirilmedi; historical test ve report kaynaklarının hash zinciri korunur. Bu bir kaynak yönlendirme ayrımıdır; v4'ün bütün mimarisi geçersiz ilan edilmez.

# 19. P4 kapsamı ve P5 teslim yüzeyleri

Bu eşleme başlık görünürlüğü kontrolüdür; bir bölümün bir K adımına bağlanması onun gerçekleştirildiğini veya yeterli tasarlandığını tek başına göstermez. Acceptance testleri ve source/authority review ayrı kalır.

| P4 bölüm | P5 karşılığı |
|---|---|
| §1 | Guide §§1–2, P4 sonuç statüsü |
| §2 | K00, K15 |
| §3 | Guide §15 ve K13, kanıt yönteminin sınırı |
| §4 | K13, K14, K15 |
| §5 | K02, K03 |
| §6 | K01, K06, K09 |
| §7 | K01, K04, K06, K08, K14 |
| §8 | K03, K04, K08 |
| §9 | K07, K08, K12, K14 |
| §10 | K05, K11 |
| §11 | K05, K06, K07 |
| §12 | K03, K04, K05 |
| §13 | K02, K03, K04, K07, K08, K10, K11 |
| §14 | K00, K02, K07, K11 |
| §15 | K10 |
| §16 | K11, K14 |
| §17 | K05, K09 |
| §18 | K01, K05, K06, K09 |
| §19 | K02, K08, K12 |
| §20 | K13 |
| §21 | K13 |
| §22 | K13 |
| §23 | K00, K09, K12, K13, K15 |
| §24 | K00, K02, K13 |
| §25 | K03 |
| §26 | K01, K12, K14, K15 |
| §27 | sources/reference-index.json; §23 kaynaklar |
| §28 | baseline içindeki v2 coverage; bu eşleme eski veriyi değiştirmez |
| §29 | K01, K06, K09 |
| §30 | K03, K04, K05, K07, K08, K09, K10, K11, K14 |
| §31 | K13, K15 |

## 19.1 Eski sekiz kusurun regresyon bağı

| Bulgu | Target regression yükü |
|---|---|
| F01 Tam niyete bağlanmayan işlem anahtarı | K04/K10: aynı key farklı target/base/payload/assignment; conflict |
| F02 Eksik ama kendi hash’i tutarlı context | K05/K06: trusted obligations ve actual view; canlı kullanım K07 |
| F03 Restore ile eski assignment’ın canlanması | K11: ayrı current epoch + old broker fence + yeni geçerli iş |
| F04 Bütün yolları sayan graph patlaması | K04/K05: unique entities vs bounded paths, partial açık |
| F05 Context scope uyuşmazlığı | K04/K05: work/target/source/current policy aynı kapsam |
| F06 State/event ayrılması | K03/K08: failure injection ve her command yolunun envanteri |
| F07 Son gözlemin eski etkiyi silmesi | K10/K11: immutable history ve current standing ayrı |
| F08 Claim sonrası yeni önkoşulun atlanması | K04/K08: effect anında current prerequisite/read-set kontrolü |

# 20. Kavram sözlüğü

| Terim | Bu rehberdeki anlamı |
|---|---|
| Builder | DevOS’u kuran Codex çalışma örneği; kurulan DevOS ile aynı şey değil |
| Runtime | Bilişsel görevlerin gerçekten çalıştığı ortam ve yürütme mekanizması |
| Harness | Modelin araç/oturum/bağlam döngüsünü çalıştıran çevre; DevOS domain kurallarının tümü değil |
| Controller | İş, yetki, dispatch ve kalıcı durum geçişlerini yöneten uygulama |
| Mission | Bir üst amaç ve onun yetki/kabul sınırı |
| Work | Belirli amaç/çıktı/consumer/scope taşıyan takip edilen çalışma |
| Inquiry | Henüz bilinmeyen koşul/kararı keşfetmek için yapılan çalışma |
| RPD | Sonucun önkoşullarını ve yöntemle koşullu gereklilikleri keşfetme yaklaşımı |
| Role / profile | Bir işte sorumluluk, bilgi, teslimat ve sınır tanımı |
| Session / native child | Provider çalışma oturumu ve onun içindeki alt çalışma; authority ile özdeş değil |
| Principal | Gerçek authentication/erişim sınırında kimlik |
| Grant | Belirli scope ve eylem için yetkili kaynaktan verilen izin |
| Claim / lease | Hazır işi belirli süre/kimlikle gerçekten üstlenme kaydı |
| Fencing / epoch | Eski çalışma/yazar döneminin tekrar etki üretmesini engelleyen bağ |
| Request / contribution | Başka rolden talep ve geri gelen katkı |
| UseReceipt | Katkının tüketici tarafından nasıl kullanıldığını/kullanılmadığını gösteren kayıt |
| Context package | Belirli iş/tüketici için derlenmiş kaynak ve actual görünüm |
| Typed relation | Sadece “ilişkili” değil, önkoşul/destek/dönüş vb. türü belli bağlantı |
| Read-set | Sonucun veya değişimin dayandığı exact kayıt/sürüm kümesi |
| Outbox / inbox | Kalıcı değişimin yayımlanacak olayı ve tüketicinin alım/tekrar kaydı |
| Idempotency | Aynı niyetin tekrarının yeni etkiyi çoğaltmaması; farklı niyet aynı key ile geçmez |
| CAS / expected head | Değiştirilecek değer hâlâ beklenen değerse ilerleyen koşullu güncelleme |
| Artifact / assembly | Üretilen eser ve birden çok parça/sürümden oluşan exact bütün |
| Verdict / acceptance | İnceleme hükmü ve yetkili kullanım/kabul kararı; farklı kayıtlardır |
| Qualification | Belirli host/görev/ölçüt için yeterlik veya uygunluğun nitelendirilmesi |
| Readback / reconciliation | Dış gerçek durumu geri okuyup yerel kayıtla uzlaştırma |
| Cutover | Bir yazma/işletim otoritesinden diğerine açık, denetlenmiş geçiş |
| Residual | Henüz kapanmamış kusur, belirsizlik veya kabul sınırı |

# 21. Başlangıç mesajı ve kesintisiz devralma

## 21.1 Codex’e verilecek başlangıç

Aşağıdaki içerik START-HERE.md içinde de bulunur. Bu metin bütün hedeflere sınırsız deployment grant’ı değildir.

> Bu pakete göre DevOS’u kuracağız. Önce README, START-HERE, docs/P5.md, plan/build-plan.json ve baseline kaynak kimliklerini oku. Gerçek hedef repo/ref, mevcut AGENTS/override zinciri ve açık yetki sınırlarını doğrula. İlk iş K00’dır. Dosya okuma ve offline test yapabilirsin; hedef yazımı, servis açma, ücretli API, migration ve publication için gerçek scope/owner grant’ı göster. Önce bulunabilir bilgiyi kendin topla, yalnız owner kararlarını sor. P4/P5 kaynakları yoksa özetten uydurma. Her adımı source/criterion/target bağlı kanıtla ilerlet; kesintide açık işi ve return_to’yu canonical build ledger’a yaz. SOUL’un ilk gerçek teknik işini seçme; onu kurulan DevOS ekibi keşfedecek.

## 21.2 Yeniden başlatılan kurucu

Yeni Codex session, önce repo/ref ve source-lock’u okur. Ledger’daki current ticket, qualification, outstanding request, unknown effect ve return_to kontrol edilir. Var olan output hash’leri geri okunur; eski yeşil sonuç yeni source/config’e otomatik taşınmaz. Sonraki gerekli eylem source recovery, failed test diagnosis veya owner yetkisi olabilir; otomatik “kod yazmaya devam” değildir.

Yeni kurucu aynı yetkilendirilmiş build scope içinde işi sürdürebilir; her adımda Batu’nun iki agent arasında mesaj aktarması gerekmez. Ancak target hesabı veya grant artık geçerli değilse etkilenen action durur. STOP, PAUSE, CANCEL ve REVOKE farklıdır: durmak yeni iş açmaz; iptal candidate/etki tarihini silmez; yetki geri alma actual credential/epoch/effect kapısına yansır.

# 22. Bu pakette ölçülenler ve açık kalanlar

Yerel doğrulama envanteri qa/execution-manifest.json ve raw loglarda bulunur. 64 case **hedefte koşulacak test şartnamesidir**, bu paketi yazarken yapılmış 64 sistem deneyi değildir. 18 role source dosyasının varlığı ve compiler’ın çalışması da 18 etkin/yeterli agent anlamına gelmez.

Paket yardımcısının negatif testleri; bozuk kaynak kimliği, eksik return_to, yanlış role/method, path/symlink kapsamı, plan döngüsü, stale criterion/target ve eksik raw evidence gibi yerel hataları denetler. Kasıtlı guard kaldırma deneyleri ilgili assertion’ın kırılıp kırılmadığını gösterir. Bunlar aynı assistant’ın yazdığı code/testlerdir; bağımsız güvence değildir.

Son koşuda 42 paket yardımcı testi geçti; altı hedefli guard kaldırma deneyinin tamamı ilgili assertion’ı kırdı. V4’ün mevcut 53 referans testi aynı kaynak kimliğiyle yeniden koşuldu; bu model yerel SQLite ve geçici Git fixture kullanır. Actual Codex binary, PostgreSQL veya kullanıcının hesap/servisleri bu üretim ortamında doğrulanmış değildir. Optional API probe yalnız kaynak olarak hazırlanır; açık ücret/veri/hesap yetkisi olmadan çalıştırılmaz.

Bu nedenle doğru final statü: **P5-GUIDE teslimi hazır; hedefe bağlı K00–K15 uygulaması NOT_RUN; P6 ve SOUL gerçek çalışma başlangıcı açık.** Guide’ın hazır olması P4’ün bütün iddialarının ispatlandığı anlamına gelmez. Kalite için gerekli olan şey, bu açık yükleri kaybetmeden actual kurulumda kapatmaktır.

**Repository sürekliliği açık:** GitHub main bu teslim anında hâlâ `fdd44fdb849b49bd882950b52297cd63de40adfc` ref’inde ve P4 v4 / P5-next durumundadır. Bu oturumda sunulan GitHub araçları dosya yazma/commit/ref güncellemesi içermedi; terminal Git bağlantısı da DNS çözümleyemedi. Bu nedenle P5 kaydı main’e yayımlanmış sayılmaz. `repository-update/` son kullanıcı yönünü, mevcut dosya kimliklerine bağlı değişiklik tarifini ve yeni P5 kayıt gövdesini taşır. Yetkili GitHub yazma yolu açıldığında scope/diff ve uzak readback ile uygulanmalıdır. Bu açık yayın işi hedef DevOS kurulumu değildir; rehber ve kaynak dosyaları bu teslimde gerçektir.

# 23. Kaynaklar ve kanıt statüsü

Dış kaynaklarda yalnız ilgili resmî bölümler kullanıldı. 28 Eylül 2026 erişimi, future API/hesap eşdeğerliği garantisi değildir. URL’nin varlığı deploy başarısı değildir. Kontrol protokolleri araştırma kanıtı yapılmadı. Tüm Foundation/studies külliyatı yeniden okunmadı; selective reuse ve kaynak derinliği sources/reading-log.md içinde açık tutuldu.

**[P4] P4 v4 tam rapor ve özgün paket — `baseline/P4-v4.md`.** Tam 1020 satır; 31 bölüm. Sözleşme/rol/kanıt ve açık yeterliklerin tasarım kaynağı. Kurulu sistem değildir.

**[R01] [EXP006 current karar ve plan](https://github.com/batuhanozgun/agentic-os-search/tree/fdd44fdb849b49bd882950b52297cd63de40adfc/explorations/EXP-006-development-os-calisma-duzeni).** INDEX/STATE/HANDOFF/WORK/DECISIONS/P4-05 tam okuma. D027 Codex, D028 rapor sonra rehber. Yeni kullanıcı P5 ve runtime yönü bu teslimde ayrı kaydedilir.

**[R02] [RPD META ve bounded değerlendirme](https://github.com/batuhanozgun/agentic-os-search/tree/main/research/studies/recursive-prerequisite-discovery).** META tam; aynı oturumdaki assessment ayrımları seçici. Önkoşul≠alt görev; ready≠completed; inquiry/return_to korunur. Canlı yöntem yeterliği değil.

**[W01] [OpenAI — Agents API overview](https://developers.openai.com/api/docs/guides/agents-api/overview).** Yönetilen Codex harness, API-model/araç/container ücretleri. Veri yerleşimi mevcut kaynakta yalnız ABD; ZDR yok, self-hosted sandbox bunu değiştirmiyor. Actual hesap erişimi ayrıca gerekir.

**[W02] [OpenAI — Agents API architecture](https://developers.openai.com/api/docs/guides/agents-api/architecture).** Uygulama server’ı, yönetilen harness ve isteğe bağlı execution environment farklı kaynak/sorumluluklar. Seçici mimari okuma.

**[W03] [OpenAI — Agents API quickstart](https://developers.openai.com/api/docs/guides/agents-api/quickstart).** Beta arayüz, hesap/SDK ve API-key izinleri. Açılan kaynakta api.agents.read, api.agents.write ve api.responses.write; actual proje/SDK keşfi K00’da.

**[W04] [OpenAI — Multi-agent](https://developers.openai.com/api/docs/guides/agents-api/multi-agent).** Native subagent kendi context’iyle çalışır; configured MCP araçlarını ve erişimlerini miras alır; function tools desteklemez. Yetki alanı ve parent/separate session tasarımını etkiler.

**[W05] [OpenAI — Functions](https://developers.openai.com/api/docs/guides/agents-api/tools/functions).** Pending required_actions, session/turn/call kimlikleri, tool-result dönüşü. Disconnect sonrası saved result ve side-effect outcome birlikte değerlendirilir.

**[W06] [OpenAI — Configuring Agents](https://developers.openai.com/api/docs/guides/agents-api/configuration).** Kaydedilmiş agent değişimi mevcut session’ı değiştirmez. Instructions/tools/multi_agent gibi alanlar için yeni session gerekir.

**[W07] [OpenAI — OpenAI-hosted sandboxes](https://developers.openai.com/api/docs/guides/agents-api/environments/openai-hosted).** Environment provisioning/setup, files, packages ve network sınırları seçici okundu. Template dosya kalıcılığı değildir; varsayılan ağı kapalı sanma. Actual config qualification gerekir.

**[W08] [OpenAI — Sandbox security](https://developers.openai.com/api/docs/guides/agents-api/environments/security).** Uygulama key’i ile sandbox/executor yetkisi ayrı; generated code’un eriştiği secret ve dosya gerçekten agent alanındadır. Protected tools uygulama sınırında tutulur.

**[W09] [OpenAI — Sandbox lifecycle](https://developers.openai.com/api/docs/guides/agents-api/environments/lifecycle).** Session, bağlı environment, replacement compute ve dosya recovery’si eşitlenmez. Reconnect/restore garanti kapsamı seçici okundu.

**[W10] [OpenAI — Session webhooks](https://developers.openai.com/api/docs/guides/agents-api/sessions/webhooks).** Webhook action_required, durum değişimleri ve session/turn sonucu ayrımı. Session/compute cleanup farklıdır; event sonrası authoritative retrieval gerekir.

**[W11] [OpenAI — Custom instructions with AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md).** Native repo guidance keşfi ve override/limit; yeni run’da yüklenme. API session’ın bu dosyaları kendiliğinden okuyacağına kanıt değildir.

**[W12] [PostgreSQL — Transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html).** Read Committed ve Serializable ayrımı; serializable failure sonrası transaction tekrar koşulu. Sequence değeri commit watermark değildir.

**[W13] [Supabase — MCP server](https://supabase.com/docs/guides/ai-tools/mcp).** Proje kapsamı/read-only/feature sınırları; yönetim MCP’si geliştirme/test aracıdır. Production runtime’ın genel SQL aracı olarak seçilmedi.

**[W14] [Supabase — Securing your API](https://supabase.com/docs/guides/api/securing-your-api).** Grant ve RLS farklı; özel exposed schema, internal schema ve Data API’yi kapatma seçenekleri. Defaults hesabın gerçek durumundan gözlenir.

**[W15] [Supabase — Securing your data](https://supabase.com/docs/guides/database/secure-data).** Trusted server direct database bağlantısı, secret/service_role sınırı. Yönetilen hosting kullanımı güvenlik kurallarını kendiliğinden kurmaz.

**[W16] [GitHub — REST references](https://docs.github.com/en/rest/git/refs).** force=false fast-forward kontrolüdür. Endpoint gövdesindeki sha hedef commit’tir; expected-old compare-and-set alanı değildir.

**[W17] [GitHub — GraphQL commits](https://docs.github.com/en/graphql/reference/commits).** createCommitOnBranch / expectedHeadOid koşullu commit yolu. Kimlik/provider/branch policy ve timeout behavior target test ister.

**[W18] [FastAPI — Manual deployment](https://fastapi.tiangolo.com/deployment/manually/).** ASGI server ile uygulama barındırma; process çalışması HTTPS/restart/resource denetimini otomatik kurmaz. Runtime framework için kaynak, DevOS kanıtı değil.

**[W19] [Psycopg — Transactions](https://www.psycopg.org/psycopg3/docs/basic/transactions.html).** Connection ve transaction context sınırları; idle-in-transaction riski. Driver dev doküman sürümü target pin olarak kullanılmaz.

**[W20] [OpenAI — Agents integration choices](https://developers.openai.com/api/docs/guides/agents).** Agents API managed Codex harness ile Agents SDK uygulama döngüsü ve Responses farklıdır. Aynı isimli session nesneleri eşit sayılmaz.
