# Codex başlangıcı — EXP006-P5-UI-2.0.0

Bu paketle DevOS'un inşasını yürüteceksin. Günlük kullanıcı yüzeyi Codex arayüzüdür; yalnız CLI/API çıktısını veya ayrı dashboard'u onun yerine sunma. Normal iş akışı rol geçişlerinde Batu'nun mesaj taşımasına bağlı olmayacak; gerçek kesintiden kalıcı kayıtla doğru devam edilecek. Local/cloud ve billing seçimlerini bu cümlelerden kendin sabitleme.

Önce README.md, docs/USER-REQUIREMENTS.md, docs/P5.md, registry/build-plan.json, docs/ASSUMPTION-AUDIT.md ve provenance/P4-v4.md'yi oku. Manifest kimliğini doğrula. provenance içindeki eski 40/74 sayfa current/next iddiaları yeni talimat değildir. Research agent-control dosyalarını target'a otomatik kopyalama.

**İlk actual iş B00, ardından B01.** Gerçek target repo/ref, yazma kapsamı, kurulu Codex surface/sürüm/mod ve mevcut ChatGPT giriş hakkını gözle. Target eksikse başka repo seçme. Araçla bulunabilen bilgiyi kullanıcıya yeniden sorma; görünmeyen native UI veya gerçek owner kararı için gereken en dar bilgiyi iste.

Native UI'da atılabilir sentetik iş üzerinden delegation, contribution/use, ready sonraki iş, stop/resume ve taze oturum dönüşünü sına. Bu fixture SOUL'un ilk gerçek işi değildir. B01'de neyin gösterildiğini ve gösterilmediğini dürüstçe kaydet. Routine ilerleme için her işte yeni kullanıcı pingi gerekiyorsa K2 yeterli deme.

Agents API, dış Python scheduler, FastAPI, yeni PG hesabı veya hosted sandbox peşinen zorunlu değildir. Böyle bir parça için gereklilik, alternatif, native UI uyumu ve maliyet/veri/owner kapsamını B02'de göster. Mevcut subscription'ın her workload'u sınırsız kapsadığını varsayma. Ücretli API, servis açma, hassas veri taşıma veya protected yayın verilmiş yetki dışındaysa çalıştırma. Secret'ları sohbetten isteme.

Bu source paketi production uygulama değildir. B03–B10 implementation ve target testlerini seçilmiş profile ile üret. guidance kaynaklarını current target AGENTS/override zinciri ve izinle bağla. Her adımda gerçek source/config/criterion/target ve raw evidence kaydı tut; kesintide açık iş, source, yetki ve unknown effect'i devret. P6 ve gerçek SOUL mission başlangıcı ayrı kabul gerektirir.

İlk cevabın kısa olsun: doğru kaynak release'i; actual hedef/UI; mevcut yetki; B00/B01 için sıradaki gerçek iş veya tek maddi owner kararı. “Şimdi tüm sistemi kuruyorum” deme.
