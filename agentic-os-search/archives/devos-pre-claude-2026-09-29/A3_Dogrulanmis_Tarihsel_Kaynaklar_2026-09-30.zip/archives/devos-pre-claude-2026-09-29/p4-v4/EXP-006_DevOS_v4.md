# SOUL'u geliştirecek çalışma düzeni
## EXP-006 · Codex hedef ortamına göre mimari revizyon · v4

**28 Eylül 2026 — P4 tasarım değerlendirmesi.** Bu belge bir DevOS kurulumu veya SOUL yeterlik sertifikası değildir. Doğrulanmış v2 kaynaklarından yeniden kurulmuş bütünleşik tasarım önerisi, gerçek yerel karşı örnekler, düzeltilmiş sınırlı referans model ve hedef ortamda yapılması gereken kabul programıdır. Sayfa sayısı içerikten doğar; eski 200 sayfa şartı uygulanmaz.

### Okuma anahtarı

**Tasarım önerisi** bu raporun seçtiği fakat kullanıcıca mimari kabulü verilmemiş yoldur. **L** bu oturumda çalıştırılmış yerel Python, SQLite veya Git gözlemidir. **S** güncel birincil belge okumasıdır. **D** sözleşme karşılaştırması veya açık varsayımlı masa başı çözümlemesidir. **H** hedefte henüz yapılmamış deneydir. Aynı nesne için bu durumlar karıştırılmaz. Metindeki [B], [L], [W] ve [R] işaretleri kaynak bölümüne gider.

# 1. Sonuç: yapı korunuyor, güven sınırı ve kritik sözleşmeler değişiyor

V2'nin temel yönü — bilişsel ekip, korunan kontrol, canlı iş/bilgi durumu, sürümlü ürün, kaynak temelli bağlam ve bağıntı mühendisliği — bu incelemede terk edilmedi. Ancak bu yönü adlandırmak, parçaların aynı anlamda çalışmasını sağlamıyor. En önemli açık, bazı güçlü metinsel vaatlerin daha dar kod veya örnek sözleşmeler üzerinden doğrulanmış sayılabilmesidir. Yeni rapor bu geçişleri açıkça keser: tasarımın söylediği, şemanın temsil ettiği, yerel kodun zorladığı ve gerçek ortamın gerçekleştirdiği şeyler ayrı ayrı gösterilir. [B1–B4, L1–L4]

Dört eski, doğrulanmamış ipucu artık yeniden üretilebilir bir kapsam kazandı. Aynı işlem anahtarı, v2 referans modelinde farklı hedef veya taban revision ile aynı makbuzu alabiliyor. Eksik bağlam, kendi ilan ettiği boş eksik listesi ve kendi hesapladığı hash ile kabul edilebiliyor. Yedek geri getirildiğinde daha sonra geçersizleştirilmiş görevlendirme yeniden geçerli görünebiliyor. Grafik bölümündeki bütün yolları taşıyan SQL örneğinin yerel eşdeğerinde, küçük bir elmas ağ çok fazla satır üretiyor. Son bulgu v2 Python `reachable` işlevine uygulanmaz; o zaten ziyaret edilmiş nesneleri ayırır. [L1]

İnceleme bu dört başlıkla sınırlanmadı. Bağlamın hedef kapsamı, ilişki/görevlendirme değişimlerinin olay izi, claim sonrasında değişen önkoşullar ve dış etki gözlemlerinin tarihçesi için de karşı örnekler üretildi. Bunlar sekiz bulgu kaydıdır; sekiz production arızası değildir. V2 metninin bu sorunların tamamını hiç düşünmediği iddia edilmez. Çoğunda sorun, ilkenin referans kodda eksik somutlanması veya bir sorgu örneğinin yanlış yeniden kullanıma açık kalmasıdır. [L1, B3]

V3 yerel modelinde 53 adlandırılmış test geçti. V2'nin 40 testi ayrıca yeniden geçti; iki sayıyı toplayıp “93 test ile mimari doğrulandı” demek yanlış olur. Yeni testlerde sonlu mantık karşılaştırmaları, bütün üç düğümlü yönlü ağlar, eşzamanlı claim/ilişki yarışı ve gerçek yerel Git ref işlemleri bulunur. Sekiz hedefli kontrol bozmasından yedisi ilgili doğruluk iddiasını bozan durumu bir assertion ile yakaladı. Bir bağlam kontrolü bozması ise sonraki aşamada `KeyError` üretti; bu, aynı kuvvette invariant doğrulaması sayılmadı. [L2–L4]

**Temel hüküm:** P4 için daha açık, yanlışlanabilir ve kendi kanıt sınırını taşıyan tasarım korunur; fakat hedef Environment artık **Codex** olarak bağlanmıştır. V3'ün yerel mekanik kanıtları bu revizyonda yeniden koşulmuş olsa da Codex'te K1/K2, gerçek PostgreSQL, korunan kimlik ve yayın sınırı, tam restore veya SOUL'un bilişsel başarısı henüz hedefte gösterilmiş değildir. Environment değişikliği bu açıkları ortadan kaldırmaz; hangi Codex yüzeyinin onları nasıl taşıyacağını somutlaştırır.

# 2. Amaç, yetki ve inceleme nesnesi

## 2.1 DevOS ne için var?

DevOS'un işi, kendisine hazır verilmiş bir SOUL backlog'unu sırayla çalıştırmak değildir. SOUL'u geliştirmek için gerekli işleri keşfeden, araştıran, alternatiflerini tartan, geliştiren, sınayan ve sonuçlarını yeniden kullanan ekibin çalışma düzenini sağlamaktır. Assistant bu raporda SOUL'un ilk gerçek işini seçmez. İhtiyaç keşfinin ve sonraki iş seçiminin hangi yetki, bilgi, değerlendirme ve kayıt ilişkileri içinde yapılacağını tasarlar. Bu ayrım korunmazsa DevOS daha başlamadan kendi varlık gerekçesini kaybeder. [R1, R2]

SOUL hedefi, tek bir yazılım komutunu yerine getirmekten geniştir. Gerekli işi bulmak; işe uygun çalışma sistemi oluşturmak; araştırmayı gerçekten karara ve üretime katmak; uzun ve bileşik ürünleri sürdürmek; hatayı, değişimi ve kesintiyi yönetmek; yöntemleri gerekçeli biçimde seçmek ve uyarlamak bu hedefin yükleridir. Bu rapor onları yeni bir nihai ontoloji olarak dondurmaz. Mevcut çalışma hedefini yeterince somut gereklilikler ve sınama soruları olarak kullanır. [R1–R3]

## 2.2 Korunan kullanıcı sınırları

Hedef actor platformu artık **Codex**'tir. Bu karar P4'te ürün/harness ailesini bağlar; Claude Code cloud artık current hedef değildir. P5 için birincil teknik aday, OpenAI'nin yönettiği Codex harness'ını programatik olarak sunan **Agents API**'dir; exact execution environment'ın `openai_hosted` mı `self_hosted` mı olacağı, protected effect ve persistence gereksinimlerine göre P5'te nitelendirilecektir. Codex uygulaması/CLI geliştirme veya operatör yüzeyi olabilir, fakat canonical Work authority'nin kendisi sayılmaz. Kullanıcının bilgisayarını sürekli açık tutmak veya rutin adımların taşıyıcısı yapmak varsayılan çözüm değildir. K1, roller arası talebin çalışmaya, yanıtın da gerçek kullanıma bağlanmasıdır. K2, rutin rol geçişlerinin Batu'nun tek tek mesaj göndermesine bağlı olmamasıdır. Başlatma, yeniden başlatma, anlamlı müdahale, yetki verme ve kabul mümkündür. [R1] [W1] [W2]

Batu'nun çekirdek rolü yetki ve kabuldür; eksik teknik önkoşulları sürekli hatırlatan gizli mühendis ya da mesaj taşıyan koordinatör değildir. Teknik doğruluk, kullanıcının onayına dayanarak doğrulanmış sayılamaz. Kullanıcı bir amacı veya tercih sınırını belirler; ekip bunun nasıl gerçekleştirileceğini araştırır ve kanıtıyla tartışır. Bir tercih çatışması ile bir olgu uyuşmazlığı farklı çözüm yolları ister.

Ürün içeriğinin sahibi anlamı ve gerekçeyi taşır. Çalışma alanı tarafı yer, statü, kaynak/sürüm ilişkisi, bulunabilirlik, bakım, devir ve yeniden kullanımı taşır. İkinci sorumluluk anlamdan tamamen habersiz bir dosyalama işi değildir; fakat ürün kararını kendi kendine devralma yetkisi de değildir. G ürün geliştirme, Y çalışma düzeninin yürütülmesi ayrımı bu sorumlulukların takibini kolaylaştırır; her ayrım fiziksel bir ekip, süreç veya servis oluşturmaz. [R1: D021]

## 2.3 Bu raporun durduğu sınır

P4, bütünleşik tasarım ve sınama programıdır. P5 gerçek kurulum, P6 hedefte kabul çalışmasıdır. Yerel referans kod üretmek bu raporun iddialarını dar bir alanda sınamak içindir; DevOS'un kurulmuş olduğu anlamına gelmez. PostgreSQL, takımlar, graph sorguları veya bir publisher bu belgede önerildi diye kullanıcı tarafından seçilmiş sayılmaz. Önceki P4-01'in dosya/Git ağırlıklı çalışma durumu da sırf daha önce yazıldığı için current çözüm değildir. [R1, R2]

Sayfa sınırının kaldırılması “daha fazla servis”, “daha çok ajan” veya “daha uzun metin” talimatı değildir. İncelemenin sorusu, gerekli kapasitenin eksiksiz adlandırılması ve onu taşıyan mekanizmaların birbirine nasıl bağlandığıdır. Gereksiz yinelenen açıklama kaldırılabilir; yük taşıyan ayrım, karşı örnek, alternatif ve uygulanabilirlik sınırı kaldırılmaz. Eksiklerin eski 200 sayfa sınırından kaynaklandığına ilişkin nedensel kanıt bulunmadı.

# 3. İnceleme yöntemi ve kanıt düzeni

## 3.1 Kaynak tabanı yeniden kuruldu

Yeni oturuma eklenen devir ZIP'si açıldı. İçindeki v2 PDF ve kaynak ZIP'nin byte uzunluğu ve SHA-256 değerleri canonical kayıttaki değerlerle eşleşti. İç ZIP manifest'indeki 22 üyenin boyut/hash değerleri de eşleşti. Bu, okunan dosyaların kimliğini doğrular; içerik doğruluğunu veya mimari yeterliği değil. V3 diye önceki yanıtta sözü edilen teslim ve 88 test bu başlangıca alınmadı. [B1, L0]

V2'nin 200 bölüm/sayfa işaretli Markdown gövdesi sıralı okundu; kısalan araç çıktıları gerekli aralıklar açılarak tamamlandı. Sözleşmeler, model, test ve mutation kodu raporla birlikte incelendi. V2 kaynak kataloğunun varlığı, oradaki 52 dış/özel kaynağın bu oturumda yeniden tam okunduğu anlamına gelmez. Bu turdaki taze teknik okuma seçici ve dört resmî belgeyle sınırlıdır. RPD ve EXP-004'ün ilgili değerlendirmeleri de mevcut soru için geri çağrıldı. [B2–B4, R3–R4, W1–W4]

## 3.2 Sonuçtan önce tutulan ölçütler

`source/stress-plan.md`, yeni karşı örnekler koşulmadan önce yazıldı. İşlem kimliği, tüketici bağlamı, restore yetki dönemi, graph tamlığı, scope, değişim–olay atomikliği, etki tarihçesi, güncel önkoşullar, grant/read-set ve dış yayın uzlaştırması için olumlu/olumsuz koşullar belirlendi. Test kodunun ayrıntıları daha sonra geliştirildiği için çalışma bağımsız bir holdout deneyi olarak sunulmaz.

Her kusur incelemesinde iki soru ayrıldı: yanlış durum neden oluşuyor ve mevcut kontrol neden bunu dışlayamıyor? Örneğin restore sırasında sayacın geriye dönmesi yakın nedendir; geçerli yetki döneminin aynı geri döndürülebilir state içine hapsedilmesi tasarım nedenidir. Yalnız sayacı büyütmek bu ikinci sorunu kapatmaz. Aynı şekilde bağlam hash'inin doğru olması, gerekli yüklerin bulunduğunu değil yalnız verilen görünümün değişmediğini gösterir.

## 3.3 Kanıt birimi test sayısı değildir

Bir test adı altında yüzlerce sonlu girdi yürütülebilir; bu, yüzlerce gerçek görev başarısı değildir. Bir testin yanlış durumda kırmızı vermesi, yalnız ölçtüğü yanlışı ayırt ettiğini gösterir. Ayrı algoritmalı reachability karşılaştırması ortak uygulama hatası riskini azaltır; aynı yazarın senaryoyu eksik kurmuş olmasını dışlamaz. Üretici, reviewer ve oracle'ın kaynak, çerçeve veya kabul ölçütünü ortak taşıması ayrıca değerlendirilir.

Ölçüm sonuçları şu sorularla birlikte saklanır: nesne/sürüm neydi, başlangıç koşulu neydi, hangi giriş verildi, ne gözlendi, beklenen sonuç nereden geldi, ne yapılmadı? Modelden dış hizmete, yerelden cloud'a veya mekanikten bilişsele geçerken yeni bir kanıt yükü doğar. Bu raporun tabloları böyle geçişleri bir “PASS” sütununda toplamaz.

# 4. SOUL gereksinimleri DevOS kapasitesine nasıl dönüşüyor?

## 4.1 Gereklilik zinciri

Bir SOUL kapasitesi önce DevOS'un yapması gereken işe çevrilir. İş, bilgi ve karar ihtiyaçlarını doğurur; bunlar sorumluluklara; sorumluluklar rol veya mekanik denetime bağlanır. Araç seçimi bu zincirin sonunda gelir. “Bir araştırmacı ajanımız var” demek, hangi belirsizliği hangi derinlikte azaltacağı ve sonucu kimin kullanacağı tanımlanmamışsa yeterlik değildir. “Graph var” demek de hangi değişim veya gerekçe sorusunu doğru yanıtladığı bilinmiyorsa çözüm değildir.

| SOUL yükü | DevOS'un taşıması gereken iş | Gözlenebilir yeterlik sorusu |
|---|---|---|
| Gerekli işi keşfetmek | Önkoşul, alternatif yöntem, eksik yetki ve bilgi ihtiyacını bulmak | Kullanıcı işaretlemeden maddi eksiği buluyor, gereksiz iş üretmiyor mu? |
| İşe özgü sistem oluşturmak | Rol, yöntem, araç, bilgi ve kontrol bileşimini seçmek | Seçim gerçekten işin koşullarına uyuyor mu; yeni rol adıyla kapasite varsayılıyor mu? |
| Araştırmayı kullanmak | Kaynak bulma, yorumlama, koşullama ve tüketiciye geri dönüş | Kaynak kararı değiştirdi mi, sınırladı mı veya mevcut yolu gerekçelendirdi mi? |
| Uzun/bileşik ürün üretmek | Parça revision'larını bütünün niyeti ve kabulüyle bağlamak | Parçalar ayrı ayrı iyi görünürken bütün yanlış kalıyor mu? |
| Kesintiden dönmek | Açık iş, yetki, etki ve bilgi durumunu yeniden kurmak | Kaybolan oturum eski yetkiyi veya yanlış tamamlanmayı canlandırıyor mu? |
| Yöntemi uyarlamak | Uygulanabilirlik, birleşim, regresyon ve kalıcılığı sınamak | Ders kaydı yeni görevde doğru yerde seçiliyor ve gerçekten fayda sağlıyor mu? |

Bu tablo nihai SOUL mimarisi veya backlog değildir. Tasarımı sorgulama aracıdır. Her satır için hem yanlış başarı hem gereksiz blokaj karşı örneği gerekir. Örneğin bütün final kriterleri bilinmiyor diye anlamlı bir araştırma işini başlatmamak da bir başarısızlıktır. [R3, R4]

## 4.2 Başlangıç döngüsü nasıl açılır?

DevOS'un iş keşfine başlayabilmesi için bütün gelecekteki SOUL tasarımını bilmesi gerekmez. Başlangıç paketi, yetkili amaç ve sınırları; eldeki araştırma giriş yollarını; mevcut ortamın doğrulanmış ve belirsiz imkânlarını; kaynak tüketim bütçesini; kabul ve müdahale yolunu taşır. Bu paket bir SOUL backlog'u değil, ekibin keşfe başlayabileceği yetkili zemindir.

İlk keşif Work'ünün çıktısı otomatik teknik uygulama emri değildir. Hangi gerekliliklerin zaten karşılandığını, hangilerinin açık olduğunu, hangi alternatif yolların farklı önkoşullar doğurduğunu ve hangi bounded bilgi edinme işlerinin başlayabildiğini gösterir. Ekip ilk gerçek işi bu değerlendirmeyle seçer. Assistant'ın bu raporda önceden seçtiği bir modülü “örnek” diye zorunlu başlangıca çevirmesi engellenir.

Başlangıç düzeninin kendisi de eleştirilebilir. Gerekli bir bilgi veya yetki eksikse bootstrap incelemesi açılır; fakat her yeni belirsizlik için bütün bir meta-sistem kurmak zorunlu değildir. Mevcut koşullar bir bilgi edinme denemesine yetiyorsa o deneme yapılabilir. Bitmemiş önkoşul keşfi, yürütülmüş geliştirme ve kabul edilmiş sonuç ayrı kalır. [R4]

# 5. Bütünleşik mimari: altı sorumluluk, tek tip doğruluk değil

## 5.1 Mantıksal yapı

Önerilen düzen altı sorumluluk alanı kullanır: bilişsel çalışma; yetkili durum geçişi; bilgi ve context; türlendirilmiş ilişkiler; korunan dış etki; gözlem ve değerlendirme. Bunlar altı mikroservis kurma talimatı değildir. Bazıları aynı uygulama sürecinde yaşayabilir; aynı güven sınırına konulmaları ise ayrıca gerekçelendirilmelidir.

Bilişsel taraf problem çerçevesini, araştırmayı, tasarımı, üretimi ve eleştiriyi taşır. Kontrol tarafı hangi değişimin hangi yetki ve sürüm koşuluyla yapılabileceğini zorlar. Bilgi/context tarafı kaydı modele uygun ama niteliklerini koruyan görünüme taşır. İlişki tarafı gerekçe, bağımlılık, kaynak ve etki sorularını çözer. Publisher gerçek dış etkiden sorumludur. Gözlem/değerlendirme ise gerçekleşeni kabul iddiasından ayırır.

Bu ayrımın amacı modeli tüm kararların dışına atmak değildir. Hangi araştırma sonucunun anlamlı olduğu, hangi yaratıcı seçimin uygun olduğu veya hangi alternatifin daha iyi gerekçelendiği çoğu zaman muhakeme ister. Mekanik kapı bunları kendi başına doğru yapmaz. Ama muhakemenin geçerli yetkiyi, yanlış hedefi, eski revision'ı veya olmayan kaynak kapsamını sessizce değiştirmesini engelleyecek bağları koruyabilir.

## 5.2 Veri otoritesi

**Canlı Work, Request, Assignment, Grant, Review, Operation ve relation state için PostgreSQL önerisi korunur.** Gerekçe, bu nesnelerin eşzamanlı değişim ve durum geçişlerini birlikte denetleme ihtiyacıdır. Bu seçim burada gerçek PostgreSQL üzerinde sınanmadı; SQLite sonuçları bu seçimi doğrulamaz. Kurulumdan önce sorgu planı, isolation, constraint, migration, outbox, restore ve erişim modeli hedef sürümde denenmelidir.

**Ürün içeriği ve yayımlanmış rol/yöntem/politika release'leri Git sürüm otoritesidir.** Canlı assignment veya kuyruk durumunun ikinci bir bağımsız Git kopyası oluşturulmaz. Markdown çalışma panoları ve insan raporları türetilmiş görünüm olarak işaretlenir. Bir görünümden düzenleme kabul edilecekse bu, canonical command kapısına çevrilen bir öneri olur; görünüm kendi başına yeni truth kaynağı olmaz.

**Kaynak ve kanıt gövdeleri** içerik kimliği, erişim politikası ve retention koşullarıyla korunur. Hash değişmezlik kontrolüne yardım eder; erişim, doğruluk, kullanım yetkisi veya anlam kanıtı değildir. Bir kaynağın silinmesi gerektiğinde yalnız index'i temizlemek yetmez: gövde, önbellek, türetilmiş view ve yedek davranışı birlikte değerlendirilir.

## 5.3 Alternatifleri neden dışlamıyoruz?

Dosya/Git temelli yapı küçük veya az eşzamanlı işte daha az operasyon yükü getirebilir. Fakat önerilen DevOS'un canlı lease, revocation, geçiş, shared dependency ve publication uzlaştırmasını dosya kilidi/sürümleriyle yeniden kurması gerekir. Bu mekanizmalar gerçekten daha basit ve güvenilir biçimde kurulabiliyorsa seçenek yeniden değerlendirilebilir. “DB var, o halde sağlam” da “dosya kolay, o halde yeterli” de gerekçe değildir.

Ayrı graph veritabanı veya dayanıklı workflow motoru da otomatik alınmaz. Sorgu biçimi, path sorgularının gerçekten gerekli kapsamı, işlem sınırları, uzmanlık ve işletim maliyeti üzerinden karşılaştırılır. Bu rapordaki path çoğalması veritabanı markası değiştirilerek kendiliğinden çözülmez; yanlış sonuç birimi başka motorda da pahalı olabilir. Ayrı index veya graph projection seçilirse source-of-truth, gecikme, scope ve replay sözleşmesi yine gerekir.

# 6. Rol düzeni, yeterlik ve G/Y işbölümü

## 6.1 Rol, agent ve principal aynı değildir

Rol belirli bir işte amaç, bilgi ihtiyacı, teslimat ve sorumluluk tanımlar. Agent çağrısı o rolü belirli bağlamda taşıyan çalışma örneğidir. RuntimePrincipal gerçek erişim/yetki sınırının kimliğidir. Bu üç nesne eşit değildir. Aynı model farklı rolleri taşıyabilir; aynı runtime içindeki ayrı rol adları ayrı güvenlik kimliği veya bağımsız reviewer üretmez.

V2'deki 16 kök rolün G/Y farklarıyla 18 çalışma profili olarak açıklanması korunur; 18 sürekli agent çalıştırma kararı yoktur. Her işin gereksiniminden uygun roller çağrılır. Tek rolün birkaç sorumluluğu taşıması mümkün; çıkar çatışması, ortak körlük veya erişim ayrımı önem kazanırsa ayrıştırılır. Ajan sayısını büyütmek, kötü ayrıştırılmış işi daha iyi tanımlamaz. [B2: roller]

## 6.2 Sorumluluk haritası

| Profil | Taşıdığı karar/üretim sorumluluğu | Devredemeyeceği sınır |
|---|---|---|
| DR01 — ihtiyaç/iş keşfi | Amaçtan eksik koşul ve başlanabilir inceleme çıkarır | Kendi çerçevesini eleştirilemez kılmaz; kullanıcı adına ürün tercihi uydurmaz |
| DR02 — kabiliyet/sistem tasarımı | İşin gerektirdiği aktör, yöntem, araç ve kontrol birleşimini kurar | Rol talimatını gösterilmiş kapasite saymaz |
| DR03 — bütünleştirme | Parça çıktısını exact assembly ve bütün hedefe bağlar | Yerel PASS toplamını bütün kabulü yapmaz |
| DR04 — sınama tasarımı | Hata sınıfı, oracle, pozitif kontrol ve kanıt sınırını kurar | Sonuca göre kriteri sessizce gevşetmez |
| DR05 — geliştirme/üretim | Yetkili taslak veya ürün değişimini üretir | Kendi çıktısını tek başına bağımsız doğrulama saymaz |
| DR06-G — ürün koordinasyonu | SOUL geliştirme işlerinin bağı, önceliği ve dönüşünü taşır | Y çalışma sağlığını veya Batu'nun yetkisini ele geçirmez |
| DR06-Y — işletim koordinasyonu | Dispatch, bekleme, kesinti, kapasite ve devri yürütür | Teknik/ürün doğruluğunu çalışma durumundan çıkarmaz |
| DR07 — bilgi ve çalışma alanı düzeni | Kaynak, konum, statü, ilişkiler, bakım ve bulunabilirliği korur | İçerik sahibinin anlam kararını otomatik yeniden yazmaz |
| DR08 — context oluşturma | Tüketicinin yüklerinden kaynaklı görünüm derler | Zorunlu yükleri kendisi azaltıp başarı ilan etmez |
| DR09 — görevlendirme | Yeterlik, erişim, çalışma yükü ve bağımsızlık ihtiyacına göre taşıyıcı seçer | Yetki grant'ını kendi kendine yaratmaz |
| DR10 — ortam/kabiliyet | Gerçek erişim, araç, adapter ve kapasiteyi nitelendirir | Dokümandaki kabiliyeti actual hostta kurulmuş saymaz |
| DR11 — sınama yürütme | Sabitlenmiş deneyleri, logları ve ortamı üretir | Fixture sonucunu daha geniş nesneye genellemez |
| DR12 — yetki/kontrol | Scope, grant, principal ve effect bağlarını uygular/inceletir | Anlamsal kalite oracle'ı olmaz |
| DR13-G — ürün incelemesi | Hedef, kaynak ve exact ürüne karşı iddiaları sınar | Başka etiketle aynı öncülleri tekrar etmeyi bağımsızlık saymaz |
| DR13-Y — çalışma düzeni incelemesi | K1/K2, durum, kayıt, erişim ve kontrol açıklıklarını sınar | Ürün tercihini operasyon kusuru diye değiştirmez |
| DR14 — teşhis/toparlanma | Yakın neden, kontrol açığı, gerçek etki ve tekrar yolunu ayırır | Başarılı retry'ı kök çözüm saymaz |
| DR15 — yöntem/öğrenme | Dersin uygulanabilirliği, release'i, transferi ve regresyonunu taşır | Bir görevde faydayı genel yöntem başarısı yapmaz |
| DR16 — araştırma | Belirsizliği uygun kaynak ve karşı kanıtla azaltır | Kaynak varlığını karar desteğiyle karıştırmaz |

## 6.3 Her görevlendirmede somut sözleşme

Bir role yalnız “araştır”, “incele” veya “koordinasyon yap” denmez. Work kimliği ve amacı; istenen katkı; hangi üst karar veya tüketiciye döneceği; kapsam/dışlanan işler; gerekli kaynak derinliği; bağlam ve yetki release'i; teslim biçimi; kabul ölçütü; açık belirsizlik ve durma koşulu atanır. Bunlar görev anındaki yetkiyi oluşturmaz; geçerli grant'a bağlanır.

Yeterlik kaydı role genel bir iyi/kötü puanı vermez. Hangi görev sınıfında, hangi araç ve bağlamla, hangi oracle karşısında, hangi revision'da işe yaradığını tutar. Yeni bir probleme transfer belirsizliği ayrıca taşınır. DR09, uzman etiketini kanıt diye kullanamaz; gerekli yeterlik yoksa deney/araştırma veya insan uzman ihtiyacı açılır. Bu ihtiyaç gerçek olduğunda Batu'ya teknik bulmacayı çözmesi için değil, erişim/yetki/kabul kararı için dönülür.

## 6.4 Ortak körlük ve root yetkisi

G koordinatörünün yanlış problem çerçevesi bütün uzmanlara ortak verilebilir. Her uzman kendi dar görevinde iyi iş yaparken bütün sistem yanlış hedefe ilerleyebilir. Bu yüzden root frame ve decomposition da review nesnesidir. Belirli kritik geçişlerde reviewer yalnız maker açıklamasını değil, ham talebi, kaynakları, alternatif analiz birimini ve kullanılmayan kanıtı görebilmelidir. Ancak her kararı her seferinde baştan araştırmak zorunlu değildir; yeni maddi kanıt, değişen hedef veya açıklanmayan residual bu dönüşü tetikler.

Reviewer'ların aynı runtime/model içinde bulunması yararlı çapraz incelemeyi yok saydırmaz. Yalnız güven iddiasını sınırlar. Güvenlik principal ayrımı, epistemik bağımsızlık ve rol sorumluluğu üç farklı eksendir. Yüksek etkili yetki/politika değişiminde bağımsız korunan owner yolu gerekirken, rutin araştırma katkılarının tamamı insan kapısına bağlanmaz.

# 7. İş keşfi ve yaşayan plan

## 7.1 İhtiyaç, önkoşul ve alt görev ayrımı

Bir işi parçalara bölmek ile onu yapılabilir kılan koşulları keşfetmek farklıdır. “Bölüm yaz” görevini beş alt bölüme ayırmak, temel varsayımın yanlış olduğunu veya kullanıcı kabul sınırının eksik kaldığını bulmayabilir. RPD bu çalışma için hedefin gereği, seçilen yöntemin gereği ve zaten sağlanan zemin arasındaki ayrımı besler. Bu, RPD'nin başka yöntemlerden üstünlüğünün veya genel etkinliğinin doğrulanması değildir. [R4]

İhtiyaç kaydı en azından üst amacı, beklenen değerini, koşul/method bağını, destek ve karşı kanıtı, açık varsayımları, alternatifleri, agent-relative başlanabilirliği ve dönüş noktasını tutar. Bir yöntemden vazgeçildiğinde yalnız o yöntemin önkoşulları otomatik evrensel gereklilik olarak kalmaz. İki ihtiyacın adı aynı diye birleştirilmesi de yanlış olabilir; scope, sürüm, zaman, kaynak ve tüketici farklılıkları korunur.

## 7.2 Keşiften yürütmeye geçiş

Önce bir inquiry sonucu oluşur: “Şu eksik koşul bu hedef için maddi; şu yollar makul; şu dar eylem şimdi başlanabilir.” Bunun Work'e kabulü, yetki ve kaynak sınırıyla yapılır. Accepted Work çıktı üretince parent otomatik tamamlanmaz. Parent, gelen sonucun gerçekten ihtiyacı karşılayıp karşılamadığını ve üst kararı nasıl değiştirdiğini değerlendirir.

Örneğin bir kaynak karşılaştırması “mevcut yaklaşım yanlış” yerine “bu iki yaklaşım hedef bakımından eşdeğer, fakat farklı operasyon yükü var” sonucunu verebilir. Bu da yararlı sonuçtur. Araştırmanın görünür katkısı yalnız yeni teknoloji önermesi değildir. Bir varsayımı doğrulama, seçeneği eleme, kullanım sınırını daraltma veya gerekli sonraki kanıtı açma da gerçek katkıdır.

## 7.3 Açık keşif ve return_to

Kesinti kaydı sadece `next_action` taşımaz. Odak ihtiyaç, üzerinde çalışılan alternatif, kullanılan kaynak sürümleri, henüz çözülmeyen karar, beklenen alt sonuç ve onun döneceği üst bağ korunur. Agent tamamlanmadan kaybolduğunda yeni oturumun önceki iç düşünce zincirini kopyalaması gerekmez; fakat hangi sorunun neden açık olduğunu ve hangi sonucun hangi kararı değiştireceğini geri kurabilmesi gerekir.

Bir alt iş sonuç vermediğinde parent sonsuza kadar beklemez. Bekleme nedeni, yeniden deneme politikası, alternatif bilgi edinme yolu ve bütçe etkisi görünür olur. Sonuç gerçekten gereksiz hale geldiyse iptal edilir; iptal “başardı” olarak kaydedilmez. İşin final kabulü için gerekli olmayan açık soru, bağımsız ilerlemeyi tümüyle kilitlemez.

## 7.4 Öncelik, stopping ve plan değişimi

Öncelik yalnız son mesajın güncelliği veya kolay test yazılabilmesiyle belirlenmez. Ana hedefe etkisi, belirsizliği azaltma değeri, kritik bağımlılıkları açması, geri alınabilirliği ve kaynak maliyeti birlikte tartılır. Evrensel tek bir puan fonksiyonu dayatılmaz. Kullanılacak basit sıralama kuralı ve istisna gerekçesi açık tutulur.

Keşif durma koşulu “artık soru kalmadı” değildir. Kalan belirsizlik mevcut yetkili eylemi maddi biçimde değiştirmiyorsa veya dar deney belirsizliği güvenle taşıyabiliyorsa ilerlenebilir. Tersine bütçe veya context bitti diye hazır olunmuş sayılmaz. Rapor/araştırma aşamasının tamamlanması da kurulum aşamasına otomatik geçiş yetkisi değildir. Bu belge böyle bir geçiş yapmaz.

# 8. İş durumları ve geçişlerin mekanik anlamı

## 8.1 Tek durum alanının yetersizliği

Gerçek Work için yürütme ilerlemesi, mevcut geçerlilik, yetki, kabul ve dış etki ayrı eksenlerdir. Bir iş yürütülmüş olabilir ama girdisi bayatlamıştır; bir çıktı geçerli olabilir ama kabul edilmemiştir; bir yayın denemesi bitmiş olabilir ama etkisi bilinmiyordur. Hepsini `done` alanında birleştirmek yanlış tüketimi kolaylaştırır.

Tasarımda Work execution için planned/ready/running/waiting/finished/cancelled; qualification için current/stale/needs_review; acceptance için proposed/accepted/rejected; effect için prepared/observed/unknown gibi ayrı durum alanları düşünülür. Bunlar tek evrensel state machine değil, nesne türünün sözleşmesidir. V3 yerel modelinin daha küçük open/running/current/closed alanı bu tam sözleşmeyi uygulamaz; aşağıdaki testler yalnız modelde gerçekten bulunan geçişler içindir.

## 8.2 Readiness ve claim

Ready sorgusu anlık bir değerlendirmedir. Claim, aynı koşulların yetkili transaction içinde yeniden kontrol edilerek gerçek çalışma hakkının alınmasıdır. Birden fazla aday aynı ready görüntüsünü görebilir; bundan birden fazla geçerli atama çıkmamalıdır. V3 yerel SQLite yarışında sekiz bağlantıdan yalnız biri claim aldı; bu local serialization kanıtıdır, PostgreSQL veya cloud dispatch kanıtı değildir. [L2]

ALL ve ANY grupları üç değerli değerlendirilir: true, false, unknown. ALL'da bir false grubu false yapar; false yokken unknown varsa sonuç unknown'dır. ANY'de bir true yeterlidir; true yokken unknown varsa sonuç unknown'dır. Boş grup sessizce ready sayılmaz. Yerel kod bu mantığı 1–5 elemanlı sonlu girdi uzayında sıra-temelli ayrı bir oracle ile karşılaştırdı. Gerçek koşulların doğru seçilmesi hâlâ bilişsel bir yük olarak kalır.

## 8.3 Claim sonrasındaki değişim

V2 modelindeki F08, claim anında yeterli olan koşulların effect anında artık yeterli olmayabileceğini gösterir. Çalışma başladıktan sonra yeni bir hard dependency açıldığında eski worker hâlâ target revision'ı güncelleyebiliyordu. V3 effect kapısı güncel work, dependency, token, grant ve read-set koşullarını birlikte tekrar kontrol eder. Bu fix, bilinmeyen bir bağımlılığı keşfetmiş olmaz; kayıtlı bağımlılığın değişimini artık görmezden gelmez. [L1, L2]

Yeni kritik bağımlılık, üreticinin elde ettiği taslağı silmek zorunda değildir. Taslak candidate olarak korunabilir; final veya protected effect engellenir. Aynı zamanda bağımsız inquiry başka bir Work ve geçerli yetkiyle devam edebilir. Böylece “fail closed” bütün projeyi gereksiz yere durdurma anlamına gelmez. Hangi effect'in hangi koşula bağlı olduğu açık olmalıdır.

## 8.4 Reopen ve cancellation

Bir kararın dayanağı değiştiğinde etkilenen işler aday inceleme kümesine alınır. Bütün eski işler otomatik yanlış veya cancelled sayılmaz. Yeniden inceleme, önceki çıktının hangi kullanımda hâlâ geçerli olduğunu belirler. Cancelled assignment'ın geç sonucu candidate kanıt olarak saklanabilir; current ürüne sessizce karışmaz. İptal komutu gönderilmiş olması, dış etki yolunun gerçekten durduğu anlamına gelmez.

# 9. K1 iletişim: mesaj değil, tüketilmiş katkı

## 9.1 Talep sözleşmesi

Request; gönderen rol/principal, alıcı iş/rol, istenen katkı, üst karar, kapsam, gerekli kaynak derinliği, teslim biçimi, urgency, deadline varsa gerekçesi ve return_to taşır. Mesaj gövdesi tek canonical truth değildir; Work ve bilgi nesnelerine bağlanan taşıyıcıdır. Bir mesajın gönderilmiş olması alıcının başladığını veya sonucu ürettiğini göstermez.

Alıcı request'i kabul edebilir, gerekçeli daraltma önerebilir, eksik giriş bildirebilir veya yetkisiz talebi reddedebilir. Her durumda gönderen tarafın beklemesi güncellenir. Gönderen, yanıtı aldıktan sonra “kullanıldı”, “koşullu kullanıldı”, “kullanılmadı — şu nedenle” veya “ek soru açtı” biçiminde tüketim kaydı üretir. Kullanılmayan değerli sonuç bilgi alanında kalabilir; request başarılı diye otomatik karar desteği olmaz.

## 9.2 K2 ve işletim sorumluluğu

Normal rol geçişi Y koordinasyonu ve ilgili dispatcher/adapter tarafından yürütülür. İnsan, her rolün ardından bir sonraki mesajı elle taşımak zorunda kalmamalıdır. Fakat native team özellikleriyle gerçek durable iş yürütme eşitlenmez. Task listesi, mesaj teslimi, child liveness, authoritative Work state ve geri dönen sonucun kullanımı farklı gözlemlerdir.

Y koordinasyonu kayıp worker, geciken yanıt ve düşmüş bağlantıyı iş anlamıyla uzlaştırır. Örneğin bir araştırmacı yanıtı üretmiş ama native task'ı kapatmamışsa yalnız task durumuna bakarak araştırmayı tekrar çalıştırmaz. Yetkili sonuç nesnesi, request bağı ve son dispatch gözlemi incelenir. Sonuç yoksa replacement atanabilir; sonuç varsa tüketici incelemesine devam edilir. Bu hareketin actual Codex session/subagent akışında otomatik ve doğru gerçekleşmesi H-K1/K2 deneyiyle gösterilecektir.

## 9.3 Döngü, deduplication ve deadlock

A'nın B'den cevap beklemesi, B'nin de A'nın henüz üretmediği nihai kararı beklemesi mümkün olabilir. Sistem önce bunun gerçek dependency döngüsü mü, bilgi talebi mi yoksa hatalı request biçimi mi olduğunu ayırmalıdır. Final karar yerine bounded taslak/varsayım istemek döngüyü açabilir; bu değişim yetkisiz varsayımı gerçek yapmaz.

Aynı request'in yeniden teslimi yeni bir iş başlatmamalı; aynı kimlikle farklı katkı içeriği ise çatışma olarak görünmelidir. Yerel inbox örneği bu dar deduplication özelliğini sınar. End-to-end exactly-once mesajlaşma veya haricî effect garantisi vermez. Kesin tekrar güvenliği, tüketici effect'inin de idempotent veya güvenli biçimde gözlenebilir olmasına bağlıdır.

# 10. Bilgi düzeni, hafıza ve anlam sahipliği

## 10.1 Bilgi aileleri ve yaşam döngüsü

Çalışma durumu, kaynak/kanıt, değerlendirilmiş bilgi, ürün tasarımı ve kararlar, yöntem/yeterlik kayıtları ve oturum/devam bilgisi farklı kullanım yükleri taşır. Hepsi tek bir “memory” koleksiyonuna atılırsa aynı tür erişim, güven ve silme kuralına tabiymiş gibi görünebilir. Fiziksel depoların sayısı bu anlamsal ayrımı belirlemez; aynı depoda ayrı şemalarla da korunabilir.

Yakalama yeni bilgi yaratabilir ama onu doğrulanmış yapmaz. Yeni kaynak için kimlik, erişim tarihi, kaynak türü, kapsam, doğrudan içerik ve türetilmiş yorum ayrılır. Çıkarımın dayanağı ve sınırı tutulur. Review veya kabul, o kaydın hangi kullanımda geçerli olduğunu belirler. Güncelleme eski revision'ı sessizce değiştirmek yerine yeni revision ve gerekçe üretir. Arşivleme hâlâ geri çağrılabilir geçmiş olabilir; deletion ise ayrı retention/erişim kararıdır.

## 10.2 Kaynak, temsil ve yorum

Bir belgenin varlığı, onu modelin gördüğünü göstermez. Retrieval sonucu kaynağın bir görünümüdür; kaynakta olmayan şeyin bulunamadığına dair genel kanıt değildir. Sıkıştırılmış özet kaynağa doğru referans verse bile karar-kritik karşı kanıtı veya qualifier'ı düşürebilir. DR08/DR07 kaynak gövdesine dönüş yolunu korur; içerik sahibi gerekli yorum ayrımını belirler.

Örneğin araştırma “A koşulunda yararlı, B koşulunda başarısız” diyorsa, belleğe yalnız “yöntem yararlı” yazılması anlam kaybıdır. Kaynağın bulunması veya hash'inin doğru olması bu kaybı düzeltmez. Yeni kullanımda A/B ayrımının gerçekten görünür olması ve kararın bunu değerlendirmesi gerekir. Context ve yöntem aktarımı burada aynı kayıt üzerinden fakat farklı yüklerle kesişir.

## 10.3 D021'in somut uygulanışı

İçerik sahibi bir bulgunun anlamını değiştirince değişiklik önerisiyle etkilenen gerekçe ve kullanım bağlarını belirtir. DR07 konum, index, source/revision ilişkisi, stale view ve yeniden kullanım kayıtlarını uzlaştırır. DR07 bir atıfın bozuk olduğunu veya iki kaydın görünürde çeliştiğini bulduğunda içerik sahibine anlam incelemesi açar; kendi başına hangi iddianın doğru olduğuna karar vermez.

Yer değiştirme ile anlam değişimi ayrılır. Dosya taşındı diye içerik revision'ı zorunlu değişmez; fakat dış adresler ve türetilmiş index güncellenir. Bir kayıt “historical” olduğunda search sıralamasında current bilgiyi gölgelememelidir. Eski malzeme gelecekte aynı yanlış işi yeniden başlatmayacak kadar bulunabilir; current authority gibi okunmayacak kadar açık statülü olmalıdır.

## 10.4 Unutma, silme ve dayanıklılık

Silinebilirlik tasarımın sonuna bırakılmaz. Bir kaynak için saklama izni geri çekildiğinde ham gövde, embedding, search snippet, context cache, türetilmiş alıntı ve yedek kapsamı değerlendirilir. Yalnız “tombstone var” demek bütün kopyaların kullanılamaz olduğunu kanıtlamaz. Hangi izlerin denetim için kimlik/gerekçe seviyesinde tutulacağı ve hangi içeriklerin kaldırılacağı ilgili yetki/politikaya bağlıdır; bu rapor genel hukuki retention hükmü vermez.

Backup doğruluğu ile current access politikası ayrı otoritelerdir. Bir yedek eski ama artık yasak içerik taşıyabilir. Restore sonrası current policy yeniden uygulanmadan index veya context serving açılmamalıdır. Bu, F03'teki yetki dönemi dersinin bilgi yaşam döngüsüne tasarım düzeyinde aktarımıdır; gerçek silme/restore deneyi bu pakette yapılmadı.

# 11. Context mühendisliği: gerekenin tanımı üreticiden gelmez

## 11.1 Üç ayrı sözleşme

ContextRequest tüketicinin iş yükünü tanımlar; ContextPackage bu yük için derlenmiş görünümü taşır; DispatchReceipt gerçek çalıştırmaya neyin sunulduğunu gözler. Kullanım ve anlama ise bunların sonrasında değerlendirilir. V3'ün merkezi değişikliği, zorunlu yüklerin paketi hazırlayanın kendi boş `open_gaps` listesine bırakılmamasıdır. [L1: F02]

ContextRequest; work ve assignment, target/revision, use, geçerli policy, gerekli bilgi/kanıt yükleri, erişim sınırı, gereken kaynak derinliği ve yanıt tüketicisini taşır. Bu gereklilikler kontrol edilmiş bir tüketici kararından gelir. Candidate worker aynı request kimliği altında onları azaltamaz. Değiştirmek gerekiyorsa gerekçeli yeni request revision'ı ve uygun owner yolu kullanılır.

ContextPackage; request kimliği/hash'i, seçilmiş exact kaynak/passages, her yükün karşılığı, açık kalanlar, gerçek görünüm ve görünüm hash'ini taşır. Request'in kopyası değil, ona karşı değerlendirilen üründür. DispatchReceipt; adapter/runtime/config sürümü, giriş paketinin kimliği, ek native bağlamın görünür kapsamı ve gözlem sınırını taşır. Bu makbuz “model anladı” demek değildir.

## 11.2 F02 ve F05 neden önemli?

V2 yerel validator, `sources=[]`, `open_gaps=[]`, `view={}` ve bu boş view'un geçerli hash'i ile kabul verdi. Yapı biçimsel olarak tutarlıydı; gereken bilginin ne olduğu dışarıdan bağlanmadığı için kabul kapısı bu eksikliği göremedi. Aynı validator work scope'unu source scope'una bağlarken target scope'unu denetlemediğinden başka kapsamdaki aynı revision'lı target da kabul edildi. `guarded_update` içindeki scope kontrolü bu farklı validation yolunun açığını kapatmıyordu. [L1]

V3 sınırlı modelinde güvenilir request kaydı oluşturulur. Her zorunlu yük belirli Source/revision/span'a bağlanır; gerçek kaynak metni immutable fixture deposundan okunur. Package içindeki referans ve metin onunla eşleşir. View, bu blokların deterministik birleşimidir; gerekli blokları taşımayan farklı bir özetin hash'i doğru olsa bile kabul edilmez. Work/target/source kapsamı ve source/target revision'ı birlikte kontrol edilir. [L2]

Bu katı örnek üretim context'inin hep aynen birleştirilmiş pasajlardan oluşması gerektiğini söylemez. Kodda tek kaynaklı exact obligation modeli seçilmesi, F02'nin mantığını açık sınamak içindir. Production tasarımında ALL/ANY destek seçenekleri, farklı sunumlar, özetler ve semantic coverage olabilir; bunlar ayrı doğrulama sözleşmesi ve deney gerektirir. Dar kodu geniş bağlam sisteminin tamamı gibi sunmak F02'yi başka biçimde tekrar etmek olur.

## 11.3 Derleme akışı

Önce use belirlenir: keşif, tasarım, üretim, karşı inceleme, kabul veya recovery. Aynı kaynak farklı use için farklı seçim ve sıralama gerektirebilir. Sonra mandatory yükler ve izinler çözülür. Exact kimlik erişimi, lexical/semantic arama ve graph komşulukları birlikte aday kaynaklar bulabilir. Aday küme erişimden önce yetki filtresine; seçimden sonra görev yeterliği incelemesine tabi olur. Sonuç bir package revision'ıdır, sessiz değişen prompt değildir.

Kaynak bulunamazsa eksik kaydı oluşur. Tamlık gerektiren kabul işi durabilir; fakat bu eksiği giderecek inquiry yine başlayabilir. Budget daralırsa önce tekrarlanan veya karar değeri düşük içerik azaltılır. Zorunlu karşı kanıt veya yetki sınırı “token tasarrufu” gerekçesiyle çıkarılmaz. Yetmeyen bütçe çalışma biçimini değiştirebilir: staged reading, ayrı inquiry veya daha dar yetkili teslim önerilir.

## 11.4 Görünürlük, dispatch ve kullanım

Native runtime kendi system prompt'unu, konuşma geçmişini, araç sonuçlarını veya ek memory'sini birleştirebilir. Denetlenen package bütün gerçek girişle aynı olmak zorunda değildir. Bu nedenle “package hash'i doğru” ile “model yalnız bu girdiyi gördü” ayrılır. Tam native giriş gözlenemiyorsa izolasyon ve bağımsızlık iddiası buna göre daraltılır.

Tüketici, kararında kullandığı kaynak ve qualifier'ları gösterebilir. Bu yararlı bir kullanım izidir; bütün mental processing'in ölçümü değildir. Daha güçlü anlamsal kontrol için kaynağın ters koşulunu taşıyan görev, eksik qualifier fixture'ı veya farklı source-grounded soru gerekir. Eksikliği bilen evaluator'ın cümleyi prompt içinde işaretlemesi ipucusuz keşif kanıtını bozar. Bu tür deneyler H-G02 kapsamındadır.

## 11.5 Cache ve yenileme

Cache anahtarı yalnız soru metni değildir. Work/use, target ve source revision'ları, policy/grant görünümü, principal/scope, role/method release ve kullanılan index sürümü gibi yük taşıyan girdilere bağlanır. Bunların hangisinin sonucu değiştirdiği açık sözleşme olmalıdır. Salt TTL, exact değişimi her zaman yakalayamaz; salt dependency graph da kaydedilmemiş semantik etkiyi yakalayamaz.

Compaction sonrası devam, geçmiş konuşmayı en kısa özete indirgeme yarışması değildir. Current amaç, yetki, açık karar, beklenen katkı, actual effect ve source access yolu geri kurulur. Yeni context package türetilir. Eski package'ın accepted olması yeni assignment veya policy için accepted olduğu anlamına gelmez. V3 yerel model bu nedenle eski token/policy/revision ile context kullanımını reddeder.

# 12. İlişki mühendisliği ve doğru sorgu birimi

## 12.1 Nesne ile bağın anlamı

Work dependency, source provenance, finding support, review challenge, assignment ve supersession aynı ilişki türü değildir. Readiness'i değiştiren bağ ile açıklayıcı ilişki ayrılır. Hard dependency'de cycle reddi istenirken yaratıcı ilişki veya inceleme feedback'inde cycle doğal olabilir. Bütün graph'ı DAG yapmak ya da bütün cycle'ları serbest bırakmak iki uç hatadır.

Bir bağ yalnız uç kimliklerini değil tür, scope, gerekli revision/use bağları, status ve zaman anlamını taşımalıdır. “Bu kaynak bu kararı destekler” ifadesi, hangi source revision'ı, hangi karar kullanımı ve hangi koşul altında sorularıyla tamamlanır. Destek gruplarında ALL/ANY ayrımı korunur. Kaynaklardan biri bayatladığında bütün kararların otomatik yanlışlanması değil, destek yeterliğinin yeniden değerlendirilmesi gerekir.

## 12.2 Nesne-etki ile yol açıklaması ayrıldı

F04'ün temel nedeni, etkilenen nesneler sorusunun her farklı yolu döndüren sorguyla cevaplanmasıdır. V2 p138 örneği recursive adımda `UNION ALL` ve path dizisi taşır; son `DISTINCT id,path` yalnız aynı id ve aynı path çiftlerini ayırır. Farklı yollar aynı nesneye ulaştığında hâlâ farklı satırlardır. Cycle guard bir path içindeki tekrarları durdurur; farklı acyclic yolların çoğalmasını durdurmaz. PostgreSQL'in resmi recursive sorgu açıklaması da deduplication'ın sonuç satırı üzerinden işlediğini belirtir. [B2: p138, W3]

Yerel semantic analogue deneyinde 18 elmas, 55 nesne ve 72 edge vardı. Bütün yolları taşıyan sorgu 1.048.573 satır; yalnız nesne kimliğini taşıyan sorgu 55 satır üretti. Bu bir PostgreSQL performans ölçümü değildir. Süreler ham logda vardır fakat makineye, sorgu planına ve fixture'a bağlıdır. Buradaki güçlü sonuç, path satırlarının küçük nesne sayısına rağmen katlanabilmesidir. [L1]

Yeni query sözleşmesi iki hizmeti ayırır. `affected_entities` yetkili snapshot üzerinde benzersiz nesneleri ve her biri için en az bir açıklayıcı keşif tanığını üretir. `explain_paths` yalnız açıkça istenen kapsamda, path/witness sınırı ve completeness bilgisiyle çalışır. “Bütün yollar” gerekli bir analitik soruysa kendi resource admission'ı gerekir; günlük invalidation akışının varsayılanı olmaz.

## 12.3 Sınır koymak ile eksik sonucu gizlemek farklıdır

Bütçe, derinlik veya zaman sınırı dolduğunda sonuç `complete=false` taşır. Böyle bir sonuçta “başka etkilenen nesne yok” veya “engel yok” denmez. Kısmi pozitif sonuç belirli incelemeleri başlatabilir; negatif hüküm daha güçlü tamlık ister. Production continuation token; snapshot/revision/policy/query ve kalan frontier'a bağlanmalıdır. V3 yerel fonksiyon pagination uygulamaz; sınır dolduğunu açıklar. [L2]

Sadece dış sorguya `LIMIT` eklemek güvenilir bir execution budget değildir. Özellikle sıralama veya join, alttaki sorgunun büyük bölümünü çalıştırabilir; resmî PostgreSQL belgesi bu kullanımın production güvencesi sayılmamasını açıklar. Bu yüzden sorgu kabulü, sonuç biçimi ve yürütme sınırı birlikte tasarlanır. [W3]

## 12.4 Snapshot, permission ve negatif bilgi

Query root'unun varlığı ve erişim yetkisi kontrol edilir. İlişki filtresi görünür kapsamı belirler; gizli düğümlerin içerikleri veya isimleri response'a sızdırılmaz. Yetkisiz bölge yüzünden tamlık sınırlıysa bunun tüketicinin kararını nasıl etkilediği, bilgi sızdırmadan açıklanır. Güvenli bir “bilinmiyor” ile yanlış bir “yok” aynı değildir.

Canlı graph değişirken önceki query sonucuyla effect yapılamaz. Command kapısı güncel koşulları ve gerekirse graph epoch/snapshot bağını tekrar kontrol eder. Yerel model `BEGIN IMMEDIATE` ile edge değişimlerini serileştirerek karşıt iki hard edge yarışında tek kazanan sağladı. Bu uygulama aynı kilit davranışının PostgreSQL'de kendiliğinden oluşacağını göstermez; gerçek isolation/lock tasarımı H-GRAPH'ta sınanmalıdır. [L2]

## 12.5 Graph dışına bakma yükü

Graph kayıtlı ilişkileri bulur. Henüz fark edilmemiş veya kayda girmemiş anlamsal etkiyi garanti etmez. Büyük ürün revizyonunda graph incelemesinin yanında exact assembly/source reading gerekir. Böylece DR07'nin ilişki bakımı ile DR03/DR13'ün anlam değerlendirmesi birleşir; hiçbiri diğerinin yerine geçmez. Kayıtlı ilişki eksikliği bir bakım bulgusudur; otomatik “anlam ilişkisi yok” hükmü değildir.

# 13. Kontrol kapısı: tam niyet, current yetki ve değişmez kimlik

## 13.1 Tam işlem niyeti

F01'de idempotency anahtarı yalnız payload hash'ine bağlanmıştı. Aynı içerik başka target veya base için kullanıldığında eski makbuz dönüyordu. Bu, içerik tekrarını denetleyen bir kontrolün işlem niyetinin tamamını denetlediğinin sanılmasıdır. V3 `prepare` niyeti; işlem türü, target, expected base, payload, work, principal/scope, assignment kimliği/generation/epoch ve grant revision'ına bağlar. [L1, L2]

Aynı anahtar ve aynı tam niyet yeni effect oluşturmaz; mevcut makbuzu döndürür. Aynı anahtar ve farklı niyet açık conflict'tir. İstemcinin key'i yeni bir hedef için sessizce yeniden kullanması engellenir. Anahtar namespace'i ve saklama süresi de sözleşmenin parçasıdır: erken idempotency kaydı temizliği, gecikmiş retry'ı yeni işlem gibi gösterebilir. Bu retention davranışı gerçek servis tasarımında ayrıca belirlenmelidir.

Bir makbuzu okumak ile effect'i yeniden yetkilendirmek farklıdır. Eski makbuz “şu işlem hazırlanmıştı” der; bugünkü grant hâlâ geçerli demek değildir. Production API receipt read ve effect authorization'ını ayrı yollar olarak tasarlamalıdır. Yerel model revoked grant sonrasında prepare/retry isteğini reddederek bu ayrımın güvenli dar bir tarafını örnekler; tam endpoint authorization sistemi değildir.

## 13.2 Read-set ve değişim transaction'ı

Effect kapısı yalnız target revision'ını değil yük taşıyan read-set'i doğrular. Kaynak, criterion, policy, grant, assignment veya assembly değişimi sonucu maddi biçimde etkiliyorsa bağ buna dahil olur. Hangi bağımlılıkların yük taşıdığı bilişsel tasarımın parçasıdır; worker'ın keyfî olarak kısa read-set yazması tek başına yeterli kontrol olamaz. Production command türünün zorunlu dependency set'i server tarafında belirlenir.

Uzun LLM çalışması boyunca DB transaction açık tutulmaz. Üretim immutable input snapshot'a dayanır; sonunda kısa bir yetkili transaction kabul veya conflict üretir. Conflict, her zaman çalışmanın çöpe gitmesi değildir. Candidate korunur; değişmiş bağlara göre rebase, yeniden inceleme veya sınırlı reuse değerlendirilir. Kör retry sadece aynı eski varsayımla yanlışı tekrar edebilir.

## 13.3 Olay kaydı kontrolün parçası

F06'da v2 `relate` ve `reassign` state'i değiştirirken event üretmiyordu. Dolayısıyla olayla beslenen bir projection veya scheduler bu değişimi öğrenemeyebilirdi. V3 bu iki değişim için aynı transaction'da event üretir ve rollback'te hem state hem event'in geri alındığını sınar. Aynı ilişkinin aynı biçimde tekrarı yeni değişim sayılmaz. [L1, L2]

Event tablosunun büyüyen kimliği tek başına bütün sistemin commit watermark'ı değildir. Production projection; aggregate revision, batch/snapshot, teslim kimliği ve eksik sıra durumunu taşımalıdır. Replay, consumer'ın yeniden doğru görünüm üretmesine yardım eder; dış etkileri yeniden üretme izni değildir. Yerel modelin event `seq` alanı global distributed order kanıtı olarak kullanılmaz.

## 13.4 Kimlik ve bypass sınırı

V3 kodundaki principal, grant, source ve EpochAuthority güvenilir fixture girdileridir. Gerçek uygulamada bunları hangi caller'ın hangi yolla oluşturabildiği ayrıca zorlanmalıdır. `Token` dataclass'ının varlığı imza, secrets isolation veya host identity kanıtı değildir. Aynı DB'ye doğrudan yazma izni olan worker bütün kontrolleri aşabilir; bu nedenle production kontrol deposu ve yönetim credential'ı worker VM'sinin sıradan yazma alanı olamaz.

Kontrolün önünde görünen API'ye bakmak yetmez. Shell, Git, MCP, dosya yolu, symlink, child process, network proxy ve başka credential yolları aynı protected effect'e erişebiliyor olabilir. Her yol için effect inventory ve yetki bağları çıkarılır. Rol prompt'undaki “yapma” cümlesi, bu envanterin ve gerçek bypass testinin yerine geçmez.

# 14. Codex hedef ortamı ve topoloji seçimi

## 14.1 Güncel resmî kaynak bulgusu

OpenAI'nin Agents API'si Codex harness'ını yönetilen bir servis olarak sunuyor. Temel nesneler **Agent, Environment, Session ve event/item akışı**dır; session konuşma ve kaydedilmiş çalışma durumunu turlar arasında sürdürebilir. OpenAI harness, session orkestrasyonu ve context compaction gibi altyapıyı yönetirken uygulama kendi araçlarını ve execution environment'ını seçer. Bu, DevOS'un kalıcı Work authority'sini platform session'ına devretmek zorunda olduğumuz anlamına gelmez; tersine iki state alanının uzlaştırılmasını açık bir tasarım konusu yapar. [W1] [W2]

Agents API'nin multi-agent modu root agent'ın bağımsız context taşıyan subagent'lar açmasına, onlara iş ve ek bilgi göndermesine, beklemesine ve sonuçları sentezlemesine izin verir. OpenAI dokümanı bunu bağımsız/parallel iş akışları için önerir; aynı mutable dosyaları düzenleyen veya sıkı sıralı işlerde koordinasyon gerektiğini ayrıca belirtir. Bu nedenle SOUL/DevOS rol modeli doğrudan “bir rol = bir subagent” kuralına çevrilmez. Role, agent instance ve principal ayrımı korunur. [W5]

## 14.2 P5 için seçilen birincil Codex topolojisi

P4'ün current **birincil P5 adayı** şöyledir: DevOS uygulama/control plane'i canonical Mission/Work/Request/Contribution/UseReceipt ve policy state'ini taşır; Agents API yönetilen Codex harness'ını ve session/subagent orkestrasyonunu sağlar; root koordinasyon agent'ı ihtiyaç olduğunda uzman subagent'lar açar; execution için başlangıç tercihi OpenAI-hosted sandbox'tır. PostgreSQL, Git publication, dış veri ve yüksek etkili effect'ler ayrı açık arayüzlerden bağlanır.

Bu seçim Codex kararının teknik yorumu ve P5 için default blueprint'tir; “Agents API dışında Codex kullanılamaz” şeklinde kullanıcı kararı değildir. OpenAI-hosted sandbox ihtiyacı karşılamazsa aynı Codex harness self-hosted environment'a bağlanabilir. Private network, özel image, kalıcı provider storage veya farklı compute gereksinimi bu geçişi gerekçelendirebilir. Environment seçimi changed workload'a göre yeniden açılabilir; Codex hedefi ise kullanıcı tarafından current platform kararıdır. [W2] [W6]

Codex session geçmişi, subagent listesi veya turn status'u DevOS Work state'inin tek doğruluk alanı değildir. Bir subagent kapanmış olabilir ama Contribution kaydı hiç oluşmamış olabilir; turn `completed` olsa bile tool call'larından biri başarısız olabilir. Tersine bir ortam kopsa da canonical Work ve alınmış dış effect devam ediyor olabilir. Y koordinasyonu bu alanları uzlaştırır; platform olayını iş anlamına doğrudan eşitlemez. [W8] [W9]

## 14.3 Kimlik, secret ve protected effect sınırı

OpenAI sandbox güvenlik dokümanı, agent-generated kodun environment içinde erişilebilir dosya, credential ve network'ü kullanabildiğini açıkça varsayar. Self-hosted executor için environment key yalnız environment bağlantısı için dar tutulabilir; application API key environment dışında kalmalıdır. OpenAI-hosted sandbox'ta üçüncü taraf credential'lar vault/proxy yolu ile gerçek secret sandbox'a verilmeden kullanılabilir. Bu mekanizmalar DevOS açısından değerlidir, fakat “subagent A ile subagent B ayrı security principal'dır” sonucunu üretmez. [W7]

Bu nedenle korunan effect yolu application/control plane tarafında kalır. Worker/subagent, doğrudan production credential almak yerine dar function tool, remote MCP veya trusted broker arayüzü kullanır. Araç çağrısı; work, principal/actor binding, scope, assignment, generation/epoch, operation intent ve current policy ile doğrulanır. Yüksek etkili grant/policy/promote veya irreversible effect aynı runtime'daki başka bir rol etiketiyle otomatik açılamaz. Ayrı policy component, protected credential boundary veya gerekli owner kabulü kullanılır.

OpenAI-hosted sandbox `env` değerleri agent kodu tarafından okunabilir; uzun ömürlü veya yüksek yetkili secret'lar sıradan environment variable olarak verilmez. Network policy de yetkinin tek katmanı değildir: allowlist yalnız hangi hosta erişilebileceğini sınırlar; o hosttaki hangi operation'ın yetkili olduğunu DevOS policy'si ayrıca belirler. [W6] [W7]

## 14.4 Session, environment ve recovery ayrımı

Agents API session'ı environment'tan daha uzun yaşayabilir. Self-hosted environment kopabilir ve yeniden bağlanabilir; fakat replacement compute aynı environment ID ile açıldı diye eski dosyaların geri geldiği garanti edilmez. OpenAI dokümanı pending input için de crash sonrasında otomatik durable queue/replay garantisi vermiyor. Geç veya başarısız connection, failed tool, completed turn ve session idle durumları ayrı gözlemlerdir. [W8] [W9]

Bu davranış v3'teki recovery ayrımlarını zayıflatmak yerine somutlaştırır. Canonical Work, request, assignment, contribution ve effect observation platform session'ından bağımsız dayanıklı yüzeyde tutulur. Bir session devam edebiliyorsa kullanılır; fakat yeni compute/session açılması gerektiğinde eski worker'ın kimliği canlandırılmaz. Current assignment ve authority yeniden bağlanır; dış effect için readback yapılır; timed-out input körlemesine tekrar gönderilmez.

## 14.5 Hedef preflight'ın gerçek teslimatı

Codex preflight yalnız “Codex çalışıyor” veya “agent cevap verdi” değildir. Fresh session'ın doğru agent config/instructions, skills/plugins, environment template, gerekli dosyalar ve network policy ile açıldığı; environment'ın gerçekten `connected` olduğu; protected tools'ın doğru uygulama tarafına bağlı olduğu; yanlış scope/principal'ın effect yapamadığı; root/subagent delegation'ın K1 request/use zincirini bozmadığı; session veya environment kaybında K2'nin Batu'yu rutin mesaj taşıyıcı yapmadan doğru Work'e döndüğü; log ve sonuçların canonical eve işlendiği gösterilir. [W1] [W5] [W6] [W8]

Bu testlerin hiçbiri bu P4 revizyonunda actual Agents API hesabında çalıştırılmış değildir. Mevcut local Python/SQLite/Git kanıtı yeniden koşturulmuştur; bu, Codex-native qualification yerine geçmez. **Environment kararı artık Codex'tir; exact P5 kurulumu ise H-ENV, H-K1/K2 ve H-AUTH kanıtını üretecek şekilde hazırlanacaktır.**

# 15. Yayın, dış etki ve DB–Git uzlaştırması

## 15.1 Tek atomik dünya varsayımı yok

Git ref değişimi ile DB state değişimi tek transaction değildir. Korunan yayın akışı önce tam niyeti ve candidate içeriği hazırlar; sonra current grant/read-set/assignment koşullarını kontrol eder; expected old ref ile sınırlı dış güncelleme dener; authoritative readback ile ne olduğunu gözler; DB sonuç ve outbox kaydını idempotent biçimde tamamlar. Aradaki her kesinti ayrı durumdur.

Git'in `update-ref` aracı expected old object değeriyle kontrol edilen ref değişimini destekler. Bu oturumda gerçek yerel bare Git üzerinde CAS ve içerik geri okuması yapıldı; altı eşzamanlı adaydan yalnız biri aynı expected old ref'i değiştirebildi. Bu, uzak GitHub izinleri, protected publisher isolation veya DB–Git atomikliği kanıtı değildir. [W4, L2]

## 15.2 Operation, gözlem ve kullanım durumu

F07, “applied → unknown → not_applied” üzerine yazımıyla daha önce görülen etki kanıtını silebiliyordu. Oysa şu anda ref'in base olması, candidate'ın hiç uygulanmadığını göstermez. Yerel Git deneyi candidate ref'e geçip sonra base'e dönmenin mümkün olduğunu gösterdi. Bu nedenle “güncel ref gözlemi”, “candidate geçmişte authoritative olarak görüldü” ve “şu anda teslim edilebilir ürün” ayrı tutulur. [L1, L2]

V3 modelinde observation kimliği, sırası ve payload hash'i korunur. Daha geç gelen eski gözlem current sıralamayı geri almaz; candidate'a ilişkin geç pozitif kanıt varsa tarihçeye eklenir. Sonraki unavailable, olmuş etkiyi silmez. Ancak `ever_applied=true`, ürün hâlâ current veya kullanıcı kabulü tamamlandı demek değildir. Bu alan yalnız bu modelin trusted observation fixture'ına dayalı tarihsel bilgidir.

## 15.3 Kesinti pencereleri

**Prepare öncesi kesinti:** Yetkili operation kaydı yoktur; candidate taslak olabilir. **Prepare sonrası, dış etki öncesi:** Operation vardır ama gerçekleşme bilinmez; broker kendi evidence yoluyla kontrol eder. **Dış etki sonrası, DB kaydı öncesi:** En tehlikeli retry penceresidir; önce readback gerekir. **DB finalize sonrası consumer öncesi:** Outbox/inbox tekrarları duplicate effect yaratmamalıdır. **Consumer sonrası kullanıcı teslimi öncesi:** Teslim bildirimi ve ürün kullanımı ayrıca gözlenir.

Yerel testte üçüncü pencere simüle edildi: Git ref gerçekten candidate'a geçirildi, DB'ye observation henüz yazılmadı, sonra ref okunarak local state uzlaştırıldı. Yeni Git update denenmeden observation ve idempotent consumer ilerledi. Bu dar gerçek Git + SQLite örneğidir; ağ timeout'u, provider eventual consistency veya korunan runtime identity deneyi değildir. [L2]

## 15.4 Revocation yarışı ve çözülemeyen atomiklik

Grant kontrolü ile haricî effect arasında yetki geri çekilebilir. Dış provider aynı authority epoch veya capability'yi atomik denetlemiyorsa yalnız DB recheck bütün yarış penceresini kapatmaz. Tasarım bu açığı görünür tutar: publisher kısa ömürlü intent/lease, effect sınırı ve per-target serialization kullanabilir; yüksek etkide provider tarafı koşullu yetki veya owner kapısı gerekebilir. Garantinin tam sınırı hedef adapter sözleşmesinde belirtilir.

Bir compensation her zaman gerçek rollback değildir. Yayınlanmış içeriğin görülmüş olması geri alınamayabilir. Bu yüzden telafi işlemi yeni yetkili operation olarak kaydedilir; tarihçe silinmez. Belirsiz effect'te güvenli gözlem yolu yoksa sistem başarılı veya etkisiz diye tahmin yapmaz. Durur, scoped recovery açar ve kullanıcı müdahalesini yalnız gerçekten gerekli noktada ister.

# 16. Restore ve kesintiden toparlanma

## 16.1 F03: yerel sayaç neden yeterli değil?

V2'daki assignment generation, normal reassign sırasında eski worker'ı reddediyordu. Ancak generation=1 ve actor=alice içeren yedek geri getirildiğinde, sonradan yapılan bob/generation=2 değişimi kayboldu. Alice'in eski token'ı yeniden eşleşti. Buradaki problem normal concurrency değil, otoritenin geçmişe geri dönmesidir. [L1]

V3 tasarımı restore/failover kabulünü, iş verisiyle birlikte geriye alınmayan bir authority epoch'a bağlar. Yedek açıldığında protected effect serving kapalı kalır. Yetkili recovery yeni epoch oluşturur; eski runtime/capability yolları fence edilir; pending dış etkiler uzlaştırılır; current grant/policy uygulanır; yeni assignment/context ile iş yeniden açılır. UUID eklemek tek başına yeterli değildir; eski UUID'yi taşıyan yedek yine geri gelebilir.

## 16.2 Yerel düzeltmenin ispat sınırı

Yerel modelde EpochAuthority yedeklenmeyen ayrı bir Python nesnesidir. Restore testinde bu fixture yeni epoch'a döner; geri yüklenen DB'deki eski token reddedilir; yeni assignment gerçek local effect yapabilir. Bu, istenen semantiğin dar gösterimidir. Dayanıklı haricî authority service, consensus, tek aktif writer, partition, eski network credential iptali veya felaket sonrası veri kaybı toleransı kanıtı değildir. [L2]

Gerçek kurulumda epoch otoritesinin kendisinin restore edilmesi, iki active controller'ın oluşması veya eski broker'ın erişilebilir kalması ayrıca sınanır. “Epoch dışarıda” demek tek başına çözüm değildir; onun kalıcılığı, erişim sınırı ve split-brain davranışı tasarlanmalıdır. Bu nedenledir ki H-RESTORE, birkaç process restart'ıyla kapatılamaz.

## 16.3 Kurtarma envanteri

Recovery manifest; DB checkpoint kimliği ve schema sürümü, ürün/release Git commit/ref'leri, kaynak/kanıt gövde manifest'i, current policy/grant authority bağlantısı, pending operation'lar, projection lag ve açık assignment/request'leri taşır. Bu manifest tek atomik backup snapshot'ı garanti etmiyorsa tutarlılık sınırı belirtilir. Hangi kayıtların daha eski olduğu ve hangi readback'in onları uzlaştıracağı açıktır.

Her aktif iş için üç sonuç mümkündür: aynı amaçla yeni assignment üzerinden devam; eldeki candidate'ı yeni kaynak/authority ile inceleme; artık geçerli olmayan işi gerekçeli iptal. Eski oturum kayboldu diye bütün çalışma tekrarlanmaz; yedek bulundu diye bütün çalışma da current sayılmaz. Actual effect ve tüketilen katkı, plan kayıtlarından ayrı okunur.

## 16.4 Basamaklı tekrar açılma

Önce yalnız yönetim ve gözlem yolları açılır. Sonra source/policy erişimi ve read-only görünümler doğrulanır. Ardından düşük etkili inquiry/candidate üretimi açılabilir. Protected publication, unresolved operation ve authority çatışmaları yeterince uzlaştırıldığında açılır. Bu sıralama ana hedefi unutmak değildir; yüksek etkili belirsizliği düşük etkili ilerlemeden ayırır.

Recovery'nin başarısı “process yeniden başladı” değildir. Doğru current purpose, kalan work, geçerli principal, kaynak ve actual effect durumu geri kurulduğunda ve yeni worker yanlış eski yetkiyle iş yapamadığında anlam kazanır. Gerçek hedef testinde iyi devam örneği de gerekir; tüm işlemleri sonsuza kadar reddeden sistem güvenli ama yeterli değildir.

# 17. Uzun ve bileşik ürünler

## 17.1 Parça kalitesi bütün kalitesi değildir

SOUL'un uzun veya bileşik ürün yükü, DevOS'ta yalnız task hiyerarşisiyle karşılanamaz. Ürün parçalarının hangi revision'larla, hangi sırada ve hangi tasarım niyetine göre bir bütün oluşturduğu explicit Assembly Snapshot'ta tutulur. Design Baseline niyeti; Working Assembly gerçekleşmiş birleşimi; Delivery Baseline kabul/teslim edilmiş ürünü gösterir. Birindeki değişim diğerinin gerçekleşmiş olduğunu varsaydırmaz. [R3]

Örneğin romanın yeni yaratıcı yönü kabul edilmiş olabilir, ama eldeki bölümler hâlâ eski karakter motivasyonunu taşıyor olabilir. Yeni design revision'ını current yapmak, mevcut manuscript'i yeni tasarımın uygulaması yapmaz. Revision Work'leri, koruma yükleri ve bütünsel review açık kalır. Bu örnek SOUL backlog'u seçmek için değil, bileşik ürün sözleşmesini sınamak için kullanılır.

## 17.2 Okuma kipleri ve kaynak-temelli değerlendirme

Plan-aware reviewer tasarım niyetini bilerek uygulama uyumunu inceler. Text-grounded reviewer yalnız gerçekleşmiş metne bakarak okurun görebileceği bağı ve eksikleri sınar. İkisinin sorusu ve context'i farklıdır; verdict'leri tek puana indirgenmez. Plan bilgisinin erken görünmesi, metnin aslında kurmadığı bir bağı reviewer'ın zihninde tamamlamasına yol açabilir. Bu riski yalnız “ayrı reviewer” etiketi çözmez; sunulan görünümün sınırı gerekir.

Reading Pass; exact assembly, okunan aralıklar, inceleme sorusu, açık threads ve durma noktasını tutar. Bütün kaynağın bir kerede context'e sığması şart değildir; fakat parça okumalarının bütün hükmünü hangi coverage ile desteklediği görünür olmalıdır. Önceki okuma yeni assembly revision'ına sessizce taşınmaz. Anlamsal değişimin yalnız etiketli graph komşularında kaldığı varsayılmaz.

## 17.3 İtiraz, tercih ve karar

Bir reviewer'ın kaygısı doğrudan patch emri değildir. Önce olgusal/teknik kusur mu, kaynak yetersizliği mi, yaratıcı tercih mi, scope çatışması mı olduğu ayrılır. Kaynak kusuru ek kanıt veya onarım ister; tercih farkı yetkili karar ister; scope çatışması üst amacı yeniden açabilir. Her eleştiriyi uygulamak veya bütün reviewer'ları ikna etmek başarı koşulu değildir.

Karar gerekçesi, değerlendirilen alternatifleri ve hangi yeni bilgiyle açılacağını kaydeder. Aynı tercih tartışması yeni maddi bilgi olmadan tekrar tekrar dönüyorsa önce mevcut karar geri çağrılır. Buna karşılık yeni kaynak veya değişen hedef eski kararın yazarlığını koruma gerekçesiyle dışlanmaz. Karar sürekliliği atalete dönüşmemelidir.

## 17.4 Gerçek bütünsel kabul

Yerel bölüm testleri, link kontrolleri veya şema uygunluğu büyük eserin etkisini doğrulamaz. G07 için gerçekten tamamlanmış eser, exact assembly'ye bağlı bütünsel review ve iddia gerektiriyorsa bağımsız okur/alan uzmanı değerlendirmesi gerekir. Buradaki kurgusal akış böyle bir deney değildir. DevOS bu kanıtı üretebilecek iş/rol/context/review düzenini taşımalıdır; sonucu önceden garanti etmiş gibi davranamaz.

# 18. Yöntem seçimi, kalıcı öğrenme ve sistemin kendini değiştirmesi

## 18.1 Ders kaydı ile etkin yöntem

Bir hata sonrası “bir daha yapma” yazmak kalıcı öğrenmenin yalnız en erken adımıdır. Yöntem adayı, hangi problem ve koşul için yararlı olduğunu; hangi kaynak/deneyle desteklendiğini; karşı örnekleri; yan etkileri; runtime ve role gereksinimlerini; geri alma yolunu taşır. Library'de kayıtlı olması, bir sonraki işte etkin olacağı anlamına gelmez.

Seçim, işin gerçek koşullarına göre yapılır. Uygun olmayan yöntemi kullanmamak da doğru bir sonuçtur. Bir source talimatı, yöntem dosyası olarak görülmesi nedeniyle otomatik etkin kontrol olmaz. Etkin role/method/policy release'i uygun yetki ve yayın yoluyla belirlenir. Böylece öğrenme, dış kaynağın gizli kontrol talimatına dönüşmesiyle karıştırılmaz.

## 18.2 Birleşim etkisi

Tek başına yararlı iki yöntem birlikte zararlı olabilir. Örneğin biri context'i sıkıştırıyor, diğeri her iddiayı kısa bir güvence cümlesine dönüştürüyor olsun. Ayrı ayrı okunabilirliği artırırken birleşimlerinde koşul ve karşı kanıt kaybolabilir. Her yöntemin tekil testi geçmesi birleşimin geçtiği anlamına gelmez. Etkin konfigurasyon, method release set'i ve uygulanma sırası evaluation nesnesi olur. [R3: G06]

Regression kontrolü yeni faydanın yanında eski yararlı davranışı korumayı arar. Yöntem değişince benchmark aynı kaldığı halde yalnız önceki hatalara duyarlı hale gelmiş olabilir. Challenge yüzeyi, değişiklikten etkilenebilecek yeni failure sınıflarıyla tazelenir. Daha az bulgu, daha az hata anlamına gelmeyebilir; verifier körleşmesi olasılığı ayrı değerlendirilir.

## 18.3 Öz-değişim yetkisi

DevOS'un kendi kontrolünü veya değerlendirme ölçütünü değiştirmesi, sıradan ürün dosyası değiştirmekten farklıdır. Maker, geçemediği kriteri kendi yetkisiyle kolaylaştırıp aynı sonucu yeni kriterle doğrulanmış sayamaz. Değişim meşru olabilir; bu durumda eski sonuç exploratory kalır ve yeni kriter fresh evidence üzerinde sınanır.

Kontrol/yetki/policy değişimi için hangi owner veya ayrı güven sınırının gerekli olduğu önceden tanımlanır. Rutin yöntem önerileri bu ağır yetkiyi almış sayılmaz. Bu raporun yerel model geliştirmesi de target agent-control değişikliği değildir; canonical araştırma protokolleri değiştirilmedi.

# 19. Kapasite, işletim maliyeti ve yararlı ilerleme

## 19.1 Daha çok kapasite yerine doğru darboğaz

DevOS kapasitesi token, agent sayısı veya DB throughput tek sayısına indirgenmez. Inquiry latency, gerçek üretim kalitesi, review maliyeti, kaynak erişimi, kontrol kuyruğu, publication serialization ve recovery yükü birbirini etkiler. Aynı iş kalitesi korunmadan ucuzluk karşılaştırması yapılamaz. Aynı şekilde yüksek maliyet otomatik daha yüksek kalite değildir.

İş sınıfları ayrı admission ve bütçe profili taşıyabilir: kısa exact lookup; derin araştırma; büyük assembly incelemesi; uzun üretim; yüksek etkili publication; recovery. Resource rezervasyonu yalnız hesaplama için değil, ortak kaynak veya dar güvence kapasitesi için de gerekebilir. Öncelik politikası recovery'yi her zaman baskın yaparak normal işte starvation üretmemelidir.

## 19.2 Ölçülecekler

Mekanik ölçümler; claim conflict, stale rebase oranı, request dönüş gecikmesi, projection lag, query eksikliği, publication unknown süresi ve recovery sonrası eski token reddidir. Bilişsel/iş değeri ölçümleri; maddi eksik keşfi, gereksiz prerequisite oranı, tüketilen araştırma katkısı, bütünsel ürün kusuru, kullanıcıya taşınan teknik keşif yükü ve yöntem transfer regresyonudur. Bunlar aynı puanda toplanmak zorunda değildir.

V2'deki Z1/Z2/Z3 ölçek ve latency değerleri ölçülmüş production limitleri değildi. Yeni rapor bunları kabul edilmiş eşik gibi taşımaz. Hedef workload ölçülünce aday eşikler sonuçtan önce sabitlenir. Bir sorgunun 55 nesnede path patlaması göstermesi milyon düğümlük gerçek benchmark'a ihtiyaç olmadığını; küçük karşı örneğin tasarım kusurunu açabileceğini gösterir. Buna karşılık küçük query düzeltmesi büyük ölçek yeterliğini kanıtlamaz.

## 19.3 Degradation ve backlog

Bir semantic index kullanılamıyorsa exact kaynak erişimi bazı inquiry'leri sürdürebilir. Bunun hangi bilgi sorularını eksik bıraktığı açıklanır. Broker veya authority erişilemiyorsa protected effect durur; candidate çalışma ve read-only araştırma uygun koşullarda devam edebilir. Degradation normal mod gibi raporlanmaz; hangi garantilerin korunduğu ve hangilerinin askıda olduğu açık olur.

Backlog, kendisiyle meşgul bir düzenin büyüyen çöp kutusuna dönüşmemelidir. Yeni keşiflerin mevcut amaçla ilişkisi, stale işler, artık gereksiz önkoşullar ve sonuçsuz tekrarlar periyodik inceleme nesnesidir. Fakat bu bakım, kullanıcıca yetkilendirilmiş işlerin kolaylık için sessizce silinmesi değildir. İptal veya öncelik düşürme gerekçesi ve etkilenen tüketiciler korunur.

# 20. Stres bulguları: gözlem, neden ve düzeltmenin sınırı

## F01 — İşlem kimliğinin eksik bağlanması

**Gözlem:** Aynı `op`, aynı payload ile önce `a@1`, sonra `b@1`, sonra `a@999` için `prepared` döndürdü; saklanan kayıt hâlâ `a@1` idi. **Yakın neden:** karşılaştırılan digest yalnız payload'dı. **Kontrol açığı:** idempotency kapsamı işlem niyetinin tamamı olarak tanımlanmamıştı. **V3:** tam intent hash'i, aynı anahtarda conflict, effect'ten ayrı makbuz anlamı. **Yeniden sınama:** farklı target/base/payload/assignment reddi; exact retry tek preparation event; revoked grant reddi. **Açık:** ağ API identity, global key namespace/retention ve gerçek publisher. [L1–L3]

## F02 — Zorunlu bilgisi olmayan context kabulü

**Gözlem:** Boş sources, gaps ve view kabul edildi. **Yakın neden:** package'ın beyan ettiği boş eksik listesine güvenildi. **Kontrol açığı:** zorunlu yükün otoritesi package üreticisinden ayrılmamıştı; view hash'i coverage oracle'ı gibi kullanılabiliyordu. **V3:** trusted ContextRequest, exact kaynak/pasaj bağları ve gerçek view eşleşmesi. **Yeniden sınama:** boş package, eksik obligation, sahte metin, doğru hash'li eksik görünüm, stale target/source/policy reddi; doğru package kabul. **Açık:** anlamsal yeterlik, gerçek native dispatch, üretimde özet/ALL-ANY/çoklu kaynak desteği. [L1–L3]

## F03 — Restore ile eski assignment'ın geri gelmesi

**Gözlem:** Yedek öncesindeki token, normal reassign sonrası reddedildi; eski yedekte tekrar kabul edildi. **Yakın neden:** tuple/generation geçmişe döndü. **Kontrol açığı:** geçerli authority dönemi backup'tan bağımsız değildi. **V3:** dış, geriye alınmayan epoch'a bağlı serving/reassignment tasarımı ve ayrı fixture üzerinden yerel test. **Yeniden sınama:** eski token reddi, yeni token'la gerçek local effect. **Açık:** dayanıklı epoch service, partition, eski broker/credential iptali ve gerçek PostgreSQL restore. [L1–L3]

## F04 — Nesne sorgusunun bütün path'leri üretmesi

**Gözlem:** 55 nesneli fixture'da 1.048.573 path satırı. **Yakın neden:** path'lerin sonuç kimliğine dahil edilmesi. **Kontrol açığı:** affected entity ve explain path sözleşmesinin örnek SQL'de ayrılmaması. V2 metni production sınırlarının gerektiğini belirtmişti; dolayısıyla “hiç düşünülmemiş” değil, güvenli varsayılan örneğin eksikliği söz konusudur. **V3:** visited entity, tek discovery witness, ayrı bounded path sorgusu, completeness. **Yeniden sınama:** 30 elmaslı local graph 91 nesne/120 edge olarak işlendi; bütün üç düğümlü yönlü graph'larda matrix oracle uyumu. **Açık:** gerçek PG sorgu planı, ACL ve snapshot pagination. [L1–L3, W3]

## F05 — Context hedef scope bağının atlanması

**Gözlem:** Work `s`, target `other` scope'undayken validator kabul etti. **Yakın neden:** kaynak scope'ları incelenirken target scope'u incelenmedi. **Kontrol açığı:** kontrol kapsamı bütün tüketim yoluna değil bazı alanlara bağlanmıştı. **V3:** request oluşturulurken ve kullanılmadan önce target/source/work bağları. **Yeniden sınama:** başka scope target'ına request reddi; doğru scope olumlu kontrol. **Açık:** gerçek principal ACL, izin değişiminin cache/view'a etkisi ve side channel. [L1, L2]

## F06 — Değişim var, olay yok

**Gözlem:** Bir dependency ve yeni assignment oluştu; event sayısı aynı kaldı. **Yakın neden:** ilgili mutator'larda emit yoktu. **Kontrol açığı:** state–event eşliği yalnız bazı commands için test edilmişti. **V3:** bu değişimler ve rollback için atomik event izi. **Yeniden sınama:** başarıda event, inject edilen hatada ne state ne event; duplicate relation yeni event değil. **Açık:** distributed projection gap detection, outbox servisinin işletimi ve bütün production command envanteri. [L1–L3]

## F07 — Güncel gözlem tarihsel etkiyi siliyor

**Gözlem:** Candidate, unavailable ve base gözlemleri state'i sırasıyla applied, unknown, not_applied yaptı. **Yakın neden:** tek alan üzerine yazıldı. **Kontrol açığı:** current observation, olmuş etki ve teslim geçerliliği birleştirilmişti. **V3:** immutable gözlem kimliği/sırası, tarihsel pozitif etki, güncel görünüm ve ürün kabulünün ayrılması. **Yeniden sınama:** unknown/base geçmiş pozitif kanıtı silmez; geç gözlem current sırayı geri almaz; gerçek Git ref base'e dönebilir. **Açık:** authentic external observer, gözlem bütünlüğü ve provider history erişimi. [L1–L3]

## F08 — Claim sonrası değişmiş önkoşul

**Gözlem:** Running work'e açık hard dependency eklendikten sonra target güncellemesi kabul edildi. **Yakın neden:** readiness yalnız claim sırasında kontrol edildi. **Kontrol açığı:** effect geçerliliği, güncel work koşulları yerine eski admission'a dayandı. **V3:** effect'te güncel dependency ve work koşulları. **Yeniden sınama:** ilgili effect reddi; bağımsız inquiry'nin ilerleyebilmesi. **Açık:** kayıtlı olmayan semantik bağımlılıklar ve gerçek PG transaction/lock davranışı. [L1–L3]

# 21. Bütün mimariyi zorlayan masa başı senaryoları

Bu bölüm yürütülmüş agent deneyleri değildir. Her senaryo, mekanizma birleşiminin hangi yanlış başarı veya gereksiz blokajı üretmemesi gerektiğini gösterir. Yerel testle karşılığı bulunan parçalar ayrıca işaretlenir; senaryonun bütünü “geçti” sayılmaz. Bu, teknik bulguların bilişsel hedefi gölgelemesini önleyen ikinci inceleme katmanıdır.

## 21.1 İpucusuz eksik gereklilik ve yanlış root frame

**Başlangıç:** Kullanıcı sonuç istiyor; belirli yöntem önermiyor. Koordinatör kolay uygulanabilen bir yöntemi seçip uzmanlara yalnız onun alt işlerini dağıtıyor. **Zorlayıcı değişken:** Hedefe giden başka bir yöntem, mevcut planın hiç görmediği bir kullanıcı kabul koşulunu ortaya çıkarıyor. **Yanlış başarı:** Tüm alt işler tamamlandı ve kendi testleri geçti, fakat ilk hedef yanlış yorumlandı.

**Tasarlanan hareket:** DR01 ihtiyaç ile yöntem gereğini ayırır; DR13-G ham talep ve alternatif frame'e erişerek decomposition'ı da inceleyebilir. Yeni koşul gerçekten maddiyse root inquiry açılır, etkilenen plan kararları stale olur. Bağımsız alt katkılar candidate olarak kalır; bütün emek otomatik atılmaz. Yeni kapsam/ürün tercihi gerekiyorsa Batu'ya gerekçeli karar döner. **Açık kanıt:** Ekibin bu alternatifi ipucusuz keşfedeceği; H-G01. [R3, R4]

## 21.2 Gereksiz önkoşul ve sonsuz hazırlık

**Başlangıç:** Basit, düşük riskli bir soru bounded kaynak incelemesiyle yanıtlanabilir. Sistem her bilgi işi için yeni agent, graph şeması, method release ve uzun plan istiyor. **Yanlış güvenlik:** Hiç hata yapılmıyor çünkü gerçek işe başlanmıyor.

**Tasarlanan hareket:** Önkoşulun hedefe veya yalnız seçilmiş yönteme ait olduğu sorgulanır. Mevcut yetki ve araçlar bilgi edinmeye yetiyorsa küçük inquiry açılır. Sonucu etkileyemeyen altyapı ertelenir. Değerlendirme, yalnız eksik yakalamayı değil gereksiz iş ve kullanıcı yükünü de ölçer. **Açık kanıt:** Bu ayrımın gerçek kullanımda doğru yapılması; H-G01/G05. Local “unrelated inquiry” testi yalnız mekanik blokaj sınırını gösterir.

## 21.3 A→B→A iletişiminde yanıt kaybı

**Başlangıç:** G araştırma ister, araştırmacı sonucu üretir, runtime kapanır. Task state açık kalır; gerçek sonuç storage'dadır. **Yanlış devam:** Yeni Y aynı araştırmayı tekrar çalıştırır veya sonucu gelmedi sanıp planı iptal eder.

**Tasarlanan hareket:** Request ve result kimlikleri uzlaştırılır; native status authoritative kabul edilmez. Eksik olan üretim değil tüketimse yeni work bunun üzerine kurulur. Kullanım makbuzu hangi kararı etkilediğini gösterir. **Açık kanıt:** Actual native restart, otomatik replacement ve kullanım; H-K1/K2. Inbox testi yalnız duplicate yerel tüketimi sınar.

## 21.4 Doğru kaynak, yanlış özet

**Başlangıç:** Kaynak “yalnız A koşulunda” diyor. Memory özeti bu qualifier'ı düşürüyor. B koşulundaki yeni work özeti çağırıyor. **Yanlış başarı:** Kaynak linki var, context hash'i doğru, reviewer özeti onaylıyor.

**Tasarlanan hareket:** Tüketici use için applicability yükü request'te mandatory olur. Exact kaynak veya uygun span gösterilir; package üreticisinin kendi coverage beyanı yetmez. Karar, B için yöntemi kullanmama veya yeni test isteme gerekçesini taşır. **Açık kanıt:** Semantic omission'ın gerçek görevde yakalanması; H-G02/G06. F02 düzeltmesi bu koşulu temsil etmeyi sağlar, yorum doğruluğunu garanti etmez.

## 21.5 Küçük ama çok yollu graph

**Başlangıç:** Aynı kanıt birkaç ara finding üzerinden ortak kararlara gidiyor. **Yanlış uygulama:** Invalidation tüm path'leri materialize ediyor ve diğer işler kaynak bulamıyor.

**Tasarlanan hareket:** Benzersiz nesne frontier'ı çıkarılır; açıklama için bir veya sınırlı sayıda witness üretilir. Geniş path analizi ayrı iş olur. Tamlık bittiğinde negatif yokluk hükmü verilmez. **Kanıt:** Bu mekanik olasılık L1'de üretildi; L2'de küçük directed graph oracle'ıyla düzeltme sınandı. **Açık:** Gerçek yoğunluk, ACL, DB latency ve throughput; H-GRAPH/G05.

## 21.6 İki role verilen paylaşılan credential

**Başlangıç:** Maker ve reviewer aynı VM'de, farklı agent adıyla çalışıyor. **Yanlış güvenlik:** Reviewer etiketi protected release için bağımsız principal sayılıyor.

**Tasarlanan hareket:** Host gerçek identity isolation göstermiyorsa tek RuntimePrincipal kabul edilir. Rutin eleştiri devam eder; yüksek etkili promotion ayrı trusted boundary'ye gider. Source ve method bağımsızlığı ayrıca değerlendirilir. **Açık kanıt:** Credential, shell/MCP/Git bypass ve authenticated actor binding; H-AUTH. Yerel Token sahteciliği testi gerçek credential ayrımını göstermez.

## 21.7 Yayın oldu, yanıt kayboldu

**Başlangıç:** Publisher candidate ref'i değiştirdi; DB sonucunu yazamadan kesildi. **Yanlış toparlanma:** Timeout etkisizlik sayıldı, başka candidate aynı key'le gönderildi.

**Tasarlanan hareket:** Tam intent kaydı korunur; observed ref candidate ise effect tarihçesi uzlaştırılır; başka niyet aynı key'i kullanamaz. Current ref farklıysa konflikt/recovery açılır. **Kanıt:** L2 yerel bare Git + SQLite kesinti penceresini çalıştırdı. **Açık:** Gerçek remote provider, network ve revocation yarışı; H-PUBLISH.

## 21.8 Backup eski grant ve assignment'ı canlandırıyor

**Başlangıç:** Worker iptal edilmiş ve hassas bir kaynağın erişimi kaldırılmış; sonra eski backup geri getiriliyor. **Yanlış toparlanma:** Servis açılıyor, eski worker eski yetkiyle effect yapıyor ve eski index içerik sunuyor.

**Tasarlanan hareket:** Recovery admission kapalı; current haricî authority/policy ve yeni epoch gerekli. Pending external effects ve erişim/silme durumu uzlaşmadan protected serving açılmaz. **Kanıt:** Assignment epoch semantiği L2'de sınırlı fixture ile sınandı. **Açık:** Policy/silme/credential/partition ve gerçek backup restoration; H-RESTORE.

## 21.9 Yeni tasarım, eski bütün

**Başlangıç:** Yeni yaratıcı veya mimari yön kabul edilmiş; parçalar henüz uygulanmamış. **Yanlış başarı:** Design revision'ı ilerlediği için ürün de yeni kabul ediliyor.

**Tasarlanan hareket:** Design, Working Assembly ve Delivery ayrı tutulur. Etki analizi ve actual source reading ile gerekli revision Work'leri açılır. Eski parçaların korunabilecek özellikleri de belirtilir; bütün metin/kod sebepsiz yeniden üretilmez. **Açık kanıt:** Gerçek uzun ürün revizyonu ve whole-product değerlendirme; H-G02/G07. [R3]

## 21.10 İki iyi yöntemin kötü birleşimi

**Başlangıç:** Bir yöntem kısa bağlam, diğeri hızlı doğrulama sağlıyor. Birleşimde kritik qualifier kayboluyor. **Yanlış başarı:** İki method ayrı ayrı accepted, dolayısıyla configuration accepted sayılıyor.

**Tasarlanan hareket:** Etkin method bileşimi, use ve release set'iyle ayrı nesne olur. Karşı örnek birleşik bağlam üzerinde koşturulur; regression eski yararlı davranışları da sınar. Gerekirse tek yöntemi kaldırmak, daha büyük yeni servis eklemekten iyidir. **Açık kanıt:** Yeni görevde seçme/kullanmama ve birleşik fayda; H-G06.

## 21.11 Kontrol hizmeti kendi kör noktası

**Başlangıç:** Broker kayıtları düzgün, tüm commands schema-valid. Server tarafının zorunlu dependency tanımı eksik. **Yanlış başarı:** Read-set güncel olduğu için yanlış karar da güvenli/doğru sanılıyor.

**Tasarlanan hareket:** Command inventory ve zorunlu yük tanımı review nesnesi olur. Mechanical safety ile semantic adequacy ayrı değerlendirilir. DR04 üreticinin kendi output'unu oracle yapmaz; ihtiyaç tanımının dışından karşı örnek aranır. **Açık kanıt:** Geniş gerçek coverage ve bağımsız review; H-G04. Bu senaryo kodun doğru çalışmasının tasarımın yeterliği olmadığını özellikle korur.

## 21.12 Tamamlanmış rapor, kabul edilmemiş sistem

**Başlangıç:** PDF ve source ZIP oluştu; çok test geçti. **Yanlış geçiş:** Sistem kurulmuş veya P5 başlamış gibi current state güncelleniyor.

**Tasarlanan hareket:** Artifact teslimi, mimari kabulü, kurulum ve hedef yeterliği ayrı kaydedilir. Repository current yönü sonraki oturuma doğru taşır. Dosya hash'i içerik yeterliği değil kimlik kanıtıdır. **Bu raporun karşılığı:** P4 teslimi; P5/P6 yok. Böylece araştırma çıktılarını implementation authority'ye dönüştüren eski drift yolu açıkça kapatılır.

# 22. Gerçek test sonuçları ve hata-duyarlılığı

## 22.1 Koşulanlar

| Deney grubu | Gerçek gözlem | İddia sınırı |
|---|---|---|
| V2 baseline | 40 adlandırılmış test yeniden geçti | Eski yerel modelin dar davranışları |
| V2 baseline mutations | Dört kontrol kaldırılması ilgili testleri başarısız yaptı | V2'nin dört dar hata sınıfına duyarlılığı |
| Yeni v2 probes | Sekiz scoped karşı örnek kaydı | Yerel kod ve SQL-semantic analogue; production arızası değil |
| V3 candidate | 53 adlandırılmış test geçti | Bounded Python/SQLite/yerel Git sözleşmeleri |
| Sonlu logic oracle | ALL/ANY için toplam 726 girdi/mode karşılaştırması | Doğru koşulların keşfi değil, verilen değerlerin birleşimi |
| Reachability oracle | 64 directed graph × 3 root = 192 karşılaştırma | Üç düğümlü sonlu uzay; gerçek graph/ACL ölçeği değil |
| Concurrency | Sekiz claim'de tek kazanan; karşıt hard edge'de tek kazanan | Yerel SQLite bağlantıları |
| Gerçek Git | CAS, içerik readback, altı aday yarışı, ref geri dönüşü, crash uzlaştırması | Yerel bare repo; uzak kimlik ve yayın güvenliği değil |
| Candidate mutations | Sekiz bozma: yedi assertion; bir downstream error | Yedi doğrudan falsification; error aynı sınıfta sayılmaz |

53 test sayısı sonlu alt girdileri ve mutation koşularını ayrıca şişirerek saymaz. Test logu her adlandırılmış deneyi içerir. Süreler ham kayıtta korunur; benchmark veya SLA sonucu olarak kullanılmaz. Aynı testleri tekrar koşmak bağımsız yeni görev örneklemi üretmez.

## 22.2 Mutation sonucu neden 8/8 başarı yazılmadı?

`context-coverage` guard'ı kaldırılınca eksik obligation sonraki kodda `KeyError` üretti. Test kırmızı oldu; fakat beklenen “hatalı package sessiz kabul edildi” yanlışı oluşmadı. Bu, kodun başka bir noktada düşmesidir ve temiz bir invariant falsification ile aynı güçte değildir. Sonucu güzel göstermek için kriter değiştirilmedi. Ham hata logu saklandı. [L3]

Diğer yedi bozma; intent eşliğini, gerçek view kapsamasını, restore epoch'unu, effect'te dependency recheck'i, assignment event'ini, pozitif effect tarihçesini ve query completeness bayrağını hedefledi. İlgili testler kasıtlı yanlış durumda assertion üretti. Bu bulgu, bu kontrollerin test edilen yanlışlara duyarlı olduğunu gösterir; alternatif bypass'ların tamamını dışlamaz.

## 22.3 Geliştirme izi ve self-review sınırı

İlk probe logunda F02 ve F05 aynı Python sözlüğünü paylaşmıştı; F05 değişimi F02'nin saklanan target alanını da değiştirdi. Gözlem anında derin kopya alınarak düzeltildi ve bütün probe tekrar koşuldu. İlk log `qa/history/` altında, düzeltme gerekçesi `qa/development-notes.md` içinde korunur. Bu bir çıktı kaydı düzeltmesidir; test ölçütü gevşetilmesi değildir.

Kod, test, rapor ve oracle düzeni aynı assistant tarafından üretildi. “Ayrı reviewer agent” çalıştırıldığı veya bağımsız insan incelemesi yapıldığı iddia edilmez. Matris oracle'ı farklı çözüm biçimiyle local cross-check sağlar; ortak kapsam hatasını dışlamaz. Hedefte davranış ve bilişsel kalite hakkında confidence bu local çalışmadan taşınmaz.

# 23. Hedef kabul programı: henüz yapılmayanlar

## 23.1 Mekanik ve ortam kapıları

| Kapı | Deney nesnesi | Başarıyı gerçekten gösterecek koşul |
|---|---|---|
| H-ENV | Actual Codex Agents API session + seçilen environment | Fresh session doğru agent/config/skills/environment ile açılır; network, tool, credential ve persistence sınırları gözlenir |
| H-K1/K2 | Gerçek request/worker/restart akışı | Batu rutin mesaj taşımaz; yanıt gerçekten doğru kararda kullanılır; kesinti doğru uzlaşır |
| H-AUTH | Broker/publisher ve credential yolları | Yanlış principal/scope/assignment ve bypass effect yapamaz; doğru dar iş yapabilir |
| H-PG | Hedef PostgreSQL schema/transaction | Constraint, concurrent command, retry, projection ve migration davranışı gerçek motorla doğrulanır |
| H-GRAPH | Gerçek veri, ACL ve query planı | Tamlık/izolasyon korunur; bounded sorgu negative hükmü yanlış üretmez; workload ölçülür |
| H-PUBLISH | DB–Git gerçek remote akış | Her crash/timeout penceresinde gözlem, conflict ve tek yetkili sonuç yolu gösterilir |
| H-RESTORE | Gerçek backup/restore/failover | Eski epoch/credential/write yolu kapanır; yeni yetkili iş ve current erişim doğru açılır |

Bu kapıların sırası sabit bir seri değildir; bağımsız, düşük riskli qualification işleri paralel açılabilir. Ancak bir kapının gerektirdiği yetki veya kaynak yoksa test yapılmış gibi davranılmaz. Hedef ortam bilgisi geldiğinde P4 varsayımı değişebilir; bu durum “uygulama sırasında küçük düzeltme” diyerek saklanmaz.

## 23.2 Bilişsel ve bütünsel kapılar

**H-G01 / keşif ve frame:** Önceden işaretlenmemiş ama maddi koşullar içeren görevler ile fazladan önkoşul gerektirmeyen görevler birlikte kullanılır. Eksik bulma, yanlış ihtiyaç üretme, doğru return_to ve uygun stopping ölçülür. Kullanıcının az soru alması tek başına başarı değildir; teknik keşif yükünü başka görünmez biçimde taşıması da ölçülmelidir.

**H-G02 / context ve semantik etki:** Gerçek uzun kaynakta qualifier kaybı, contradictory evidence, değişen source revision ve graph dışında kalan etki yerleştirilir. Tam içerik/assembly sabitlenir; package, actual dispatch ve tüketici gerekçesi ayrı izlenir. Bilgi erişimi, kullanımı ve doğru yorumu farklı ölçülerdir.

**H-G04 / yeterlik ve oracle:** Bilinen yanlış ve sağlam örnekler, farklı kaynak/çözüm yolları ve görev sınıfına uygun uzmanlık karşılaştırılır. Maker'ın sonucu evaluator'a sızdırılmaz; gereken yerde bağımsız insan/alan kanıtı kullanılır. İncelemeyi geçen artifact'in hangi claim'i desteklediği exact bağlanır.

**H-G05 / yararlı ilerleme:** Aynı kalite hedefi altında token, gecikme, maliyet, rework, starvation ve kullanıcı yükü değerlendirilir. Basit işi gereksiz orkestrasyonla ağırlaştırma ve karmaşık işi kolaylık için daraltma iki ayrı karşı durumdur. Tek throughput puanı yeterli değildir.

**H-G06 / yöntem transferi:** İlgili, ilgisiz ve çelişen yöntemler yeni görevlerde sunulur. Kullanma ve kullanmama, composition, normal cold-start üzerinden kalıcılık ve önceki yararlı davranışın korunması sınanır. Aynı eğitim/keşif örneğini tekrar koşmak transfer kanıtı değildir.

**H-G07 / bütün ürün:** Tam uzun eser veya bileşik geliştirme çıktısı üretilir; Design/Assembly/Delivery farkı takip edilir. Yerel review ile bütünsel kullanıcı etkisi ayrı değerlendirilir. Gereken estetik veya alan iddiası için uygun bağımsız okuyucu/uzman kanıtı aranır. Buradaki roman senaryosu bu deneyi çalıştırmış değildir. [R3]

## 23.3 Sonuçtan önce karar kuralı

Her hedef deneyi için claim, fixture, positive/negative controls, sample/repetition gerekçesi, ölçüm ve geçiş kuralı sonuç görülmeden belirlenir. Eşik yalnız “başarılı çıksın” diye sonradan seçilmez. Yeni hata veya yanlış oracle keşfedilirse protokol değişebilir; eski koşu post-hoc/keşifsel olarak kalır ve yeni veri gerekir.

Bütün açık araştırma sorularının deneysel kapanması P4 raporunun teslim koşulu değildir. Ama P5 kurulum ve P6 kabul kararı bu residual'ları görmeden verilemez. Özellikle native K1/K2, gerçek security boundary ve bilişsel yeterlik sadece yerel kayıt koduyla kapanmaz. Sonraki çalışma, bu bağımlılıkları gerçek hedefe bağlamak için ayrıca yetkilendirilir.

# 24. Tasarım kararları ve yeniden açma koşulları

## 24.1 Korunan tercihler

Work'ten rol türetimi; G/Y ve içerik–düzen ayrımı; ürün sürümü ile canlı iş durumu için ayrı authority; source/view/yorum ayrımı; scoped kabul; K1/K2; actual effect gözlemi; bağımsız bilgi edinmenin gereksiz bloklanmaması ve uzun ürünün exact assembly kimliği korunur. Bunlar v2'den gelen her mekanizmanın doğru olduğu iddiası değil, SOUL yükleri karşısında hâlâ gerekçeli görülen yönlerdir.

## 24.2 Güçlendirilen tercihler

İşlem niyetinin tam bağlanması, trusted context yükümlülükleri, değişmez kaynak pasajı–gerçek view eşliği, backup dışı authority dönemi, entity/path sorgu ayrımı, mutation–event coverage, current dependency recheck ve observation tarihçesi somutlaştırıldı. Yerel karşı örnekler bu değişimlerin ihtiyaç gerekçesini verir. Uygulamanın tamamının production düzeyine geldiğini göstermez.

## 24.3 Koşullu tutulanlar

Codex hedef platformu kullanıcı kararıdır; fakat Agents API içindeki root/subagent dağılımı, `openai_hosted` vs `self_hosted` environment, PostgreSQL, dış broker/publisher, hybrid retrieval ve ayrı object body storage nihai benimsenmiş seçimler değildir. İş ihtiyacını daha az operasyon yüküyle aynı güven ve kalite sınırında karşılayan alternatif gösterilirse değişebilirler. Sadece pahalı veya karmaşık oldukları için güçlü sayılmazlar; yalnız kolay alternatif bulundu diye gerekli kapasite de düşürülmez.

## 24.4 Yeniden açma olayları

Actual Codex topolojisinin K1/K2'yi karşılamaması; gerçek identity sınırının önerilenden zayıf çıkması; DB/Git yetki yarışının kabul edilemez kalması; large-source context'in yeterli bilgiyi taşıyamaması; root keşfinin sistematik hata üretmesi; whole-product incelemesinin parça başarısından ayrışmaması; method composition'ın kalıcı regresyonu; kontrol/maintenance maliyetinin yararlı işi bastırması tasarımı yeniden açar. Bu olaylar yalnız parametre tuning olarak görülmez; gerektiğinde mimari seçim değişir.

# 25. Sözleşme ve referans kodun uyum sınırı

## 25.1 Tek isim farklı olgunluk demek değildir

Paket üç düzeyi ayırır. `contracts/design-contracts.json` production tasarım semantiğini ve açık yükleri taşır. `contracts/context-envelope.schema.json` sınırlı modelin biçimsel envelope'unu tanımlar. `reference_model/kernel.py` seçilmiş yerel invariant'ları gerçekleştirir. Baseline v2 sözleşmeleri ayrıca tarihsel dizinde korunur; yeni modele uygulanmış production migration sayılmaz.

| Alan | V3 yerel kodda bulunan | Yalnız tasarım/hedefte kalan |
|---|---|---|
| Work | Open/running ve hard dependency effect recheck | Tam çok eksenli yaşam döngüsü, semantic dependency discovery |
| Assignment | UUID, generation, epoch, scope/principal fixture | Gerçek host kimliği, lease/heartbeat, dayanıklı epoch authority |
| Context | Trusted request, exact passage/view, rev/policy/scope | Native dispatch, çoklu destek seçenekleri, semantic coverage ve ACL |
| Graph | Hard edges, visited entity ve completeness | Typed tüm ilişki ailesi, temporal query, snapshot pagination, PG planı |
| Publication | Tam prepare intent ve observation geçmişi | Korunan network publisher, provider revocation atomikliği |
| Event | Local mutation/emit transaction ve inbox dedup | Dağıtık outbox hizmeti, ordering/gap-aware projection |
| Git | Gerçek local commit/ref/CAS/readback | Remote protected branch, gerçek credential ve operasyonel işletim |

Bu tablo bilinçli daraltmadır; görünmeyen özellik uygulanmış sayılmaz. Yerel code coverage'ın dışında kalan tasarım yükleri, aynı dosya adına veya aynı kavrama sahip olduğu için test edilmiş olmaz.

## 25.2 Şema uygunluğu ve davranış

JSON Schema zorunlu alan, tür ve hash biçimi gibi yapısal koşulları sınayabilir. Kaynak metni gerçekten doğru mu, verilen principal gerçek mi, policy authority current mı, özet qualifier'ı koruyor mu gibi sorular ayrı doğrulama ister. Şema kullanan API server'ın kontrol sırası, transaction sınırı ve hata davranışı sözleşmede belirtilir. Bu raporda endpoint'ler kurulmadı.

PostgreSQL için `contracts/postgres-requirements.md` migration ve constraint yüklerini listeler. Çalıştırılmamış DDL'yi uygulanmış düzeltme gibi vermek yerine v2 DDL tarihi korunur ve P5/H-PG yükü açıkça taşınır. Bu tercih PostgreSQL tasarımını atlamak değil, yerel SQLite davranışını denenmemiş bir SQL dosyası üzerinden üretim kanıtına yükseltmemektir.

# 26. Teslim paketi, tekrar üretim ve süreklilik

## 26.1 Dosyaların rolü

`source/DevOS_v3.md` tek düzenlenebilir yeni rapordur. PDF aynı metinden normal akışla üretilir. `source/stress-plan.md`, bulgu ve test envanteri ile kaynak kataloğu incelemenin izini taşır. `reference_model/` yeni sınırlı modeli ve tests'i; `tools/` probe, mutation, renderer ve QA araçlarını; `qa/` gerçek ham sonuçları ve sınırlarını taşır. `baseline/` v2 metnini, modelini ve sözleşmelerini tarihsel karşılaştırma için korur.

Aynı adla iki current rapor oluşturulmaz. Baseline içindeki “current”, “next” veya “200 sayfa” ifadeleri tarihsel belgenin parçasıdır. Yeni yön bu metin ve repository current kaydıdır. Kaynak ZIP, yeni oturuma taşınabilir tam çalışma paketidir; hash erişim yolu değildir. Repository yalnız provenance ve current handoff taşıyorsa tam raporun ayrıca eklenmesi gerektiği açık yazılır.

## 26.2 Yeniden çalıştırma

Paket README'sindeki komutlar, önce preserved v2 testlerini; sonra karşı örnekleri; sonra candidate testlerini ve mutations'ı ayrı çıktılara yazar. Normal testler Python standard library ve local Git kullanır. PDF üretimi ayrıca ReportLab ve yerel uygun Unicode font ister. Font dosyaları pakete dahil değildir. Yeniden koşu eski logların bağımsız kanıtı değil, aynı mekanizmanın yeni ortam gözlemidir.

Her üretimde source, test, model ve log hash'leri kaydedilir. PDF'nin metin kapsamı, sayfa taşmaları, Türkçe karakterler, bağlantılar ve görsel düzeni kontrol edilir. Bu QA, mimari iddiaların doğruluğunu kanıtlamaz; kullanıcıya verilen dosyanın kendi içeriğini eksiksiz ve okunabilir taşımasına yöneliktir.

## 26.3 Current durum

Bu v4 rapor, v3 yerel kanıt tabanını koruyan ve hedef Environment kararını Codex'e bağlayan P4 değerlendirme ürünüdür. V2'nin dosya kimliği korunmuş tabanından devam edilmiştir; önceki erişilemeyen v3 başarıları geri kazanılmış gibi sunulmamıştır. Kurulum yapılmamıştır. SOUL'un gerçek ilk işi seçilmemiştir. Mimari öneri, kullanıcı kararı ve hedef kabulü ayrı kalmaktadır.

Bu raporun tesliminden sonraki ayrı aşama P5 kurulum rehberidir. Rehber, Codex Agents API tabanlı default blueprint'i actual hesap, environment, protected tool ve persistence kararlarına dönüştürmelidir. Bu P4 teslimi P5 kurulumunu henüz yapmış sayılmaz; P5 sırasında H-ENV/K1-K2/H-AUTH sonucu default blueprint'i bozarsa ilgili teknik seçim yeniden açılır.

# 27. Kaynaklar ve gerçek okuma kapsamı

## Baseline ve yerel kanıt

**[B1]** `EXP-006_Yeni_Oturum_Devir_Paketi.zip`: 628182 byte; SHA-256 `ad0124a4be685558745fcd6e2291d2bfcc1fd600618268dd1e1e8a65276cc007`. Devir kaynağı, yeni rapor değil.

**[B2]** V2 `source/DevOS_v2.md`: 433434 byte; SHA-256 `45259ee104d31bffbbb1b83fc59b24aa308d1032cf1d8160373525174f68b8f3`. 200 sayfa/bölüm işaretli tam Markdown gövdesi bu oturumda okundu. Yeni metin sabit sayfalı renderer'ı kullanmaz.

**[B3]** V2 `contracts/` ve `reference_model/model.py`: kaynak ZIP içindeki tam sözleşme/model bağlamı. Model SHA-256 `45aab53c6c9a45c78d8e3d4c7fd0c213d7137d6adb474589dd8993a78b6ceb7f`. Sınırlı model, production implementation değil.

**[B4]** V2 test/mutation/QA ve 52 kayıtlı kaynak kataloğu. Testler ve mutations bu tur yeniden çalıştırıldı. Katalogdaki bütün original kaynaklar yeniden tam okunmadı; tarihsel provenance olarak ayrı korunur.

**[L0]** `qa/baseline-identity.json`, `qa/environment.json`: identity, araç ve ortam gözlemleri.

**[L1]** `tools/probe_v2.py`, `qa/v2-counterexamples.json`: sekiz scoped karşı örnek ve graph satır ölçümleri. İlk log düzeltmesi `qa/development-notes.md` içindedir.

**[L2]** `reference_model/test_kernel.py`, `qa/candidate-tests.txt`: 53 yerel test; standart Python/SQLite ve gerçek local Git. Native Codex Agents API, PostgreSQL ve haricî identity yok.

**[L3]** `tools/mutate_candidate.py`, `qa/candidate-mutations.json`: sekiz hedefli bozma; yedi assertion, bir error. Bağımsız review değil.

**[L4]** `qa/baseline-tests.txt`, `qa/baseline-mutations.json`: v2'nin 40 test ve dört kontrol kaldırma yeniden koşusu. V3 kabulü değil.

## Canonical proje kaynakları

**[R1]** `batuhanozgun/agentic-os-search`, EXP-006 `INDEX`, `STATE`, `HANDOFF`, `WORK`, `DECISIONS` ve `work/P4-03-unbounded-stress-test-handoff.md`: bu oturum başlangıcında tam okundu. Amaç, D001–D025, kaynak kimliği ve yarım kalan işin yetkisi buradan alındı. Agent-control dosyaları araştırma kanıtı değildir.

**[R2]** Aynı paket `work/P4-02-soul-derived-report-v2.md`: v2'nin tarihsel teslimi, mimari öneri ve kanıt sınırı; tam okundu. Eski next-work current yön olarak alınmadı.

**[R3]** EXP-004 `artifacts/MS01-COVERAGE-AND-OPEN-MECHANISMS.md`; blob `64870a8b7032e0efed165ded8dfa0d3947e997ae`: tam okundu. G01–G07, uzun ürün ve yöntem birleşimi açıklıkları geri çağrıldı. Bu kaynak kavramsal self-review; gerçek roman/host deneyi değil.

**[R4]** `research/studies/recursive-prerequisite-discovery/META.md`; blob `68fd539f3b24c70ad987241d183c4f301488b9ac`: tam okundu. `ASSESSMENT.md` §§1–5 seçici okundu. İhtiyaç/koşul/yöntem/karar/eylem, agent-relative frontier ve return_to ayrımları kullanıldı. Özgün 8 Eylül eklerinin tamamı bu oturumda yeniden erişilmiş değildir; yöntem etkinliği doğrulanmış sayılmaz. Studies CATALOG yalnız ilgili aday keşfi için seçici kullanıldı.

## Taze resmî teknik kaynaklar

**[W1]** OpenAI Developers, “Agents API — Overview”, erişim 28 Eylül 2026. Managed Codex harness; Agent/Environment/Session/event kavramları, managed session/orchestration ve sandbox kullanımı seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/overview . Actual kullanıcı hesabında DevOS kurulumu yapılmadı.

**[W2]** OpenAI Developers, “Agents API — Architecture”, erişim 28 Eylül 2026. Harness, application server ve `none`/`openai_hosted`/`self_hosted` environment ayrımı; streaming/webhook sorumlulukları seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/architecture .

**[W3]** PostgreSQL 18 documentation, “WITH Queries”, erişim 28 Eylül 2026; recursive evaluation, cycle/path ve LIMIT/materialization açıklamaları. URL: https://www.postgresql.org/docs/current/queries-with.html . Yerel path deneyi SQLite semantic analogue'dur; bu sayfa PostgreSQL benchmark sonucu sağlamaz.

**[W4]** Git documentation, `git-update-ref`, erişim 28 Eylül 2026; expected old object ve ref güncellemesi. URL: https://git-scm.com/docs/git-update-ref . Yerel testin Git sürümü ayrıca environment kaydındadır; current belgeyle bütün sürüm özellikleri özdeş sayılmaz.

**[W5]** OpenAI Developers, “Agents API — Multi-agent”, erişim 28 Eylül 2026. Root agent'ın bağımsız context taşıyan subagent'lar açması, mesaj/iş gönderimi, bekleme ve shared mutable work üzerindeki koordinasyon sınırı seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/multi-agent .

**[W6]** OpenAI Developers, “OpenAI-hosted sandboxes”, erişim 28 Eylül 2026. Packages, setup commands, files, env, skills/plugins, environment templates ve network policy yüzeyi seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/environments/openai-hosted .

**[W7]** OpenAI Developers, “Sandbox security”, erişim 28 Eylül 2026. Workload isolation, executor key, application key separation, vault/proxy ile third-party credential brokering ve agent-visible environment sınırı seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/environments/security .

**[W8]** OpenAI Developers, “Sandbox lifecycle”, erişim 28 Eylül 2026. Session/environment yaşam döngüsü, reconnect, shutdown, pending input ve replacement compute/file recovery sınırları seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/environments/lifecycle .

**[W9]** OpenAI Developers, “Session webhooks”, erişim 28 Eylül 2026. Session state, `action_required`, reconnect ve turn outcome ayrımları seçici incelendi. URL: https://developers.openai.com/api/docs/guides/agents-api/sessions/webhooks .

# 28. V2 kapsamının yeni metindeki karşılığı

Bu iz, eski sayfa düzenini sürdürmez; eski ana soruların yeni raporda kaybolmamasını denetler. Ayrı `source/v2-coverage.csv` her sayfa/bölüm işaretini bir yeni bölüme bağlar. Eşleme semantik kapsam yardımıdır; her eski cümlenin doğrulandığı veya aynen aktarıldığı iddiası değildir.

| V2 sayfa/bölüm alanı | V3 evi | İşlem |
|---|---|---|
| 1–8 giriş/kanıt sınırı | 1–3, 22, 26–27 | Yeni gerçek kanıt ve teslim sınırıyla yeniden yazıldı |
| 9–20 SOUL gereklilikleri | 2, 4, 7, 17–18, 23 | Hedef–kapasite–sınama bağı korundu |
| 21–32 kalite/ölçek | 3, 19, 22–23 | Ölçek hedefi ile gerçek ölçüm ayrıldı |
| 33–46 mimari | 5, 13–16, 24 | Temel ayrım korundu, authority ve recovery güçlendirildi |
| 47–70 roller | 6, 9 | G/Y ve rol/agent/principal farkı korundu |
| 71–88 Work | 7–9, 13 | Keşif/return_to ve claim sonrası koşul eklendi |
| 89–108 memory | 10, 18 | Yaşam döngüsü, anlam sahibi, silme ve restore bağlantısı açıklaştırıldı |
| 109–128 context | 11, 20, 25 | Trusted request, scope ve gerçek view bağları güçlendirildi |
| 129–150 graph | 12, 20, 22 | Nesne/path ayrımı ve gerçek karşı örnek yerleştirildi |
| 151–164 harness/security | 13–14, 23 | Current kaynak ve actual host qualification ayrıldı |
| 165–176 yayın/recovery | 15–16, 20 | Tam intent, observation geçmişi ve dış epoch tasarımı |
| 177–190 evaluation | 3, 21–23 | Mekanik/bilişsel kanıt ayrımı, olumlu kontroller ve residual'lar |
| 191–192 yürüyüşler | 21 | On iki birleşik karşı durum; gerçek koşu diye sayılmadı |
| 193 testler | 22 | Tarihsel ve yeniden koşulmuş/yeni sonuç ayrıldı |
| 194 değişim | 20, 24–25 | Bulgu–neden–fix–test–açık bağları |
| 195–200 kaynaklar | 27 ve kaynak katalogları | Tarihsel kaynak ile bu turun gerçek okuması ayrıldı |


# 29. Ayrıntılı rol sözleşmeleri

Bu sözleşmeler 6. bölümdeki sorumluluk haritasını uygulanabilir görev arayüzüne açar. Hepsi her anda aktif olmak zorunda değildir. Bir işte rollerin aynı taşıyıcıda birleşmesi veya farklı çağrılara ayrılması, gerekli yeterlik, bilgi ayrımı, çıkar çatışması ve gerçek authority sınırına göre belirlenir. Aşağıdaki “çıktı” alanları gizli düşünce dökümü değil, tüketicinin sonucu inceleyip kullanabilmesi için gerekçe ve kanıt izidir.

## 29.1 DR01 — İhtiyaç ve iş keşfi

**Giriş:** Yetkili mission, mevcut plan/frame, kullanım beklentisi, bilinen kaynak ve ortam sınırları. Rol, yalnız koordinatörün ayrıştırılmış task listesini değil gerektiğinde ham talebi ve onun current yorumunu görebilmelidir. **Çalışma:** Hedefin gerçekleşmesini neyin mümkün kıldığını, hangi koşulların zaten sağlandığını, hangi belirsizliğin maddi olduğunu ve alternatif yöntemlerin farklı gerekliliklerini araştırır.

**Çıktı:** İhtiyaç/koşul haritası; destek ve karşı kanıt; seçilmiş veya açık yöntem alternatifleri; başlanabilir inquiry frontier'ı; üst karara dönüş noktası. Belirsiz ihtiyaç provisional kalabilir; zorunlu olduğu kanıtlanmadan bütün işin hard dependency'si yapılmaz. **Tüketici:** G koordinasyonu ve DR02; yeni bilgi gerekiyorsa DR16, yetki gerekiyorsa uygun owner.

**Yetki sınırı:** SOUL ürün kararını kullanıcı adına uydurmaz; araştırma sırasında keşfettiği kapsam büyümesini grant saymaz. **Kabul:** Maddi eksiği bulma kadar gereksiz önkoşul üretmeme, alternatifleri erken kapatmama ve doğru stopping değerlendirilir. **Failure/recovery:** Keşif sona ermeden kesilirse odak ihtiyaç, açık alternatif ve beklenen alt sonuç saklanır. Başka agent'a “buradan devam et” demek yerine neden/return_to bağı verilir.

## 29.2 DR02 — Kabiliyet ve çalışma sistemi tasarımı

**Giriş:** İhtiyaç/Work haritası, actor yeterlikleri, araç/ortam koşulları, bilgi ve kontrol yükleri. **Çalışma:** Belirli iş için hangi rol, yöntem, araç, veri görünümü, iletişim ve acceptance düzeninin gerekli olduğunu türetir. Hazır bir mimariyi her işe uyarlamak yerine gereksinimlerin hangi bileşimi gerçekten zorunlu kıldığını sorgular.

**Çıktı:** Working Configuration adayı; bileşenler arasındaki sözleşmeler; makul alternatiflerle karşılaştırma; açık qualification yükleri; başarısızlık ve geri alma yolu. Konfigürasyon yalnız prompt metni değildir; hangi release, principal, adapter ve context ihtiyacına bağlı olduğu görünürdür. **Tüketici:** G/Y koordinasyonları, DR09, DR10 ve ilgili kontrol owner'ları.

**Yetki sınırı:** Yeni rol adı gerçek uzmanlık veya model kapasitesi yaratmaz; yeni araç tanımı erişim sağlamaz. **Kabul:** Seçilen bileşim işe özgü yükleri karşılamalı, gereksiz işletim yükü doğurmamalı ve hangi varsayımla seçildiği açıklanmalıdır. **Failure/recovery:** Bir qualification eksikse tüm tasarım “kuruldu” olmaz; bağımsız alt kapasite değerlendirilirken ilgili etki kapısı kapalı kalır. Yeni bilgi tasarımı değiştirirse etkilenen Work ve method release bağları yeniden incelenir.

## 29.3 DR03 — Bütünleştirme

**Giriş:** Parça çıktıları ve revision'ları, Design Baseline, assembly manifest'i, parça review'ları ve açık itirazlar. **Çalışma:** Parçaların birlikte amaçlanan ürünü oluşturup oluşturmadığını, arayüz ve anlam ilişkilerini, korunması gereken özellikleri ve eksik gerçekleşmiş revizyonları inceler.

**Çıktı:** Exact Assembly Snapshot; birleşim incelemesi; source/criterion bağı; uyumsuzluk ve revision Work adayları; teslim edilebilirlik önerisi. “Tüm child task'lar kapalı” yerine “şu sürümdeki bütün şu gerekçeyle değerlendirildi” diyebilmelidir. **Tüketici:** DR13-G ve acceptance owner; eksikler ilgili üretici/keşif rollerine döner.

**Yetki sınırı:** Reviewer'ın yerine bağımsız kabul üretmez; yeni tasarım kararını uygulanmış ürün saymaz. **Kabul:** Gerçek bütün üzerinde kaynak-temelli inceleme ve açık residual'lar gerekir. **Failure/recovery:** Parçalardan biri değiştiğinde tüm iş baştan yapılmaz; etki adayı çıkarılır, bağlar ve actual kaynak kontrol edilir. Eski assembly'ye bağlı review yeni assembly için current gösterilmez. Kritik değişim bilinmiyorsa teslim bekler; bağımsız bölüm işi sürebilir.

## 29.4 DR04 — Sınama tasarımı

**Giriş:** İddia, nesne/sürüm, beklenen kullanım, risk sınıfı ve önceki kanıt. **Çalışma:** İddia yanlış olsaydı hangi gözlemin farklı olacağını tanımlar. Yanlış ve sağlam fixture'ları, alternatif oracle'ları, çevre koşullarını ve coverage sınırını kurar. Bir görev başarı ölçütü ile ona giden mekanik ara ölçüyü ayırır.

**Çıktı:** Sonuçtan önce sabitlenmiş test/deney sözleşmesi; kriter, sampling gerekçesi, ölçüm ve karar kuralı; hata duyarlılığı planı; yapılmayanlar. **Tüketici:** DR11 ve ilgili reviewer; tasarım açığı varsa DR01/DR02. **Yetki sınırı:** Üretici sonucu gördükten sonra kriteri tek başına yeniden tanımlamaz. Yeni kriter gerekiyorsa değişim izini tutar ve fresh evidence yükünü açıklar.

**Kabul:** Test aynı iyi/bad sınıfını ayırt etmeli; boş güvenlik sonucu için her şeyi reddetmemeli; real-world claim'i yanlış proxy ile ölçmemeli. **Failure/recovery:** Oracle yetersiz bulunduğunda önceki PASS geri alınmak zorunda olmayabilir ama iddia kapsamı daralır. Yeni deney ayrı sürüm olur. Aynı checklist'i yıllarca değiştirmeden sürdürmek, güncel hata yüzeyine duyarlı olduğunun kanıtı değildir.

## 29.5 DR05 — Geliştirme ve üretim

**Giriş:** Yetkili Work, current input snapshot, tasarım/criterion ve rol/method release'i, araç ve scope sınırları. **Çalışma:** Belirlenen katkıyı üretir; üretim sırasında ortaya çıkan maddi ihtiyaç veya yanlış varsayımı görünür kılar. Uygulama kolaylığı için amacı sessizce daraltmaz.

**Çıktı:** Candidate artifact revision, değişiklik gerekçesi, kullanılan kaynak/girdi bağı, actual test/araç sonuçları, açık belirsizlik ve tüketiciye dönük teslim notu. Ürün ile onu üreten çalışma kaydı ayrı nesnelerdir. **Tüketici:** Bütünleştirme, review ve request sahibi.

**Yetki sınırı:** Candidate üretme izni protected publication veya kabul izni değildir. Kendi output'unun doğru olduğunu iddia edebilir ama aynı self-review'u bağımsız güvence diye sunamaz. **Kabul:** Katkı istenen scope ve revision'a bağlı, tekrar incelenebilir ve güncel read-set ile teslim edilebilir olmalıdır. **Failure/recovery:** Input değişirse eski candidate saklanır; yeniden kullanılabilir kısmı incelenir. Beklenmedik dış effect varsa plan kaydı değil actual effect kanıtı öncelik kazanır.

## 29.6 DR06-G — SOUL geliştirme koordinasyonu

**Giriş:** Mission, keşif sonuçları, canlı Work ilişkileri, ürün durumu, kaynak/kalite bütçesi ve acceptance sınırı. **Çalışma:** Hangi işin neden sırada olduğunu, alt katkıların hangi üst karara döneceğini, kritik bağımlılıkları ve ürün bütününü izler. Ekibin ilk ve sonraki gerçek SOUL işlerini keşfetmesine alan açar.

**Çıktı:** Yaşayan plan/frame, gerekçeli öncelik, request/return_to bağları, ürün değişim karar adayları ve durma/devam önerisi. **Tüketici:** Ekip ve Batu'nun gerçek yetki/kabul yolu. **Yetki sınırı:** Y'nin operational truth'unu tek başına değiştirmez; kendi frame'ini eleştirinin dışında tutmaz. Mesajları “tamamlandı” diye yorumlayarak actual artifact/review gözlemini atlamaz.

**Kabul:** Planın amaçla bağı, araştırma katkısının kullanımı ve global ilerleme görünür olmalıdır. **Failure/recovery:** Yeni kaynak root anlayışı değiştiriyorsa frame review açar. Child başarılıyken parent başarısız olabilir; bunu takvim gecikmesi gibi daraltmaz. Yeni oturumda bütün geçmişi ezberlemek yerine current planın kaynak ve açık karar bağlarını geri kurar.

## 29.7 DR06-Y — Çalışma işletimi koordinasyonu

**Giriş:** Work/Request/Assignment state, runtime liveness, dispatch kayıtları, event/projection durumu, kaynak ve kontrol hizmetlerinin availability'si. **Çalışma:** İşlerin doğru role gitmesini, beklemelerin nedenlerinin anlaşılmasını, sonuçların doğru tüketiciye dönmesini ve kesintilerin uzlaşmasını sağlar.

**Çıktı:** Dispatch/receipt/recovery kayıtları, açık operasyonel engeller, replacement önerisi ve current handoff. **Tüketici:** G koordinasyonu, DR09/10/14 ve ilgili role. **Yetki sınırı:** Rolü yeniden başlatabilir diye SOUL ürün kararını değiştiremez; task status'unu sonuç doğruluğuna çeviremez. Kullanıcıyı rutin mesaj yönlendiriciye dönüştürmez.

**Kabul:** K1/K2 akışı gerçek gözlemle çalışmalı; hatalı retry veya ghost worker yaratmamalıdır. **Failure/recovery:** Native teammate kaybolduğunda önce authoritative result ve assignment kontrol edilir; otomatik yeni worker gerektiğinde yeni kimlik/epoch/context hazırlanır. Serving veya authority belirsizse protected effect durur, uygun düşük riskli işler ayrılır. Yeni oturumda eski lead'in varlığı varsayılmaz.

## 29.8 DR07 — Bilgi ve çalışma alanı düzeni

**Giriş:** İçerik sahibinin yeni/değişen bilgi kayıtları, current repository/database router'ları, source/revision/status ve tüketim bağları. **Çalışma:** Bilginin doğru yerde, doğru statü ve ilişkiyle bulunmasını; stale ve historical yüzeylerin current bilgiyi gölgelememesini; bakım/silme/devir yüklerinin yürütülmesini sağlar.

**Çıktı:** Güncel index/view, source/revision bağları, bakım önerileri, kırık link ve anlam inceleme talepleri, aktarılabilir handoff. **Tüketici:** Bütün roller; anlam belirsizliği içerik sahibine döner. **Yetki sınırı:** Dosya düzenini onarma yetkisi içerik kararını değiştirmez. Bir duplicate şüphesinde scope ve sürümü anlamadan kayıtları birleştirmez.

**Kabul:** Fresh session doğru current state'e erişebilmeli; source gövdesi gerçekten mevcut olmalı; hash erişim yolu yerine geçmemelidir. **Failure/recovery:** Türetilmiş görünüm güncel değilse canonical kaynağa geri dönülür. Kaynak yoksa boşluk tahminle doldurulmaz. Yerel görünümler yeniden üretilebilir; fakat unique kullanıcı kararları veya gerçek effect kanıtı silinmez.

## 29.9 DR08 — Context derleme

**Giriş:** Trusted ContextRequest, use/target, izinli source ve index'ler, role/method release, budget ve gerekli okuma derinliği. **Çalışma:** Mandatory yükleri koruyarak uygun kaynak, span, qualifier ve karşı kanıtı seçer; view'u üretir; belirsiz coverage'ı gizlemez.

**Çıktı:** Request'e bağlı immutable ContextPackage, yük→kanıt eşliği, açık boşluk, gerçek görünüm kimliği ve cache/revision bağları. **Tüketici:** Görevlendirilen rol ve dispatch adapter'ı. **Yetki sınırı:** Kendi hazırladığı paketin eksiklerini azaltmak için request'i tek başına değiştiremez. Kaynak erişim yetkisini semantic similarity'den çıkarmaz.

**Kabul:** Biçimsel kapsam, actual view ve kaynak/revision/policy/scope bağları doğrulanır; semantic adequacy ayrı kalır. **Failure/recovery:** Budget yetmediğinde mandatory bilgi atılmaz; staged reading, ayrı inquiry veya request revision'ı gerekçelendirilir. Cache current değilse yeniden derlenir. Gönderildi makbuzu ile gerçekten kullanıldığı sonucu eşitlenmez.

## 29.10 DR09 — Görevlendirme ve kapasite eşleme

**Giriş:** Work ihtiyacı, rol sözleşmeleri, actual actor/runtime imkânları, yeterlik kanıtı, erişim/grant sınırı, güncel yük ve bağımsızlık gereği. **Çalışma:** Uygun taşıyıcıyı seçer; bir role bir model ismi atamaktan fazlasını yapar. Eksik yeterlik için qualification işi açar.

**Çıktı:** Assignment adayı ve seçim gerekçesi; gerekli role/config/context sürümleri; varsa yetersiz kapasite veya insan uzman ihtiyacı. Gerçek assignment kimliği, generation ve epoch yetkili kontrol tarafından üretilir. **Tüketici:** Y ve ilgili worker.

**Yetki sınırı:** Actor allocation önerisi permission grant değildir. Bir runtime'a ait bütün agent'ları ayrı secure principal sayamaz. **Kabul:** Doğru taşıyıcının gerçek ortamda çalışabildiği ve iş yükünün kapsamını karşılayabildiği gösterilmelidir. **Failure/recovery:** Liveness kaybı veya yeterlik sorunu durumunda reassign yapılır; eski token fence edilir; geç sonuç candidate olarak incelenir. Aynı işi birden fazla taşıyıcıya vermek gerekiyorsa bunların bağımsız üretim mi yoksa ortak katkı mı olduğu açık olur.

## 29.11 DR10 — Ortam ve kabiliyet nitelendirmesi

**Giriş:** Hedef runtime, araç/adaptör ihtiyacı, network/credential/policy kısıtları ve kaynak bütçesi. **Çalışma:** Güncel birincil kaynak bilgisini actual ortam ölçümüyle ayırır; hangi command/config'in yüklendiğini ve hangi gerçek effect yollarının bulunduğunu araştırır.

**Çıktı:** Sürüm ve environment kimliğine bağlı capability raporu; kurulmuş/erişilebilir/izinli/kullanılmış ayrımı; bypass envanteri ve qualification sonuçları. **Tüketici:** DR02, Y, DR09 ve kontrol owner'ı.

**Yetki sınırı:** Kullanılabilir ürün özelliği, kullanıcı hesabında etkin veya hedef çalışma düzeninde yeterli sayılmaz. Bulunmayan araç için varsayımsal başarılı koşu uydurulmaz. **Kabul:** İstenen scope'ta gerçek olumlu ve olumsuz yollar gösterilmelidir. **Failure/recovery:** Provider/config değiştiğinde ilgili capability kaydı stale olur; bütün mimari yerine etkilenen varsayım açılır. Mac/local bağımlılığı kullanıcı hedefini ihlal ediyorsa çözüm sessizce oraya taşınmaz.

## 29.12 DR11 — Deney yürütme

**Giriş:** Sürümü sabit deney planı, target/model, fixture ve beklenen oracle davranışı. **Çalışma:** Deneyi gerçek ortamında çalıştırır; hata, timeout ve gözlem sınırlarını kaydeder. Fixture içi değişim ile ortam arızasını ayırır.

**Çıktı:** Ham log, exit code, environment/source/test hash'leri, başlangıç/sonuç state ve koşulmayanların listesi. **Tüketici:** DR04, DR13 ve ilgili decision owner. **Yetki sınırı:** Testi çalıştıran rol, sonuç beklentiye uymadı diye kriteri sessizce değiştirmez. Tool sonucu olmayan bir şeyi koşulmuş diye raporlamaz.

**Kabul:** Log tekrar incelenebilir olmalı; başarısızlık import/fixture hatası mı yoksa iddia falsification'ı mı açıklanmalıdır. **Failure/recovery:** Altyapı hatası giderildikten sonra yeni koşu yapılır, eski log silinmez. Kriter değiştiyse sürüm ve epistemik statü ayrılır. Bir test çok sayıda alt girdi içerdiğinde isim/test/girdi sayıları farklı gösterilir.

## 29.13 DR12 — Yetki ve korunan kontrol

**Giriş:** Authenticated principal, current grant/policy, command niyeti, exact target/read-set, assignment/epoch ve effect riski. **Çalışma:** Yetkili geçişi mekanik olarak kabul veya reject eder; gereken owner incelemesini yönlendirir. Hukuki/ürün/estetik doğruluk oracle'ı değildir.

**Çıktı:** İmzalanması gerekiyorsa uygun güven sınırından üretilmiş karar/makbuz, state/event ve red gerekçesi. **Tüketici:** Worker, publisher ve audit/recovery. **Yetki sınırı:** Çağıranın kendi principal etiketi, role adı veya boş gap beyanı authority kaynağı değildir. Control mutation ve grant değişimi ayrı korunan yoldadır.

**Kabul:** Yanlış scope/principal/revision/epoch engellenirken doğru dar çalışma mümkündür. **Failure/recovery:** Authority'ye ulaşılamıyorsa protected effect kapalı kalır. Restore veya failover'da eski issuer/endpoint canlı kalamaz. İptal talimatı gönderildiği değil, effect sınırında kabul edilmediği gösterilir. Bu rolün mantığını aynı worker'ın doğrudan değiştirebildiği düzen güven sınırı sayılmaz.

## 29.14 DR13-G — Ürün/iddia incelemesi

**Giriş:** Exact artifact/assembly, criterion ve design revision, kaynak kanıtı, maker gerekçesi ve gerektiğinde alternatif/ham kaynak görünümü. **Çalışma:** İddianın gerçekten bu nesneden çıkarılıp çıkarılamayacağını, karşı kanıtı ve kapsamını inceler. Üreticinin kendinden emin anlatımını kanıt yerine kullanmaz.

**Çıktı:** Scoped Review/Verdict; desteklenen claim, itiraz, residual, önerilen düzeltme ve yeniden açma koşulu. **Tüketici:** Üretici/bütünleştirme ve kabul owner'ı. **Yetki sınırı:** Her eleştiri ürün tercihini değiştirme yetkisi değildir. Plan-aware ve text-grounded incelemeyi aynı kanıt gibi birleştirmez.

**Kabul:** Yanlış ve sağlam örnekleri ayırt edebilmeli, oracle doğru özelliği ölçmelidir. **Failure/recovery:** Basis değiştiyse verdict stale olur; önceki dar kanıt tarihsel kalır. Ortak model/source/frame sınırı görünür tutulur. Birden fazla reviewer aynı yanlışı tekrar ediyorsa oy sayısı confidence'ı otomatik artırmaz.

## 29.15 DR13-Y — Çalışma düzeni incelemesi

**Giriş:** Request/assignment/dispatch/event/projection, izin ve recovery kayıtları; K1/K2 ve continuity hedefi. **Çalışma:** İşin gerçek hareketinin tasarlanan düzene uyup uymadığını sınar. “Dosya var” ile “tüketici gördü/kullandı” ayrımına bakar.

**Çıktı:** İşletim/kontrol kusuru, etkilenen current state, yanlış başarı veya gereksiz blokaj yolu ve onarım önerisi. **Tüketici:** Y, DR14/DR12 ve gerektiğinde DR02. **Yetki sınırı:** Ürün tercihini sırf operasyon daha kolay olsun diye değiştirmez. Kendi checklist'ini kontrolün gerçekten çalıştığının yerine koymaz.

**Kabul:** Fresh-session devri doğru amacı, yetkiyi ve sıradaki gerçek işi geri kurdurmalıdır. **Failure/recovery:** State/router/handoff çatışması varsa sessiz birini seçmek yerine hierarchy ve kaynak izini değerlendirir. Çatışma çözülmeden etkilenen iş durur; ilgisiz araştırma keyfî biçimde iptal edilmez.

## 29.16 DR14 — Teşhis ve toparlanma

**Giriş:** Gerçek arıza belirtisi, command/effect/observation tarihçesi, current authority ve önceki müdahaleler. **Çalışma:** Yakın nedeni, katkıda bulunan koşulları, prevention/detection açığını ve tekrar yolunu ayırır. Birden çok olası nedeni kanıtla ayrıştırır.

**Çıktı:** Scoped cause model, doğrulanmış/varsayımsal nedenler, güvenli recovery adımları, fix'in değiştirdiği katman ve açık residual. **Tüketici:** Y, üretici, kontrol ve method sorumluları. **Yetki sınırı:** Başarılı workaround'u kök çözüm diye sunmaz. Bilinmeyen dış etkiyi yeniden denemeyle zorla başarıya çevirmeye çalışmaz.

**Kabul:** Müdahale gerçek etki ve tekrar riskini azaltmalı; yeni bir bypass yaratmamalıdır. **Failure/recovery:** Authority veya history eksikse önce gözlem yolu kurulur. Daha derine gitmek karar/müdahaleyi artık değiştirmiyorsa analiz durabilir; kanıtsız sonsuz “neden” zinciri kurulmaz. Recovery sonucu ve öğrenme adayı ayrı kaydedilir.

## 29.17 DR15 — Yöntem ve öğrenme

**Giriş:** Tekrarlayan failure sınıfı, kaynak/deney dayanağı, mevcut method library ve gerçek kullanım koşulları. **Çalışma:** Dersin genellenebilir sınırını, seçme/kullanmama koşulunu, birleşim etkisini ve regression yükünü belirler.

**Çıktı:** Method adayı/release önerisi; applicability, negatif örnekler, etkin bileşim ve geri alma koşulu. **Tüketici:** DR02, role config owner ve evaluation. **Yetki sınırı:** Library'ye yazmak etkin kontrol benimsemesi değildir. Başarısız bir testten sonra kendi criterion'unu gevşeterek yöntemi “iyileşti” sayamaz.

**Kabul:** Fresh görev ve normal cold-start içinde uygun seçim, gerçek kullanım ve fayda gösterilmelidir. **Failure/recovery:** Regresyon çıktığında release geri alınabilir; lesson kaydı silinmez, başarısız applicability kanıtı olarak korunur. Tek problemi çözen yöntemin başka sorunda gereksiz altyapı ürettiği de olumsuz sonuçtur.

## 29.18 DR16 — Araştırma

**Giriş:** Bounded soru, karar bağlamı, kaynak derinliği, freshness gereği ve tüketici. **Çalışma:** Yalnız verilen ürün/terimle değil alttaki ihtiyaç, işlev ve failure üzerinden kaynak arar. Kaynağın açık ifadesi, yorum ve yeni çıkarımı ayırır; karşı kanıt ve kullanım sınırını korur.

**Çıktı:** Source/revision kimlikli sonuç, alternatifler, karar katkısı ve açık belirsizlik; gerekirse ek araştırma önerisi. **Tüketici:** Request sahibi ve bilgi alanı. **Yetki sınırı:** Dış kaynağı etkin kontrol yapmaz; source otoritesini architecture adoption saymaz. Eski research finding güncel provider/API davranışı için yeniden doğrulama gerektirebilir.

**Kabul:** Araştırma ilgili soruya ne kattığını göstermeli; sonucun değişmemesi veya adayın ilgisiz çıkması meşrudur. **Failure/recovery:** Kaynak erişilemiyorsa özetin sınırı belirtilir; tam okuma iddiası uydurulmaz. Uzun araştırma kesilirse okunan kapsam, açık soru, güçlü adaylar ve return_to korunur; yalnız URL listesi yeterli devir değildir.

# 30. Hizmet arayüzleri ve bütünleşik geçiş sözleşmeleri

## 30.1 Mission ve Work admission

**Komut:** `admit_work(proposal, mission_revision, authority_basis)`. Proposal, yapılacak işi olduğu kadar hangi ihtiyaca döneceğini, method koşulunu, output consumer'ı, scope ve izinli effect sınıfını taşır. Server, yetkili mission bağını, proposed work kimliğini ve kayıtlı koşulları doğrular. Yeni bir ürün kapsamı yalnız Work eklemekle grant kapsamına giremez.

**Başarılı sonuç:** Accepted Work revision ve aynı transaction'ın event kaydı. **Conflict:** Mission veya ilgili koşul değişmiştir; yeni bilgiyle proposal değerlendirmesi gerekir. **Rejected:** Yetki/temel giriş yetersizdir veya yasak effect istenmiştir. **Bekleyen:** Bilgi edinme işi açılabilir; production effect için gereken koşulun eksikliği inquiry'yi otomatik yasaklamaz. Bu arayüz production önerisidir; yerel `add/claim` metodlarının tam eşdeğeri değildir.

## 30.2 Request, Contribution ve UseReceipt

`request_contribution` geçerli Work/rol ilişkisine bağlanan bir talep üretir. `submit_contribution` exact artifact veya bilgi revision'ını, kapsamı ve açık qualifier'ları döndürür. `record_use` tüketicinin bu katkıyı nerede ve nasıl kullandığını veya neden kullanmadığını kaydeder. Bu üç geçiş aynı state'in ad değiştirmesi değil, farklı aktör sorumluluklarıdır.

Request key'i, contribution key'i ve tüketim key'i farklı olabilir; aralarındaki bağlantı explicit'tir. Transport duplicate aynı katkıyı iki kez uygulamaz. Başka payload aynı key'i kullanırsa conflict olur. Consumer geçici olarak kaybolursa katkı kaybolmaz; yeni assignment return_to üzerinden devam eder. Tüketicinin “gördüm” demesi kullanıma, “kullandım” demesi doğru yoruma otomatik eşitlenmez.

## 30.3 Claim ve effect command

Claim; Work revision, actual principal ve current assignment/lease koşullarıyla kabul edilir. Production claim token; issuer, scope, work, assignment UUID, generation, authority epoch, izinli command/effect ve expiry varsa onu taşır. Token'ın imzası/host binding'i nasıl yapılıyorsa o güven sınırı test edilir; JSON alanları tek başına güvenlik sağlamaz.

Effect command; token, exact target/read-set, command-specific zorunlu bağımlılıklar, current grant/policy ve kabul yüklerini denetler. Başarıda state ve event birlikte yazılır. Worker'ın verdiği kısa read-set server'ın zorunlu yüklerini düşüremez. Uzun çalışma nedeniyle stale olan candidate korunabilir; current effect ayrı kabul edilir. V3 model bu arayüzün yalnız seçilmiş local kontrol kısmını uygular.

## 30.4 Context request ve dispatch

Trusted consumer `create_context_request` ile amaç, target/use, source derinliği ve bilgi yüklerini oluşturur. Compiler `prepare_context` ile exact kaynak, view ve residual üretir. Validator `qualify_context` ile yapısal coverage/current bağları denetler. Adapter `dispatch_context` ile gerçek runtime'a giden kontrollü parçayı kimliklendirir.

Başarısız derleme, kabul edilmiş bir boş package üretmez. Eksik mandatory yük varsa final use durur veya yetkili yeni request hazırlanır. Dispatch başarısızlığı kaynak doğruluğunu silmez; hangi runtime'a neyin gitmediğini gösterir. Native girişin gözlenemeyen kısmı, izolasyon ve bağımsızlık iddiasını sınırlar. Bu dört geçişin hepsini tek “context hazır” alanına indirmek F02'nin daha geniş biçimini yaratır.

## 30.5 Relation/query servisi

`assert_relation` typed uçlar, revision/scope/use ve etkilediği invariant'larla çalışır. Hard dependency admission cycle kontrolüyle aynı transaction sınırına bağlanır. `query_entities` izinli snapshot üzerinde unique nesne kümesi ve completeness döndürür. `explain_paths` ayrı path bütçesi ve açıklama amacı ister.

Query response; scope/policy görünümü, graph/snapshot kimliği, root set'i, filter, ziyaret/tamlık bilgisi ve witness sınırını içerir. Partial response negatif yokluk hükmü üretemez. Paging sırasında source state değişirse eski continuation token ya aynı snapshot'a döner ya stale olur; farklı snapshot'ları sessizce tek tam sonuç yapamaz. Bu production contract'ın actual PG ve permission davranışı H-GRAPH'ta denenir.

## 30.6 Publication servisi

`prepare_publication` tam niyeti kaydeder. `attempt_effect` effect sınırında current yetkiyi denetleyip dış provider'a koşullu işlem uygular. `observe_effect` authentic readback'i saklar. `finalize_publication` gözlenen sonucu doğru local state ve outbox'a bağlar. Bu komutlar ayrı process'lerde çalışabilir; aynı process'de çalışmaları DB–Git atomikliği yaratmaz.

Operation state ve history, retry decision için yeterli olmalıdır. Unknown result otomatik resubmit değildir. Applied gözlemi current ürün kabulü değildir. Provider ref'i sonradan başka yöne gittiyse tarihsel effect kaydı korunur; current assembly/release yeniden değerlendirilir. Çok ref veya çok artifact transaction'ı gerekiyorsa tek ref CAS testinden o daha geniş garanti çıkarılmaz.

## 30.7 Restore admission ve authority

`begin_recovery` normal protected serving'i kapatır ve checkpoint manifest'ini bağlar. `advance_authority_epoch` backup'tan bağımsız current authority yolunda gerçekleşir. `reconcile_effects` pending operation'ları actual provider durumuyla karşılaştırır. `requalify_access` current grant, policy ve silme yüklerini uygular. `resume_work` yeni assignment/context ile yalnız uygun işi açar.

Bu geçişlerin sırasını atlayan bir “DB restored successfully” mesajı yeterli değildir. Eski endpoint ve issuer'ların hâlâ effect yapabilmesi recovery failure'dır. Doğru yeni işin başlamaması da availability failure'dır. Gerçek test her iki tarafı ölçmelidir. Local EpochAuthority fixture'ı yalnız eski token'ın yeniden eşleşmesine karşı mantık örneğidir.

## 30.8 Review ve acceptance

`open_review` exact claim/target/criterion/use/basis bağını oluşturur. `submit_verdict` kanıt ve residual'ı taşır. `accept_result` yalnız o scope'ta geçerli owner ve current evidence ile karar verir. `reopen` yeni maddi bilgi veya değişen basis ile eski hükmün kullanımını yeniden değerlendirir.

Aynı output farklı amaçta kullanılacaksa eski verdict otomatik taşınmaz. Reviewer's role adı gerçek independent principal kanıtı değilse acceptance bunu bilmelidir. Kullanıcı tercihiyle teknik doğruluk ayrı kaydedilir. İnsan onayı yalnız üst sorumluluğu veya ürün tercihini kabul ediyor olabilir; unseen benchmark veya host guarantee doğrulamış sayılamaz.

# 31. İnceleme kapanışı ve kalıcı açıklar

Bu teslim, v2'nin ana tasarımını tüm başlıklarıyla yeniden tartışıp kritik birleşim noktalarını değiştirdi. Yalnız graph eki veya test raporu değildir: iş keşfi, rol sözleşmeleri, bilgi düzeni, context, ilişkiler, authority, yayın, restore, uzun ürün, yöntem aktarımı ve işletim birbirine bağlandı. Aynı zamanda bütün bunları uyguladığını iddia eden yeni bir sahte production kernel de oluşturulmadı.

P4'te environment family artık belirsiz değildir: kullanıcı Codex kararını vermiştir. Geriye kalan önemli belirsizlik, DevOS control plane ile gerçek Codex harness/environment/tool sınırlarının SOUL hedefini taşıyacak biçimde birleşip birleşmeyeceğidir. K1/K2 ve güven sınırı uygun çıkmazsa Codex içindeki execution/topoloji seçimi değişebilir; environment kararı sessizce Claude'a geri dönmez. Context/keşif/uzun ürün deneyleri başarısız çıkarsa yalnız daha fazla kontrol veya daha büyük DB eklemek yeterli olmayabilir. Bu nedenle mekanik ve bilişsel kabul yolları birlikte tutulur.

Paketin güçlü kanıtı, yanlış durumların gerçek ve tekrar üretilebilir yerel örnekleridir. Zayıf veya yapılmamış kanıtları da açıkça sayar: authenticated runtime, native dispatch, gerçek PostgreSQL ve remote Git publisher, durable authority epoch, actual silme/restore, bağımsız evaluator ve tam SOUL ürünü deneyi. Bu açıklık raporu değersiz yapmaz; hangi kararı taşıyabildiğini ve hangisini taşımadığını belirler.

**P4 Codex revizyonu tamamlanabilir; P5 kurulum rehberi ayrı sonraki aşamadır ve P6 hedef kabulü bu rapordan otomatik çıkmaz.** Kalıcı repository kaydı bu ayrımı korumalı, kaynak paketine gerçek erişim yolunu göstermeli ve yeni oturumu eski P4-01 veya doğrulanmamış “88 test” beyanına göndermemelidir.
